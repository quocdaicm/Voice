> **AI/dev tiếp quản: đọc `HANDOFF.md` trước.**

# CIT Voice (iOS) — giọng đọc tiếng Việt chạy trên máy

Bản iOS của CIT Voice Studio, dùng model VieNeu v3 Nano (ONNX) chạy hoàn toàn trên iPhone.

**Trạng thái: giai đoạn 2–3 đã viết xong, CHƯA build/chạy thử.** Chi tiết lộ trình ở đầu `CITVoice/TTSEngine.swift`.

| Phần | Trạng thái |
|---|---|
| Khung app, tải model, 11 giọng, phát/chia sẻ WAV, CI → IPA | ✅ (giai đoạn 1) |
| Tách câu, chia chunk, thẻ cảm xúc, thẻ `[nghỉ 2s]` (`TextChunker`, `PauseTags`) | ✍️ đã port từ Python, chưa test |
| Engine ONNX (`NanoEngine`), đọc `constants.npz` (`NPZ`), nối/cắt âm (`AudioUtils`) | ✍️ đã viết, chưa test |
| Vá mask bool cho ONNX Runtime iOS (`OnnxBoolPatch`) | ✍️ đã viết, chưa test |
| Nhân bản giọng: ghi âm/chọn file → x-vector (fbank Kaldi 80 mel + `speaker_encoder`) + style 50×256 (`codec_encoder` → chuẩn hoá/gom ×6 → `reference_encoder`); `VoiceCloner`, `SpeakerFbank`, `Resampler`, `CloneView`, giọng lưu ở `CustomVoices.json` | ✍️ đã viết, chưa chạy thử trên máy thật |
| sea-g2p (Rust, vendor/sea-g2p) → `SeaG2PFFI.xcframework` qua C-ABI có sẵn + từ điển `sea_g2p.bin` (`scripts/prepare.sh` tự tải) | ✍️ đã nối, CI build, chưa chạy thử |

## Giao diện & logo (v0.3)
- Icon app: `CITVoice/Assets.xcassets/AppIcon.appiconset` (1024×1024, không alpha, iOS tự bo góc); bản vector gốc: `Logo.svg`.
- Giao diện kiểu iOS: nền grouped, thẻ bo 20pt, chip chọn giọng, thanh "Tạo giọng nói" ghim dưới đáy (vật liệu mờ), trình phát + chia sẻ, haptics, tự đổi Sáng/Tối. Màu nhấn `AccentColor` (indigo → tím).
- Toàn bộ nền, banner, nút và icon là **SVG vector** trong `Assets.xcassets` (bản gốc ở `design-svg/`, sửa bằng Figma/Illustrator rồi chép đè): `BgAurora` (có bản Tối), `HeroWave`, `BtnPrimary`, `BtnRound`/`BtnRoundRed`, `BtnRecord`/`BtnRecordRed`, và icon `Ic*` (template, tô màu theo `foregroundStyle`). Cần Xcode 12+.
- Trình phát sóng âm (`Waveform.swift`, `AudioPlayer.swift`): sóng thật tách từ file WAV, phần đã phát tô gradient, kim chỉ vị trí, chạm/kéo để tua, thời gian chạy, quầng sáng và thanh nhấp nhô theo âm lượng khi phát, đọc được bằng VoiceOver. Dùng ở màn chính (kèm chia sẻ WAV) và ở nghe thử giọng mẫu.
- **Lồng tiếng video** (`DubbingView`, `DubbingModel`, `DubbingExporter`, `Subtitles`): chọn video (thư viện ảnh/Tệp) + phụ đề `.srt`/`.vtt` (hoặc dán, hoặc đọc track phụ đề có sẵn trong video) → tạo giọng từng dòng, đặt đúng mốc thời gian, dòng nào dài hơn khung thì tạo lại với tốc độ cao hơn (tối đa 1.6x) → ghép vào video (giữ âm gốc nhỏ 15% hoặc tắt) → xuất `.mp4`, xem lại và chia sẻ. Giới hạn video 30 phút. Chưa chạy thử trên máy thật.
- **Tự tạo phụ đề (v0.4)** (`SubtitleGenModel`, `AudioExtractor`, `Translator`, `AutoSubtitleViews`): nút "Tự tạo phụ đề" ở thẻ Phụ đề → chọn ngôn ngữ gốc (hoặc tự phát hiện: Anh, Trung, Thái, Hàn, Nhật…) và model → trích âm thanh 16 kHz → nhận dạng bằng **WhisperKit** (Swift Package, ghim 0.9.0, model `openai_whisper-base/small` tải từ HuggingFace lần đầu) → gộp/tách đoạn cho vừa lồng tiếng → dịch sang tiếng Việt bằng **Apple Translation** (iOS 18+, chạy trên máy, có hộp tải gói ngôn ngữ; iOS cũ hơn hoặc cặp ngôn ngữ không hỗ trợ thì giữ bản gốc để người dùng tự sửa) → màn **sửa từng dòng** (sửa chữ, vuốt xoá, xuất `.srt`) → rồi mới tạo video. Cần Xcode 16+ để có framework `Translation` (nếu thiếu, code tự bỏ phần dịch nhờ `canImport`). Chưa build thử: API WhisperKit viết theo tài liệu công khai, nếu CI báo `error:` ở `SubtitleGenModel.swift` thì gửi lại để sửa.
- `Theme.swift`: logo vẽ bằng code (`LogoMark`), `Card`, các `ButtonStyle`, `IconBadge`, `WaveformBars`, `Haptics`.
- Giao diện mới chưa được build thử trên Xcode; nếu CI báo lỗi `error:` thì gửi lại để sửa.

Nếu thiếu `SeaG2PFFI` hoặc model chưa tải, nút "Tạo giọng nói" chỉ phát tiếng bíp.

## Build bằng GitHub (không cần máy tính)
1. Tạo repo mới, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions → Build iOS → Run workflow** (hoặc cứ push là tự chạy).
3. Xong thì tải artifact **CITVoice-ipa** (file `.ipa` chưa ký), ký/cài bằng công cụ bạn đang dùng cho các app trước.
4. Nếu build lỗi: mở artifact **build-log** hoặc copy các dòng `error:` gửi lại để sửa.

Đổi bundle id (`app.citvoice.ios`) trong `project.yml` nếu cần cho việc ký.

## Nhân bản giọng (v3 Nano, giai đoạn 4)
- Vào **Nhân bản giọng nói** → tải thêm 3 model (~100 MB) → ghi âm/chọn file 5–10 giây → tích xác nhận quyền → **Tạo giọng**.
- Giọng mới xuất hiện trong danh sách giọng và được lưu bền; xoá ở cuối màn Nhân bản giọng.
- Chưa có: khử nhiễu (`denoiser.onnx`) và watermark như bản Python.
- Phần cần kiểm chứng trên máy thật: tên/bố cục đầu vào của `speaker_encoder.onnx` (code tự thử `[1,T,80]` rồi `[1,80,T]`), tham số fbank.
- Đã thử bằng Python tương đương: bộ resample (sai số < 1e-4), FFT/fbank (khớp numpy ~1e-13), ánh xạ gom nhóm latent ×6 (khớp `reshape/transpose` của bản gốc).
