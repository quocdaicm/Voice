> **AI/dev tiếp quản: đọc `HANDOFF.md` trước.**

# CIT Voice (iOS) — giọng đọc tiếng Việt chạy trên máy

**Tác giả ứng dụng:** Quốc Đại · quocdai.net@gmail.com · https://quocdai.site · https://www.tiktok.com/@quocdai69f1 · © 2026 Quốc Đại

Bản iOS của CIT Voice Studio, dùng model VieNeu v3 Nano (ONNX) chạy hoàn toàn trên iPhone.

**Trạng thái: giai đoạn 2–3 đã viết xong, CHƯA build/chạy thử.** Chi tiết lộ trình ở đầu `CITVoice/TTSEngine.swift`.

| Phần | Trạng thái |
|---|---|
| Khung app, tải model, 11 giọng, phát/chia sẻ WAV, CI → IPA | ✅ (giai đoạn 1) |
| Tách câu, chia chunk, thẻ cảm xúc, thẻ `[nghỉ 2s]` (`TextChunker`, `PauseTags`) | ✍️ đã port từ Python, chưa test |
| Engine ONNX (`NanoEngine`), đọc `constants.npz` (`NPZ`), nối/cắt âm (`AudioUtils`) | ✍️ đã viết, chưa test |
| Vá mask bool cho ONNX Runtime iOS (`OnnxBoolPatch`) | ✍️ đã viết, chưa test |
| Nhân bản giọng: ghi âm/chọn file → x-vector (fbank Kaldi 80 mel + `speaker_encoder`) + style 50×256 (`codec_encoder` → chuẩn hoá/gom ×6 → `reference_encoder`); `VoiceCloner`, `SpeakerFbank`, `Resampler`, `CloneView`, giọng lưu ở `CustomVoices.json` | ✍️ đã viết, chưa chạy thử trên máy thật |
| sea-g2p (Rust, vendor/sea-g2p) → `SeaG2PFFI.xcframework` qua C-ABI có sẵn + từ điển `sea_g2p.bin` (`scripts/prepare.sh` tự tải) | ✍️ đã nối, CI build, chưa chạy thử |

## Giao diện & logo (v0.3)
- Icon app: `CITVoice/Assets.xcassets/AppIcon.appiconset` (1024×1024, không alpha, iOS tự bo góc); bản vector gốc: `Logo.svg`.
- Giao diện kiểu iOS: nền grouped, thẻ bo 20pt, chip chọn giọng, thanh "Tạo giọng nói" ghim dưới đáy (vật liệu mờ), trình phát + chia sẻ, haptics, tự đổi Sáng/Tối. Màu nhấn `AccentColor` (indigo → tím).
- Toàn bộ nền, banner, nút và icon là **SVG vector** trong `Assets.xcassets` (bản gốc ở `design-svg/`, sửa bằng Figma/Illustrator rồi chép đè): `BgAurora` (có bản Tối), `HeroWave`, `BtnPrimary`, `BtnRound`/`BtnRoundRed`, `BtnRecord`/`BtnRecordRed`, và icon `Ic*` (template, tô màu theo `foregroundStyle`). Cần Xcode 12+.
- Trình phát sóng âm (`Waveform.swift`, `AudioPlayer.swift`): sóng thật tách từ file WAV, phần đã phát tô gradient, kim chỉ vị trí, chạm/kéo để tua, thời gian chạy, quầng sáng và thanh nhấp nhô theo âm lượng khi phát, đọc được bằng VoiceOver. Dùng ở màn chính (kèm chia sẻ WAV) và ở nghe thử giọng mẫu.
- **Lồng tiếng video** (`DubbingView`, `DubbingModel`, `DubbingExporter`, `Subtitles`): chọn video (thư viện ảnh/Tệp) + phụ đề `.srt`/`.vtt` (hoặc dán, hoặc đọc track phụ đề có sẵn trong video) → tạo giọng từng dòng, đặt đúng mốc thời gian, dòng nào dài hơn khung thì tạo lại với tốc độ cao hơn (tối đa 1.6x) → ghép vào video (giữ âm gốc nhỏ 15% hoặc tắt) → xuất `.mp4`, xem lại và chia sẻ. Giới hạn video 30 phút. Chưa chạy thử trên máy thật.
- **Tự tạo phụ đề (v0.4)** (`SubtitleGenModel`, `AudioExtractor`, `Translator`, `AutoSubtitleViews`): nút "Tự tạo phụ đề" ở thẻ Phụ đề → chọn ngôn ngữ gốc (hoặc tự phát hiện: Anh, Trung, Thái, Hàn, Nhật…) và model → trích âm thanh 16 kHz → nhận dạng bằng **WhisperKit** (Swift Package, ghim 0.9.0, model `openai_whisper-base/small` tải từ HuggingFace lần đầu) → gộp/tách đoạn cho vừa lồng tiếng → dịch sang tiếng Việt bằng **Apple Translation** (iOS 18+, chạy trên máy, có hộp tải gói ngôn ngữ; iOS cũ hơn hoặc cặp ngôn ngữ không hỗ trợ thì giữ bản gốc để người dùng tự sửa) → màn **sửa từng dòng** (sửa chữ, vuốt xoá, xuất `.srt`) → rồi mới tạo video. Cần Xcode 16+ để có framework `Translation` (nếu thiếu, code tự bỏ phần dịch nhờ `canImport`). Chưa build thử: API WhisperKit viết theo tài liệu công khai, nếu CI báo `error:` ở `SubtitleGenModel.swift` thì gửi lại để sửa.
- **Sao lưu & khôi phục (v0.5)** (`Backup.swift`, thẻ ở màn chính): nhập giọng từ file `.json` (cùng định dạng `voices_v3_nano.json`, kiểm tra 192 + 50×256, tên trùng tự thêm hậu tố), lưu giọng đã nhân bản ra `.json`, lưu model đã tải thành thư mục `CITVoice-Model` (kèm file thông tin đã vá ONNX) ra app Tệp/iCloud và khôi phục lại mà không cần tải. Chưa build thử.
- **v0.6**: màn sửa phụ đề có chỉnh mốc từng dòng (±0.1 s), nghe thử giọng từng dòng, cảnh báo dòng dài; lưu video vào Ảnh; ghi WAV theo khối (ít RAM); hiện MB đã tải khi tải model Whisper (model lưu ở Application Support, không sao lưu iCloud); lọc câu lặp do Whisper "ảo giác".
- **v0.7**:
  - **Tách lời gốc khỏi nhạc nền** (`StemSeparator.swift`): model UVR-MDX-NET Inst HQ 3 bản Core ML fp16 (~34 MB, `gyoom/UVR-MDX-CoreML`, MIT) tải riêng ở màn Lồng tiếng → bật "Tách lời gốc, chỉ giữ nhạc nền". Xử lý theo đoạn ~5.9 giây (STFT/iSTFT tự viết bằng Swift, FFT cơ số 2×3, đã kiểm bằng Python), âm thanh trung gian ghi ra đĩa nên ít tốn RAM; kết quả (WAV stereo 44,1 kHz) được dùng lại nếu tạo lại cùng video. Khi bật, nhạc nền thay cho âm gốc của video và không còn "ducking".
  - **Tự rút ngắn câu dịch** (`LineShortener.swift`): dùng model ngôn ngữ trên máy của Apple (Foundation Models, cần iOS 26 + Apple Intelligence + tiếng Việt được hỗ trợ). Bật ở sheet "Tự tạo phụ đề" hoặc bấm "Rút ngắn N dòng quá dài" trong màn sửa phụ đề. Máy không hỗ trợ → tự tắt, lồng tiếng vẫn đọc nhanh hơn (≤1.6x) như cũ.
  - **Giấy phép & ghi công** (`Licenses.swift`, `THIRD_PARTY_NOTICES.md`, `Resources/LICENSE-Apache-2.0.txt`): màn "Giấy phép & ghi công" ở màn chính, toàn văn MIT/Apache-2.0 và liên kết nguồn của mọi thành phần bên thứ ba.
  - Chưa build thử; nếu CI báo `error:` ở `StemSeparator.swift` / `LineShortener.swift` thì gửi lại để sửa.
- `Theme.swift`: logo vẽ bằng code (`LogoMark`), `Card`, các `ButtonStyle`, `IconBadge`, `WaveformBars`, `Haptics`.
- Giao diện mới chưa được build thử trên Xcode; nếu CI báo lỗi `error:` thì gửi lại để sửa.

Nếu thiếu `SeaG2PFFI` hoặc model chưa tải, nút "Tạo giọng nói" chỉ phát tiếng bíp.

## Build bằng GitHub (không cần máy tính)
1. Tạo repo mới, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions → Build iOS → Run workflow** (hoặc cứ push là tự chạy).
3. Xong thì tải artifact **CITVoice-ipa** (file `.ipa` chưa ký), ký/cài bằng công cụ bạn đang dùng cho các app trước.
4. Nếu build lỗi: mở artifact **build-log** hoặc copy các dòng `error:` gửi lại để sửa.

Đổi bundle id (`app.citvoice.ios`) trong `project.yml` nếu cần cho việc ký.

## Nhân bản giọng (v3 Nano, giai đoạn 4)
- Vào **Nhân bản giọng nói** → tải thêm 3 model (~100 MB) → ghi âm/chọn file 5–10 giây → tích xác nhận quyền → **Tạo giọng**.
- Giọng mới xuất hiện trong danh sách giọng và được lưu bền; xoá ở cuối màn Nhân bản giọng.
- Chưa có: khử nhiễu (`denoiser.onnx`) và watermark như bản Python.
- Phần cần kiểm chứng trên máy thật: tên/bố cục đầu vào của `speaker_encoder.onnx` (code tự thử `[1,T,80]` rồi `[1,80,T]`), tham số fbank.
- Đã thử bằng Python tương đương: bộ resample (sai số < 1e-4), FFT/fbank (khớp numpy ~1e-13), ánh xạ gom nhóm latent ×6 (khớp `reshape/transpose` của bản gốc).

- **v0.8 — nhịp đọc, nhiều đoạn, lịch sử, xuất M4A** (`Pacing.swift`, `History.swift`, `AudioExporter.swift`; sửa `AppModel`, `ContentView`, `NanoEngine`, `Waveform`):
  - **Nhịp đọc**: bộ cài sẵn Chuẩn / Kể chuyện / Tiên hiệp (tốc độ + ngắt nghỉ), tốc độ 0.5–1.5x bước 0.05, ba thanh ngắt nghỉ (giữa đoạn / giữa câu / sau dấu phẩy) và thẻ `[nghỉ 2s]` như cũ. Giá trị được nhớ cho lần mở sau.
  - **Nhiều đoạn**: mỗi dòng là một đoạn, tạo lần lượt (hiện "Đoạn i/n"), nghỉ giữa đoạn theo cài đặt, âm lượng chuẩn hoá một lần cho cả bản; bấm Huỷ giữa chừng vẫn giữ phần đã tạo. Nút "Mở .txt" nạp văn bản từ file.
  - **Lịch sử**: mỗi bản tạo được lưu (tối đa 30 bản mới nhất, Application Support/History), nghe lại, chia sẻ, dùng lại văn bản, vuốt để xoá.
  - **Xuất**: nút chia sẻ có WAV và M4A (AAC mono 64 kbps). MP3 chưa có vì iOS không có bộ mã hoá MP3 sẵn (cần thêm LAME, giấy phép LGPL).
  - Chưa build thử; nếu CI báo `error:` ở `History.swift` / `AudioExporter.swift` / `AppModel.swift` / `ContentView.swift` thì gửi lại để sửa.

- **v0.9 — Lồng tiếng khớp khung hơn** (`DubFit.swift`; sửa `DubbingModel`, `DubbingView`, `Licenses`):
  - **Đo rồi chỉnh**: mỗi dòng cắt im lặng hai đầu, đo độ dài thật; nếu dài hơn khung thì đọc nhanh lên tối đa 2 lần chỉnh (≤1.6x) thay vì 1 lần như trước.
  - **Danh sách dòng quá dài** sau khi tạo (giờ, độ dài đọc / khung, nội dung) để biết dòng nào cần rút ngắn; báo số dòng đã phải đọc nhanh hơn.
  - **Dự báo trước khi tạo** ở thẻ Phụ đề: bao nhiêu dòng có thể không kịp. Tốc độ đọc (ký tự/giây) khởi đầu 16 cho tiếng Việt rồi tự học theo giọng đang dùng (lưu `dub.cps1`).
  - **Cân bằng âm lượng** giữa các dòng (±4 dB, không vượt đỉnh).
  - Ý tưởng tham khảo VoiceStudio (AGPL-3.0), mã tự viết lại; ghi công trong màn Giấy phép và `THIRD_PARTY_NOTICES.md`.
  - Chưa build thử; nếu CI báo `error:` ở `DubFit.swift` / `DubbingModel.swift` / `DubbingView.swift` thì gửi lại để sửa.

- **v0.10 — Tạo lại nhanh + phụ đề khớp giọng** (`DubFit.swift` có `DubCache`; sửa `DubbingModel`, `DubbingView`):
  - **Bộ nhớ đệm từng dòng**: dòng nào không đổi (cùng chữ, giọng, tốc độ, chất lượng, khung) thì dùng lại lần tạo trước. Rút ngắn vài dòng rồi tạo lại chỉ tạo giọng cho các dòng đã sửa. Lưu ở Caches (tự giữ ≤400 MB, nút Xoá ở thẻ Giọng đọc).
  - **Xuất phụ đề khớp giọng** (.srt): mốc bắt đầu/kết thúc theo độ dài giọng thật, nút chia sẻ ở thẻ Kết quả.
  - Ý tưởng tạo lại phần thay đổi tham khảo VoiceStudio (AGPL-3.0), mã tự viết.
  - Chưa build thử; nếu CI báo `error:` ở `DubFit.swift` / `DubbingModel.swift` / `DubbingView.swift` thì gửi lại để sửa.

- **v0.11 — Giọng Supertonic-3 (tuỳ chọn)** (`SupertonicEngine.swift`, `SupertonicStore.swift`, `SupertonicCard.swift`; sửa `AppModel`, `ContentView`, `VoiceLibrary`, `Licenses`):
  - Thẻ **"Thêm giọng Supertonic-3"** ở màn chính: tải model ONNX (bản ghim `supertone-oss-archive/supertonic-3`), xong thì thêm các giọng **Supertonic Nam/Nữ 1–5** vào thẻ Giọng đọc. Dùng được cho đọc văn bản, lồng tiếng và xuất file như giọng VieNeu.
  - Chọn giọng nào thì engine đó chạy (`RouterEngine`). Đầu ra 44,1 kHz được hạ về 24 kHz để dùng chung các phần còn lại. Chưa nhân bản giọng được với Supertonic.
  - Mức chất lượng ánh xạ sang số bước: Nhanh 6, Chuẩn 8, Cao 12, Rất cao 16. Tốc độ nhân 1,05 như mặc định của hãng.
  - Ghi công và điều khoản OpenRAIL-M trong màn Giấy phép và `THIRD_PARTY_NOTICES.md`.
  - **Chưa build, chưa nghe thử trên máy.** Nếu CI báo `error:` ở `SupertonicEngine.swift` / `SupertonicStore.swift` / `AppModel.swift` thì gửi lại để sửa; nếu giọng ra lạ (rè, ngắt, sai chữ) gửi mô tả để chỉnh.

- **v0.12 — Phụ đề karaoke** (`KaraokeASS.swift`; sửa `DubbingModel`, `DubbingView`, `Licenses`):
  - Sau khi lồng tiếng, thẻ Kết quả có nút **Chia sẻ phụ đề karaoke (.ass)**: mỗi từ sáng dần theo giọng đọc (thẻ `\kf`), mốc thời gian lấy từ độ dài giọng thật của từng dòng.
  - Thời gian trong dòng chia theo độ dài từ và dấu ngắt (không chia đều); tổng các thẻ luôn bằng độ dài dòng.
  - Mở bằng VLC, ffmpeg (`-vf ass=phu-de-karaoke.ass`) hoặc ứng dụng dựng video có nhập .ass. Chưa đốt thẳng vào video trong app.
  - Ý tưởng tham khảo VoiceStudio (AGPL-3.0), mã tự viết; đã ghi trong mục Giấy phép.
  - Chưa build thử; nếu CI báo `error:` ở `KaraokeASS.swift` thì gửi lại để sửa.

- **v0.13 — Video karaoke** (`KaraokeVideo.swift`, `KaraokeVideoSection.swift`; sửa `KaraokeASS`, `DubbingModel`, `DubbingView`, `Licenses`):
  - Sau khi lồng tiếng, thẻ Kết quả có mục **Video karaoke**: chọn cỡ chữ (Nhỏ/Vừa/Lớn) và màu sáng (Vàng/Xanh lá/Hồng/Cam), bấm **Tạo video karaoke**. App vẽ chữ từng từ sáng dần theo giọng lên video đã lồng tiếng (âm thanh giữ nguyên), xong thì chia sẻ hoặc lưu vào Ảnh.
  - Cách làm: tự vẽ chữ bằng Core Graphics rồi ghép từng khung hình bằng Core Image (`AVMutableVideoComposition` + `AVAssetExportSession`), không cần ffmpeg. Chữ nằm ở đáy khung, tự xuống dòng khi dài, có viền đen.
  - Mốc từng từ dùng chung cách chia với `.ass` (theo độ dài từ và dấu ngắt). Có nút Huỷ khi đang xuất.
  - Cần video đã lồng tiếng của lần tạo hiện tại (cùng phiên). Video xuất lại sẽ tốn thời gian gần bằng độ dài video.
  - Chưa build thử; nếu CI báo `error:` ở `KaraokeVideo.swift` / `KaraokeVideoSection.swift` / `DubbingModel.swift` thì gửi lại để sửa. Nếu chữ lệch vị trí hoặc quét sáng sai tốc độ, gửi ảnh chụp video để chỉnh.

- **v0.14 — Video karaoke từ văn bản + giọng (không cần video gốc)** (`KaraokeScene.swift`, `KaraokeSceneCard.swift`; sửa `KaraokeVideo`, `AppModel`, `ContentView`, `Licenses`):
  - Sau khi bấm **Tạo giọng nói** ở màn chính, có thẻ **Video karaoke**: chọn khung Dọc 9:16 (1080×1920) hoặc Ngang 16:9 (1920×1080), nền (Tím đêm / Xanh biển / Hồng sen / Đen, hoặc ảnh từ thư viện, được làm tối nhẹ), cỡ chữ, màu sáng. Bấm **Tạo video karaoke** → chia sẻ hoặc lưu vào Ảnh.
  - Cách làm: app ghi mốc thời gian từng đoạn khi đọc, chia mỗi đoạn thành cụm ngắn (theo câu, dấu phẩy, rồi theo từ) tỉ lệ theo số ký tự; vẽ từng khung hình 30 fps (nền + chữ ở giữa khung) bằng `AVAssetWriter`, đổi âm thanh sang M4A rồi ghép (không mã hoá lại).
  - Giữ dòng đang hiện tới khi dòng sau bắt đầu. Hai chế độ video karaoke (có video gốc / chỉ nền) dùng chung `KaraokeRenderer`.
  - Hạn chế: thẻ ngắt nghỉ `[nghỉ 2s]` làm lệch nhẹ mốc chữ trong đoạn đó; chỉ làm cho bản đọc mới nhất; video dài tốn thời gian tạo (gần tỉ lệ với độ dài, chưa đo).
  - Chưa build thử; nếu CI báo `error:` ở `KaraokeScene.swift` / `KaraokeSceneCard.swift` / `KaraokeVideo.swift` thì gửi lại để sửa.
