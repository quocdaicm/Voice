# CIT Voice (iOS) — giọng đọc tiếng Việt chạy trên máy

Bản iOS của CIT Voice Studio, dùng model VieNeu v3 Nano (ONNX) chạy hoàn toàn trên iPhone.

**Trạng thái: giai đoạn 2–3 đã viết xong, CHƯA build/chạy thử.** Chi tiết lộ trình ở đầu `CITVoice/TTSEngine.swift`.

| Phần | Trạng thái |
|---|---|
| Khung app, tải model, 11 giọng, phát/chia sẻ WAV, CI → IPA | ✅ (giai đoạn 1) |
| Tách câu, chia chunk, thẻ cảm xúc, thẻ `[nghỉ 2s]` (`TextChunker`, `PauseTags`) | ✍️ đã port từ Python, chưa test |
| Engine ONNX (`NanoEngine`), đọc `constants.npz` (`NPZ`), nối/cắt âm (`AudioUtils`) | ✍️ đã viết, chưa test |
| Vá mask bool cho ONNX Runtime iOS (`OnnxBoolPatch`) | ✍️ đã viết, chưa test |
| sea-g2p (Rust, vendor/sea-g2p) → `SeaG2PFFI.xcframework` qua C-ABI có sẵn + từ điển `sea_g2p.bin` (CI tự tải từ repo sea-g2p, không nằm trong repo) | ✍️ đã nối, CI build, chưa chạy thử |

Nếu thiếu `SeaG2PFFI` hoặc model chưa tải, nút "Tạo giọng nói" chỉ phát tiếng bíp.

## Build bằng GitHub (không cần máy tính)
1. Tạo repo mới, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions → Build iOS → Run workflow** (hoặc cứ push là tự chạy).
3. Xong thì tải artifact **CITVoice-ipa** (file `.ipa` chưa ký), ký/cài bằng công cụ bạn đang dùng cho các app trước.
4. Nếu build lỗi: mở artifact **build-log** hoặc copy các dòng `error:` gửi lại để sửa.

Đổi bundle id (`app.citvoice.ios`) trong `project.yml` nếu cần cho việc ký.
