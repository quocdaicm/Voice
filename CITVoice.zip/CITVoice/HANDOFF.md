# HANDOFF — CITVoice iOS (đọc file này trước khi làm tiếp)

Người dùng viết tiếng Việt → trả lời tiếng Việt. Khi trả project: **đúng 1 file zip** (không chia nhỏ).
Project **CHƯA từng build/chạy thử** (không có Xcode ở môi trường làm việc). Mọi code Swift mới chỉ được kiểm tra bằng cách đếm ngoặc. Khi người dùng gửi lỗi `error:` từ CI/Xcode thì sửa ngay.

## 1. Tổng quan project
- App iOS (SwiftUI, iOS 16+, xcodegen `project.yml`, build bằng GitHub Actions → IPA chưa ký). Đọc `README.md` và đầu `CITVoice/TTSEngine.swift` để biết lộ trình engine.
- TTS tiếng Việt chạy trên máy: VieNeu v3 Nano (ONNX Runtime) + sea-g2p (Rust, `vendor/sea-g2p`). Nhân bản giọng từ ghi âm.
- Bundle id `app.citvoice.ios`, phiên bản 0.4.0.

## 2. Đã làm trong phiên này
| Hạng mục | File |
|---|---|
| Logo app (SVG → PNG 1024 không alpha) | `Logo.svg`, `CITVoice/Assets.xcassets/AppIcon.appiconset`, `AccentColor` |
| Bộ SVG vector: nền aurora (sáng/tối), banner `HeroWave`, nút `BtnPrimary`, `BtnRound(Red)`, `BtnRecord(Red)`, 13 icon `Ic*` (template) | `Assets.xcassets/*.imageset`, bản gốc `design-svg/` (sinh bằng script Python, chỉ dùng gradient/path vì actool không hỗ trợ filter/blur) |
| Thiết kế iOS: thẻ kính `Card`, `PrimaryButtonStyle`, `SoftButtonStyle`, `CircleIconButtonStyle`, `RecordButton`, `SVGIcon`, `SVGLabel`, `AuroraBackground`, `HeroBanner`, `LogoMark`, `Haptics`, `hideKeyboard()` | `Theme.swift` |
| Màn chính, chip chọn giọng, thanh dưới (tạo + trình phát) | `ContentView.swift` |
| Màn nhân bản giọng | `CloneView.swift` |
| Trình phát sóng âm (tách đỉnh từ WAV, tua bằng kéo, quầng sáng theo âm lượng) | `Waveform.swift`, `AudioPlayer.swift` (có `pause/seek/skip`, `stop()` = pause) |
| Ẩn bàn phím: chạm nền, cuộn, nút "Xong" trên bàn phím, Return ở ô tên giọng | `dismissKeyboardOnTap()`, `keyboardDoneButton()` |
| Bỏ dòng chữ phụ dư thừa | — |
| **Lồng tiếng video**: video (thư viện/Tệp) + phụ đề .srt/.vtt/dán/track nhúng → tạo giọng từng dòng, đặt đúng mốc, dòng quá dài thì tạo lại tốc độ ≤1.6x, ghép vào video (giữ âm gốc 15% hoặc tắt), xuất mp4 | `DubbingView.swift`, `DubbingModel.swift`, `DubbingExporter.swift`, `Subtitles.swift`; `AppModel.makeEngine(store:)` dùng chung engine |

Giới hạn hiện tại của lồng tiếng: video ≤ 30 phút (mix toàn bộ trong RAM, Float 24 kHz); phụ đề đóng cứng vào hình thì không đọc được.

## 3. Tự tạo phụ đề (v0.4.0) — ĐÃ VIẾT, CHƯA BUILD
Files: `SubtitleGenModel.swift` (quy trình + SubtitleRefiner), `AudioExtractor.swift`, `Translator.swift` (TranslationBridge + `.translationHost`), `AutoSubtitleViews.swift` (sheet tạo + màn sửa), `Subtitles.swift` (thêm `original`, `SubtitleWriter.srt`), `DubbingView/Model` (nút, sheet, lọc dòng trống). `project.yml`: package WhisperKit exact 0.9.0, version 0.4.0.
Điểm dễ lỗi khi build: API WhisperKit (`WhisperKitConfig(model:)`, `DecodingOptions` gán từng thuộc tính, `transcribe(audioPath:decodeOptions:) -> [TranscriptionResult]`, `segments[].start/end/text`, `result.language`); `translationTask` closure @Sendable gọi bridge @MainActor; cần Xcode 16 cho Translation (đã bọc canImport).
Chưa làm: chỉnh mốc thời gian từng dòng, thanh % khi nhận dạng, tải model có tiến trình.

## 4. Quy ước & lưu ý kỹ thuật
- Swift 5 mode, target iOS 16: tránh API iOS 17+ (`sensoryFeedback`, `onChange` 2 tham số, `.topBarTrailing`…). Dùng `.navigationBarTrailing`, `onChange { newValue in }`.
- `@State private` trong struct → phải tự viết `init` nếu dùng từ file khác (đã gặp ở `WaveformPlayer`).
- SVG trong Asset Catalog: chỉ gradient/path/stroke; icon template đặt `template-rendering-intent`; nút nền dùng `scaledToFill` rồi clip bằng SwiftUI.
- Thêm file Swift mới không cần sửa project (xcodegen quét thư mục `CITVoice/`).
- Engine tạo giọng: `AppModel.makeEngine(store:)` → `any SpeechEngine`; nếu thiếu model/G2P sẽ trả `PlaceholderEngine` (tiếng bíp).
- Không đóng gói thêm tính năng khi chưa có phản hồi build; ưu tiên sửa lỗi CI người dùng gửi.
