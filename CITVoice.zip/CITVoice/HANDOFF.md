# HANDOFF — CITVoice iOS (đọc file này trước khi làm tiếp)

Người dùng viết tiếng Việt → trả lời tiếng Việt. Khi trả project: **đúng 1 file zip** (không chia nhỏ).
Project **CHƯA từng build/chạy thử** (không có Xcode ở môi trường làm việc). Mọi code Swift mới chỉ được kiểm tra bằng cách đếm ngoặc. Khi người dùng gửi lỗi `error:` từ CI/Xcode thì sửa ngay.

## 1. Tổng quan project
- App iOS (SwiftUI, iOS 16+, xcodegen `project.yml`, build bằng GitHub Actions → IPA chưa ký). Đọc `README.md` và đầu `CITVoice/TTSEngine.swift` để biết lộ trình engine.
- TTS tiếng Việt chạy trên máy: VieNeu v3 Nano (ONNX Runtime) + sea-g2p (Rust, `vendor/sea-g2p`). Nhân bản giọng từ ghi âm.
- Bundle id `app.citvoice.ios`, phiên bản 0.14.0.

## 2. Đã làm trong phiên này
| Hạng mục | File |
|---|---|
| Logo app (SVG → PNG 1024 không alpha) | `Logo.svg`, `CITVoice/Assets.xcassets/AppIcon.appiconset`, `AccentColor` |
| Bộ SVG vector: nền aurora (sáng/tối), banner `HeroWave`, nút `BtnPrimary`, `BtnRound(Red)`, `BtnRecord(Red)`, 13 icon `Ic*` (template) | `Assets.xcassets/*.imageset`, bản gốc `design-svg/` (sinh bằng script Python, chỉ dùng gradient/path vì actool không hỗ trợ filter/blur) |
| Thiết kế iOS: thẻ kính `Card`, `PrimaryButtonStyle`, `SoftButtonStyle`, `CircleIconButtonStyle`, `RecordButton`, `SVGIcon`, `SVGLabel`, `AuroraBackground`, `HeroBanner`, `LogoMark`, `Haptics`, `hideKeyboard()` | `Theme.swift` |
| Màn chính, chip chọn giọng, thanh dưới (tạo + trình phát) | `ContentView.swift` |
| Màn nhân bản giọng | `CloneView.swift` |
| Trình phát sóng âm (tách đỉnh từ WAV, tua bằng kéo, quầng sáng theo âm lượng) | `Waveform.swift`, `AudioPlayer.swift` (có `pause/seek/skip`, `stop()` = pause) |
| Ẩn bàn phím: chạm nền, cuộn, nút "Xong" trên bàn phím, Return ở ô tên giọng | `dismissKeyboardOnTap()`, `keyboardDoneButton()` |
| Bỏ dòng chữ phụ dư thừa | — |
| **Lồng tiếng video**: video (thư viện/Tệp) + phụ đề .srt/.vtt/dán/track nhúng → tạo giọng từng dòng, đặt đúng mốc, dòng quá dài thì tạo lại tốc độ ≤1.6x, ghép vào video (giữ âm gốc 15% hoặc tắt), xuất mp4 | `DubbingView.swift`, `DubbingModel.swift`, `DubbingExporter.swift`, `Subtitles.swift`; `AppModel.makeEngine(store:)` dùng chung engine |

Giới hạn hiện tại của lồng tiếng: video ≤ 30 phút (mix toàn bộ trong RAM, Float 24 kHz); phụ đề đóng cứng vào hình thì không đọc được.

## 3. Tự tạo phụ đề (v0.4.0) — ĐÃ VIẾT, CHƯA BUILD
Files: `SubtitleGenModel.swift` (quy trình + SubtitleRefiner), `AudioExtractor.swift`, `Translator.swift` (TranslationBridge + `.translationHost`), `AutoSubtitleViews.swift` (sheet tạo + màn sửa), `Subtitles.swift` (thêm `original`, `SubtitleWriter.srt`), `DubbingView/Model` (nút, sheet, lọc dòng trống). `project.yml`: package WhisperKit exact 0.9.0, version 0.4.0.
Điểm dễ lỗi khi build: API WhisperKit (`WhisperKitConfig(model:)`, `DecodingOptions` gán từng thuộc tính, `transcribe(audioPath:decodeOptions:) -> [TranscriptionResult]`, `segments[].start/end/text`, `result.language`); `translationTask` closure @Sendable gọi bridge @MainActor; cần Xcode 16 cho Translation (đã bọc canImport).
Chưa làm: chỉnh mốc thời gian từng dòng, thanh % khi nhận dạng, tải model có tiến trình.

## 3b. v0.7 — ĐÃ VIẾT, CHƯA BUILD
| Hạng mục | File |
|---|---|
| Tách lời khỏi nhạc nền: `StemModelStore` (tải 3 file .mlpackage từ `gyoom/UVR-MDX-CoreML`, biên dịch bằng `MLModel.compileModel`), `MixedFFT`, `MDXSpectral` (STFT/iSTFT), `StemSeparator.instrumental(...)` | `StemSeparator.swift` |
| Dùng nhạc nền đã tách thay âm gốc khi xuất | `DubbingExporter.swift` (tham số `background`), `DubbingModel.swift` (phase `.separating`, `removeVoice`), `DubbingView.swift` (công tắc + dòng tải model) |
| Tự rút ngắn câu dịch bằng Foundation Models | `LineShortener.swift`, `SubtitleGenModel.swift` (`shorten:`), `AutoSubtitleViews.swift` (công tắc + nút trong màn sửa) |
| Giấy phép | `Licenses.swift`, `THIRD_PARTY_NOTICES.md`, `Resources/LICENSE-Apache-2.0.txt`, dòng "Giấy phép & ghi công" ở `ContentView.swift` |

Điểm dễ lỗi khi build / chạy:
- `StemSeparator`: hợp đồng I/O của model lấy từ model card (input `"input"`, output `"output"`, `[1,4,3072,256]` fp16, thứ tự `[L_re, L_im, R_re, R_im]`, n_fft 6144, hop 1024, Hann tuần hoàn, center reflect, bỏ Nyquist). Nếu tiếng ra bị méo/đảo: kiểm tra chuẩn hoá STFT, thứ tự plane, hoặc thử bù biên độ (UVR có hệ số `compensate` ~1.03 cho một số model). Đã kiểm bằng Python: FFT/STFT khớp numpy ~1e-7, ghép đoạn với "model đồng nhất" tái tạo tín hiệu sai số < 1e-3. `Float16` chỉ có trên arm64 (đã bọc `#if arch(arm64)`). Strides của `MLMultiArray` được tính đến khi đọc/ghi.
- `LineShortener`: API `FoundationModels` (`SystemLanguageModel.default.availability`, `supportsLocale`, `LanguageModelSession(instructions:)`, `respond(to:options:)`) viết theo tài liệu công khai, bọc `canImport(FoundationModels)` + `#available(iOS 26.0, *)`. Cần Xcode 26 để thật sự biên dịch phần này; Xcode cũ thì tự bỏ qua (tính năng báo "chưa dùng được").
- Tải model tách nhạc: URL dạng `https://huggingface.co/gyoom/UVR-MDX-CoreML/resolve/main/UVR-MDX-NET-Inst_HQ_3.mlpackage/<Manifest.json | Data/com.apple.CoreML/model.mlmodel | Data/com.apple.CoreML/weights/weight.bin>`. Nếu repo đổi cấu trúc thì sửa `StemModelStore.files`.
- Khi thêm thành phần bên thứ ba mới: cập nhật `LicenseCatalog.items` và `THIRD_PARTY_NOTICES.md`.

## 4. Quy ước & lưu ý kỹ thuật
- Swift 5 mode, target iOS 16: tránh API iOS 17+ (`sensoryFeedback`, `onChange` 2 tham số, `.topBarTrailing`…). Dùng `.navigationBarTrailing`, `onChange { newValue in }`.
- `@State private` trong struct → phải tự viết `init` nếu dùng từ file khác (đã gặp ở `WaveformPlayer`).
- SVG trong Asset Catalog: chỉ gradient/path/stroke; icon template đặt `template-rendering-intent`; nút nền dùng `scaledToFill` rồi clip bằng SwiftUI.
- Thêm file Swift mới không cần sửa project (xcodegen quét thư mục `CITVoice/`).
- Engine tạo giọng: `AppModel.makeEngine(store:)` → `any SpeechEngine`; nếu thiếu model/G2P sẽ trả `PlaceholderEngine` (tiếng bíp).
- Không đóng gói thêm tính năng khi chưa có phản hồi build; ưu tiên sửa lỗi CI người dùng gửi.

## 5. Sửa lỗi bộ chọn file Sao lưu & khôi phục (0.7.1)
- Triệu chứng: ở "Nhập giọng"/"Khôi phục model" file .json bị mờ, không chọn được.
- Sửa `Backup.swift`: tách thành 2 `.filePicker` độc lập (`importingVoices`, `importingModel`) thay cho 1 bộ chọn đổi loại theo `importKind`; Nhập giọng nhận `.json/.plainText/.text/.data/.content/.item` (nội dung kiểm tra ở `VoiceFileIO.decode`); Khôi phục model vẫn chỉ `.folder` (chọn thư mục `CITVoice-Model`, bấm "Mở"). Chưa build thử.
- 0.7.2 `FilePicker.swift`: `.filePicker` không còn dùng `.sheet` của SwiftUI; mở `UIDocumentPickerViewController` trực tiếp từ UIKit (view controller trên cùng), file dùng `asCopy: true` (hệ thống chép file về tạm), thư mục (`[.folder]`) dùng `asCopy: false`. Lý do: ở màn Nhân bản giọng chạm file không chọn được dù không bị mờ. Chưa build thử.

## 6. v0.8.0 — nhịp đọc / nhiều đoạn / lịch sử / M4A (ĐÃ VIẾT, CHƯA BUILD)
| Hạng mục | File |
|---|---|
| `PauseProfile` (nghỉ đoạn/câu/phẩy), `PacingPreset` (Chuẩn/Kể chuyện/Tiên hiệp) | `Pacing.swift` |
| `SynthesisOptions.pauses` + `.normalize`; `NanoEngine` dùng `options.pauses` thay `AudioUtils.gapSilence`, chỉ chuẩn hoá âm lượng khi `normalize == true` (mặc định true nên Lồng tiếng không đổi) | `TTSEngine.swift`, `NanoEngine.swift` |
| Tạo theo từng đoạn (tách theo dòng), `statusText`, giữ phần đã tạo khi huỷ, `importText`, lưu UserDefaults (`pacing.*`) | `AppModel.swift` |
| `HistoryStore` (tối đa 30 bản, WAV + index.json), `HistoryView`, `ExportMenu` (WAV/M4A) | `History.swift` |
| WAV → M4A bằng `AVAudioFile` (AAC 64 kbps), `SharePresenter` | `AudioExporter.swift` |
| UI: bộ cài sẵn nhịp đọc, thanh ngắt nghỉ, nút "Mở .txt", mục Lịch sử, nhãn "Đoạn i/n" | `ContentView.swift`; `Waveform.swift` dùng `ExportMenu` thay `ShareLink` |
Điểm dễ lỗi khi build: `AVAudioFile(forWriting:settings:commonFormat:interleaved:)` với AAC 64 kbps ở 24 kHz mono (nếu lỗi thử 48 kbps hoặc dùng AVAssetWriter); `ShareLink` trong `Menu`; `$model.pauses.paragraph` (Binding lồng) trong `ContentView`. Giá trị preset (tốc độ 0.95/0.9, nghỉ 0.9/1.2 s…) là ước lượng, CHƯA nghe thử — chỉnh theo phản hồi của người dùng. MP3 chưa làm (cần LAME).

## 7. v0.9.0 — khớp khung lồng tiếng (ĐÃ VIẾT, CHƯA BUILD)
| Hạng mục | File |
|---|---|
| `DubFit` (ký tự/giây, `learnedCPS` lưu `dub.cps1`, `forecast`, `rms`, `leveled`), `RateTracker`, `DubCueReport` | `DubFit.swift` |
| Vòng tạo giọng mới: `AudioUtils.trimAndFade` → đo độ dài → tối đa 2 lần tăng tốc → cân bằng âm lượng; `tightLines`, `speedUpCount` | `DubbingModel.swift` |
| Dự báo ở thẻ Phụ đề (`forecastNote`), danh sách dòng quá dài ở thẻ Kết quả | `DubbingView.swift` |
| Mục ghi công VoiceStudio (`LicenseKind.agpl3`) | `Licenses.swift`, `THIRD_PARTY_NOTICES.md` |
Nguồn ý tưởng: VoiceStudio (debpalash/VoiceStudio, AGPL-3.0) — chỉ tham khảo, KHÔNG chép mã. Người dùng dùng cá nhân, muốn ghi giấy phép/nguồn nếu chia sẻ ra ngoài (đã làm). Ý tưởng chưa làm: engine thứ hai Supertonic-3 (ONNX, có tiếng Việt, giấy phép OpenRAIL — cần xem điều khoản), xuất phụ đề karaoke.
Điểm dễ lỗi khi build: `String(format:)` lồng trong nội suy chuỗi ở `DubbingView`; `let` trong `@ViewBuilder forecastNote`; `AudioUtils.trimAndFade` có thể trả mảng rỗng (đã `continue`).

## 8. v0.10.0 — bộ nhớ đệm dòng + phụ đề khớp giọng (ĐÃ VIẾT, CHƯA BUILD)
- `DubCache` (trong `DubFit.swift`, dùng CryptoKit SHA256): khoá = chữ + id giọng + dấu vân tay speakerEmb + steps/cfg/sway/baseSpeed + khung (làm tròn 0.05s) + sr; tệp `Caches/DubCache/<key>.f32` (Float32: tốc độ rồi mẫu âm, đã cắt im lặng, CHƯA cân bằng âm lượng). `trim(maxMB: 400)`, `clear()`, `sizeMB`.
- `DubbingModel`: nhánh cache-hit/miss trong vòng tạo giọng; `cachedCount`, `fittedSRT` (ghi `phu-de-khop-giong.srt` ở thư mục tạm), `clearCache()`, `cacheMB`.
- `DubbingView`: dòng "dùng lại N dòng", nút chia sẻ .srt khớp giọng, dòng bộ nhớ đệm + nút Xoá ở `optionsCard`.
- Điểm dễ lỗi: `floats.withUnsafeMutableBytes { data.copyBytes(to: $0) }`; `Data(buffer:)`; init memberwise `SubtitleCue(index:start:end:text:)`.

## 9. v0.11.0 — engine Supertonic-3 (ĐÃ VIẾT, CHƯA BUILD, CHƯA NGHE THỬ)
- Nguồn tham chiếu: repo `supertonic` (py/helper.py, ios/ExampleiOSApp). Zip người dùng gửi bị cắt cụt (thiếu `swift/Sources`), nên engine được viết theo `py/helper.py`. Model: `supertone-oss-archive/supertonic-3` @ `aafc6e32416a594460b32413efc49d7fe4ce6d46`, file `onnx/{tts.json,unicode_indexer.json,duration_predictor,text_encoder,vector_estimator,vocoder}` + `voice_styles/{M1..M5,F1..F5}.json` (chỉ M1, F1 bắt buộc).
- Đầu vào ONNX (theo helper.py): DP `text_ids,style_dp,text_mask`; TextEnc `text_ids,style_ttl,text_mask`; VectorEst `noisy_latent,text_emb,style_ttl,text_mask,latent_mask,current_step,total_step` (lặp `steps` lần, đưa ngược đầu ra vào `noisy_latent`); Vocoder `latent`. Mặt nạ là float, dạng [1,1,L]. Văn bản: NFKD, bỏ emoji, quy tắc thay thế, bọc `<vi>…</vi>`, mã Unicode → `unicode_indexer`.
- `Voice` có thêm `engine` ("vieneu"|"supertonic") và `preset`; giọng Supertonic có `speakerEmb`/`style` rỗng. `RouterEngine` chọn engine theo `voice.engine`; `AppModel.makeEngine` là điểm duy nhất tạo engine (cả `generate` và lồng tiếng). `AppModel.syncSupertonicVoices()` thêm/bớt giọng khi tải/xoá model.
- Điểm dễ lỗi khi build: `String(String.UnicodeScalarView(...filter...))` trong `preprocess`; `try` trong `init` của `SupertonicEngine` khi gán `let`; các tên đầu vào/ra ONNX nếu model bản ghim khác `helper.py`; mặt nạ bool trên ONNX Runtime iOS (VieNeu phải vá `OnnxBoolPatch`, Supertonic dùng float nên chưa cần).
- Chưa làm: chọn ngôn ngữ khác `vi`, nhân bản giọng Supertonic, thẻ thông báo khi giọng Supertonic được chọn mà model chưa cài (hiện báo lỗi "Cần tải model Supertonic-3 trước").

## 10. v0.12.0 — phụ đề karaoke .ass (ĐÃ VIẾT, CHƯA BUILD)
- `KaraokeASS.build(_ cues:)` (file `KaraokeASS.swift`): tiêu đề + 1 style, mỗi dòng 1 `Dialogue` với `{\kf<cs>}từ`. Trọng số từ = số ký tự chữ/số, +2 sau `, ; :`, +4 sau `. ! ? …`. Độ dài thẻ = hiệu các mốc đã làm tròn centi giây, tối thiểu 1.
- `DubbingModel.karaokeASS` được ghi sau khi tạo giọng (từ `fitted`, cùng nguồn với `fittedSRT`); `DubbingView` có nút ShareLink thứ hai.
- Điểm dễ lỗi khi build: chuỗi nhiều dòng `"""` (thụt lề phải bằng dòng đóng), `String(format:)` với `Int`.
- Chưa làm: đốt phụ đề vào video, đổi font/màu trong giao diện (có sẵn `KaraokeASS.Style`), karaoke cho màn phụ đề tự động.

## 11. v0.13.0 — video karaoke (ĐÃ VIẾT, CHƯA BUILD, CHƯA CHẠY THỬ)
- `KaraokeVideoExporter.export(video:cues:style:)`: `AVMutableVideoComposition(asset:applyingCIFiltersWithHandler:)` (đã deprecated từ iOS 16 nhưng còn dùng được, chỉ cảnh báo) → mỗi khung: tìm dòng đang hiện (nhị phân theo `starts`), lấy `KaraokeOverlay` từ `KaraokeOverlayCache` (≤6 dòng), ghép bản trắng + các vùng bản màu đã quét (`highlightRects(at:)`), đặt ở đáy cách mép dưới 8% chiều cao. Xuất `AVAssetExportSession` HighestQuality, giữ nguyên âm thanh video đầu vào.
- `KaraokeOverlay.make`: chia dòng theo 88% chiều rộng, cỡ chữ = 4,5% chiều cao × hệ số, vẽ bằng `UIGraphicsImageRenderer` (scale 1), viền đen `strokeWidth -6`. Mốc từ lấy từ `KaraokeASS.wordTimings`.
- `DubbingModel`: `fittedCues` (riêng tư), `hasFittedCues`, `makeKaraokeVideo(style:)`, `cancelKaraoke()`, `karaokeVideoURL/Progress/Error`. `KaraokeVideoSection` hiện khi có `outputURL` + dòng đã khớp.
- Điểm dễ lỗi/sai: toạ độ gốc (UIKit trên-trái ↔ Core Image dưới-trái; đã đổi trong `highlightRects`), `withTaskCancellationHandler` trong hàm async, hiệu năng video dài/độ phân giải cao (chưa đo), cảnh báo concurrency vì `KaraokeVideoStyle` chứa `UIColor`.
- Chưa làm: tạo video karaoke từ chỉ văn bản + giọng (không có video gốc, nền màu/ảnh), đổi font, vị trí chữ, hiệu ứng vào/ra.

## 12. v0.14.0 — video karaoke chỉ từ văn bản + giọng (ĐÃ VIẾT, CHƯA BUILD, CHƯA CHẠY THỬ)
- `KaraokeRenderer` (trong `KaraokeVideo.swift`) tách ra dùng chung: `frame(at:over:)`, `Placement .bottom/.center`, `holdUntilNext`. `KaraokeVideoExporter` (có video gốc) giờ gọi renderer này.
- `KaraokeSceneExporter.export`: WAV → M4A (`AudioExporter.m4a`) → `AVAssetWriter` + `AVAssetWriterInputPixelBufferAdaptor` (BGRA, H.264 5 Mbps, 30 fps) vẽ khung bằng `CIContext.render` → `AVMutableComposition` (hình + M4A) → `AVAssetExportSession` Passthrough → .mp4. `RenderState` là cờ dùng chung với hàng đợi vẽ; huỷ qua `withTaskCancellationHandler`.
- `KaraokeCueBuilder.cues(from:maxChars:)`: đoạn → câu (`(?<=[.!?…])\s+`) → dấu phẩy → theo từ; thời gian chia theo số ký tự (+6 sau câu, +3 sau dấu phẩy). `SpeechTiming` được `AppModel.generate` ghi vào `lastTimings` (mốc theo mẫu âm thanh trước khi chuẩn hoá, chiều dài không đổi).
- UI: `KaraokeSceneCard` (nền preset hoặc `PhotosPicker`), `KaraokeSceneModel` (@MainActor). Chỉ hiện khi có `outputURL` + `lastTimings` và không đang tạo giọng.
- Điểm dễ lỗi/sai: `while input.isReadyForMoreMediaData` với `continue` khi chưa có pool (có thể quay rỗng nếu pool nil), toạ độ chữ ở giữa khung, hiệu năng 1080p, chữ dài vượt khung dọc (`maxChars` 70 dọc / 90 ngang), giọng đọc có ngắt nghỉ `[nghỉ Xs]` lệch mốc.
- Chưa làm: video karaoke từ lịch sử bản đọc cũ, hiệu ứng vào/ra của dòng, đổi font, đếm ngược đầu video.
