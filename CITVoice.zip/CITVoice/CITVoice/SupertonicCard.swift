import SwiftUI

/// Thẻ tải model giọng Supertonic-3 (tuỳ chọn, thêm 10 giọng nam/nữ để so với VieNeu).
struct SupertonicCard: View {
    @ObservedObject var store: SupertonicStore

    var body: some View {
        Card {
            switch store.state {
            case .ready:
                HStack(spacing: 12) {
                    IconBadge(systemName: "checkmark.seal.fill", color: .green)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Supertonic-3 · Đã cài").font(.body.weight(.semibold))
                        Text("Chọn giọng \"Supertonic …\" ở thẻ Giọng đọc.").font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    Menu {
                        Button(role: .destructive) { store.deleteModel() } label: {
                            Label("Xoá model Supertonic", systemImage: "trash")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle").font(.title3).foregroundStyle(.secondary)
                    }
                }
            case .downloading:
                HStack(spacing: 12) {
                    IconBadge(systemName: "arrow.down.circle.fill")
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Đang tải Supertonic-3…").font(.body.weight(.semibold))
                        Text(store.statusText).font(.footnote).foregroundStyle(.secondary)
                    }
                }
                ProgressView(value: store.fileProgress).tint(Brand.indigo)
            case .notInstalled:
                HStack(spacing: 12) {
                    IconBadge(systemName: "waveform.badge.plus")
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Thêm giọng Supertonic-3 (tuỳ chọn)").font(.body.weight(.semibold))
                        Text("Model thứ hai chạy trên máy, có tiếng Việt, vài trăm MB. Giọng nam/nữ có sẵn, chưa nhân bản được.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Button {
                    Haptics.tap()
                    Task { await store.download() }
                } label: {
                    Label("Tải Supertonic-3", systemImage: "arrow.down.circle").frame(maxWidth: .infinity)
                }
                .buttonStyle(SoftButtonStyle())
            case .failed(let msg):
                HStack(spacing: 12) {
                    IconBadge(systemName: "exclamationmark.triangle.fill", color: .red)
                    Text(msg).font(.footnote).foregroundStyle(.red)
                }
                Button {
                    Task { await store.download() }
                } label: {
                    Label("Thử lại", systemImage: "arrow.clockwise").frame(maxWidth: .infinity)
                }
                .buttonStyle(SoftButtonStyle())
            }
        }
    }
}
