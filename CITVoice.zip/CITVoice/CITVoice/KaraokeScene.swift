import AVFoundation
import CoreImage
import UIKit

// =============================================================================
//  KaraokeScene (v0.14) — video karaoke chỉ từ văn bản + giọng đọc, không cần video gốc:
//  nền (màu chuyển sắc hoặc ảnh) + chữ từng từ sáng dần theo giọng + âm thanh vừa tạo.
//  Ý TƯỞNG karaoke từng từ tham khảo VoiceStudio (AGPL-3.0); mã tự viết (Core Graphics / Core Image / AVAssetWriter).
// =============================================================================

/// Mốc thời gian của một đoạn đã đọc (giây, theo file âm thanh vừa tạo).
struct SpeechTiming {
    let text: String
    let start: Double
    let end: Double
}

enum KaraokeCueBuilder {
    /// Chia mỗi đoạn thành các cụm ngắn vừa màn hình (theo câu, rồi theo dấu phẩy / theo từ nếu còn dài).
    /// Thời gian của đoạn được chia theo số ký tự (cộng thêm một chút sau dấu ngắt).
    static func cues(from timings: [SpeechTiming], maxChars: Int) -> [SubtitleCue] {
        var out: [SubtitleCue] = []
        for t in timings {
            let clean = PauseTags.split(t.text).map { $0.0 }.joined(separator: " ")
                .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, t.end > t.start else { continue }
            let pieces = split(clean, maxChars: maxChars)
            let weights = pieces.map { p -> Double in
                var w = Double(max(p.count, 1))
                if let last = p.last, ".!?…".contains(last) { w += 6 } else if let last = p.last, ",;:".contains(last) { w += 3 }
                return w
            }
            let total = max(weights.reduce(0, +), 1)
            var acc = 0.0
            for (i, p) in pieces.enumerated() {
                let a = t.start + (t.end - t.start) * acc / total
                acc += weights[i]
                let b = t.start + (t.end - t.start) * acc / total
                out.append(SubtitleCue(index: out.count + 1, start: a, end: b, text: p))
            }
        }
        return out
    }

    private static func split(_ text: String, maxChars: Int) -> [String] {
        var result: [String] = []
        for sentence in splitKeeping(text, pattern: "(?<=[.!?…])\\s+") {
            if sentence.count <= maxChars { result.append(sentence); continue }
            var cur = ""
            for part in splitKeeping(sentence, pattern: "(?<=[,;:])\\s+") {
                if part.count > maxChars {
                    if !cur.isEmpty { result.append(cur); cur = "" }
                    result.append(contentsOf: byWords(part, maxChars: maxChars))
                } else if cur.isEmpty {
                    cur = part
                } else if cur.count + 1 + part.count <= maxChars {
                    cur += " " + part
                } else {
                    result.append(cur); cur = part
                }
            }
            if !cur.isEmpty { result.append(cur) }
        }
        return result
    }

    private static func splitKeeping(_ text: String, pattern: String) -> [String] {
        guard let re = try? NSRegularExpression(pattern: pattern) else { return [text] }
        let ns = text as NSString
        var out: [String] = []
        var pos = 0
        for m in re.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            let s = ns.substring(with: NSRange(location: pos, length: m.range.location - pos))
            if !s.isEmpty { out.append(s) }
            pos = m.range.location + m.range.length
        }
        let tail = ns.substring(from: pos)
        if !tail.isEmpty { out.append(tail) }
        return out
    }

    private static func byWords(_ text: String, maxChars: Int) -> [String] {
        var out: [String] = []
        var cur = ""
        for w in text.split(separator: " ", omittingEmptySubsequences: true) {
            if cur.count + 1 + w.count > maxChars, !cur.isEmpty { out.append(cur); cur = String(w) }
            else { cur += (cur.isEmpty ? "" : " ") + w }
        }
        if !cur.isEmpty { out.append(cur) }
        return out
    }
}

struct KaraokeBackground {
    var colors: [UIColor]
    var image: UIImage? = nil

    static let presets: [(name: String, colors: [UIColor])] = [
        ("Tím đêm", [UIColor(red: 0.17, green: 0.06, blue: 0.33, alpha: 1), UIColor(red: 0.46, green: 0.59, blue: 0.87, alpha: 1)]),
        ("Xanh biển", [UIColor(red: 0.06, green: 0.12, blue: 0.15, alpha: 1), UIColor(red: 0.17, green: 0.33, blue: 0.39, alpha: 1)]),
        ("Hồng sen", [UIColor(red: 0.26, green: 0.15, blue: 0.35, alpha: 1), UIColor(red: 0.75, green: 0.42, blue: 0.52, alpha: 1)]),
        ("Đen", [UIColor(white: 0.0, alpha: 1), UIColor(white: 0.12, alpha: 1)]),
    ]

    func render(size: CGSize) -> CIImage? {
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            let cg = ctx.cgContext
            if let image {
                // phủ kín khung (aspect fill), rồi tối nhẹ để chữ dễ đọc
                let s = max(size.width / image.size.width, size.height / image.size.height)
                let w = image.size.width * s, h = image.size.height * s
                image.draw(in: CGRect(x: (size.width - w) / 2, y: (size.height - h) / 2, width: w, height: h))
                cg.setFillColor(UIColor.black.withAlphaComponent(0.42).cgColor)
                cg.fill(CGRect(origin: .zero, size: size))
            } else {
                let cs = CGColorSpaceCreateDeviceRGB()
                let cols = colors.map { $0.cgColor } as CFArray
                if let g = CGGradient(colorsSpace: cs, colors: cols, locations: nil) {
                    cg.drawLinearGradient(g, start: .zero, end: CGPoint(x: size.width * 0.3, y: size.height), options: [])
                }
            }
        }
        guard let cg = img.cgImage else { return nil }
        return CIImage(cgImage: cg)
    }
}

/// Cờ dùng chung giữa hàng đợi vẽ khung hình và tác vụ huỷ.
private final class RenderState: @unchecked Sendable {
    var frame = 0
    var cancelled = false
    var done = false
}

enum KaraokeSceneExporter {
    static let fps = 30

    /// `audio`: file WAV vừa tạo. `cues`: các cụm chữ đã có mốc thời gian theo file đó.
    static func export(cues: [SubtitleCue], audio wav: URL, size: CGSize, background: KaraokeBackground,
                       style: KaraokeVideoStyle,
                       onProgress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        let m4a = try await AudioExporter.m4a(from: wav)
        let audioAsset = AVURLAsset(url: m4a)
        let duration = try await audioAsset.load(.duration).seconds
        guard duration > 0.2 else { throw DubError.noDubAudio }
        guard let renderer = KaraokeRenderer(cues: cues, style: style, placement: .center, holdUntilNext: true) else {
            throw DubError.export("không có dòng chữ nào để vẽ")
        }
        guard let bg = background.render(size: size) else { throw DubError.export("không dựng được nền") }

        let stamp = Int(Date().timeIntervalSince1970)
        let silent = FileManager.default.temporaryDirectory.appendingPathComponent("cit-karaoke-hinh-\(stamp).mp4")
        try? FileManager.default.removeItem(at: silent)

        // 1) Hình: vẽ từng khung (nền + chữ) bằng AVAssetWriter
        let writer = try AVAssetWriter(outputURL: silent, fileType: .mp4)
        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: Int(size.width),
            AVVideoHeightKey: Int(size.height),
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: 5_000_000,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
            ],
        ]
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        input.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: input,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: Int(size.width),
                kCVPixelBufferHeightKey as String: Int(size.height),
            ])
        guard writer.canAdd(input) else { throw DubError.export("không thêm được luồng hình") }
        writer.add(input)
        guard writer.startWriting() else {
            throw DubError.export(writer.error?.localizedDescription ?? "không bắt đầu ghi được")
        }
        writer.startSession(atSourceTime: .zero)

        let total = max(1, Int((duration * Double(fps)).rounded(.up)))
        let state = RenderState()
        let ctx = CIContext()
        let bounds = CGRect(origin: .zero, size: size)
        let space = CGColorSpaceCreateDeviceRGB()

        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
                let queue = DispatchQueue(label: "cit.karaoke.render")
                input.requestMediaDataWhenReady(on: queue) {
                    while input.isReadyForMoreMediaData, !state.done {
                        if state.cancelled {
                            state.done = true
                            input.markAsFinished()
                            writer.cancelWriting()
                            cont.resume(throwing: CancellationError())
                            return
                        }
                        if writer.status == .failed {
                            state.done = true
                            cont.resume(throwing: DubError.export(writer.error?.localizedDescription ?? "ghi hình lỗi"))
                            return
                        }
                        if state.frame >= total {
                            state.done = true
                            input.markAsFinished()
                            cont.resume()
                            return
                        }
                        guard let pool = adaptor.pixelBufferPool else { continue }
                        var pb: CVPixelBuffer?
                        guard CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, pool, &pb) == kCVReturnSuccess,
                              let buffer = pb else { continue }
                        let t = Double(state.frame) / Double(fps)
                        ctx.render(renderer.frame(at: t, over: bg), to: buffer, bounds: bounds, colorSpace: space)
                        adaptor.append(buffer, withPresentationTime: CMTime(value: Int64(state.frame), timescale: Int32(fps)))
                        state.frame += 1
                        if state.frame % 15 == 0 { onProgress(0.85 * Double(state.frame) / Double(total)) }
                    }
                }
            }
        } onCancel: {
            state.cancelled = true
        }
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in writer.finishWriting { c.resume() } }
        guard writer.status == .completed else {
            throw DubError.export(writer.error?.localizedDescription ?? "không hoàn tất file hình")
        }

        // 2) Ghép hình + âm thanh (không mã hoá lại)
        let videoAsset = AVURLAsset(url: silent)
        guard let vTrack = try await videoAsset.loadTracks(withMediaType: .video).first else { throw DubError.noVideoTrack }
        guard let aTrack = try await audioAsset.loadTracks(withMediaType: .audio).first else { throw DubError.noDubAudio }
        let vDur = try await videoAsset.load(.duration)
        let aDur = try await audioAsset.load(.duration)
        let comp = AVMutableComposition()
        guard let cv = comp.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let ca = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw DubError.export("không tạo được luồng ghép")
        }
        try cv.insertTimeRange(CMTimeRange(start: .zero, duration: vDur), of: vTrack, at: .zero)
        try ca.insertTimeRange(CMTimeRange(start: .zero, duration: CMTimeMinimum(aDur, vDur)), of: aTrack, at: .zero)

        guard let session = AVAssetExportSession(asset: comp, presetName: AVAssetExportPresetPassthrough) else {
            throw DubError.export("không tạo được phiên xuất")
        }
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("cit-karaoke-video-\(stamp).mp4")
        try? FileManager.default.removeItem(at: out)
        session.outputURL = out
        session.outputFileType = .mp4
        session.shouldOptimizeForNetworkUse = true
        let poll = Task {
            while !Task.isCancelled {
                onProgress(0.85 + 0.15 * Double(session.progress))
                try? await Task.sleep(nanoseconds: 300_000_000)
            }
        }
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            session.exportAsynchronously { cont.resume() }
        }
        poll.cancel()
        try? FileManager.default.removeItem(at: silent)
        guard session.status == .completed else {
            throw DubError.export(session.error?.localizedDescription ?? "không rõ nguyên nhân")
        }
        onProgress(1)
        return out
    }
}

// MARK: - Trạng thái giao diện

@MainActor
final class KaraokeSceneModel: ObservableObject {
    @Published var isMaking = false
    @Published var progress = 0.0
    @Published var videoURL: URL?
    @Published var error: String?
    private var task: Task<Void, Never>?

    func make(timings: [SpeechTiming], audio: URL, portrait: Bool, background: KaraokeBackground, style: KaraokeVideoStyle) {
        guard !isMaking else { return }
        isMaking = true
        progress = 0
        error = nil
        videoURL = nil
        let size = portrait ? CGSize(width: 1080, height: 1920) : CGSize(width: 1920, height: 1080)
        let cues = KaraokeCueBuilder.cues(from: timings, maxChars: portrait ? 70 : 90)
        task = Task { [weak self] in
            defer { self?.isMaking = false; self?.task = nil }
            do {
                let url = try await KaraokeSceneExporter.export(cues: cues, audio: audio, size: size,
                                                                background: background, style: style) { p in
                    Task { @MainActor in self?.progress = p }
                }
                self?.videoURL = url
            } catch is CancellationError {
                // người dùng bấm Huỷ
            } catch {
                self?.error = error.localizedDescription
            }
        }
    }

    func cancel() { task?.cancel() }

    func reset() {
        videoURL = nil
        error = nil
    }
}
