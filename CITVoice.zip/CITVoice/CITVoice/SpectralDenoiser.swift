import Foundation

/// Khử tạp âm nền ổn định (tiếng xì, ù, quạt, ồn phòng) cho giọng mẫu — thuật toán Wiener/spectral gating, tự viết, chạy hoàn toàn trên máy.
/// Ước lượng mẫu tạp âm từ những khung nhỏ nhất của chính clip, rồi giảm các tần số có năng lượng gần mức ồn.
/// Không cần model tải thêm. Không xử lý được nhạc/tiếng người khác (dùng "Tách tiếng nói khỏi nhạc nền" cho trường hợp đó).
enum SpectralDenoiser {
    /// - strength: 0…1 (mức khử; 0.6 vừa phải, cao quá làm giọng "méo").
    static func denoise(_ x: [Float], sr: Int, strength: Float = 0.6) -> [Float] {
        let nFFT = sr > 24_000 ? 2048 : 1024
        let hop = nFFT / 4
        guard x.count > nFFT * 4 else { return x }
        let bins = nFFT / 2 + 1

        // Cửa sổ Hann (periodic); tổng bình phương chồng để chuẩn hoá khi ghép
        var win = [Float](repeating: 0, count: nFFT)
        for i in 0..<nFFT { win[i] = 0.5 - 0.5 * cosf(2 * .pi * Float(i) / Float(nFFT)) }

        let pad = nFFT
        var xp = [Float](repeating: 0, count: x.count + 2 * pad)
        for i in 0..<x.count { xp[pad + i] = x[i] }
        let nFrames = (xp.count - nFFT) / hop + 1

        let fft = FFT(n: nFFT)
        var re = [[Float]](repeating: [], count: nFrames)
        var im = [[Float]](repeating: [], count: nFrames)
        var energy = [Float](repeating: 0, count: nFrames)

        var bufR = [Float](repeating: 0, count: nFFT)
        var bufI = [Float](repeating: 0, count: nFFT)
        for f in 0..<nFrames {
            let s = f * hop
            for i in 0..<nFFT { bufR[i] = xp[s + i] * win[i]; bufI[i] = 0 }
            fft.transform(&bufR, &bufI, inverse: false)
            re[f] = Array(bufR[0..<bins]); im[f] = Array(bufI[0..<bins])
            var e: Float = 0
            for k in 0..<bins { e += re[f][k] * re[f][k] + im[f][k] * im[f][k] }
            energy[f] = e
        }

        // Mẫu tạp âm: trung bình công suất của 12% khung yếu nhất (bỏ khung im lặng tuyệt đối)
        let order = (0..<nFrames).sorted { energy[$0] < energy[$1] }
        let take = max(4, nFrames * 12 / 100)
        var noise = [Float](repeating: 0, count: bins)
        for f in order.prefix(take) {
            for k in 0..<bins { noise[k] += re[f][k] * re[f][k] + im[f][k] * im[f][k] }
        }
        for k in 0..<bins { noise[k] = noise[k] / Float(take) + 1e-12 }

        let alpha = 1 + 1.5 * strength            // mức trừ quá
        let gmin = powf(10, -(8 + 22 * strength) / 20)   // sàn độ lợi: -8…-30 dB
        var prevGain = [Float](repeating: 1, count: bins)
        var out = [Float](repeating: 0, count: xp.count)
        var wsum = [Float](repeating: 0, count: xp.count)
        var gain = [Float](repeating: 1, count: bins)
        var sm = [Float](repeating: 1, count: bins)

        for f in 0..<nFrames {
            for k in 0..<bins {
                let p = re[f][k] * re[f][k] + im[f][k] * im[f][k] + 1e-12
                gain[k] = max(gmin, 1 - alpha * noise[k] / p)
            }
            // làm mượt theo tần số (3 điểm) rồi theo thời gian (nhanh khi mở, chậm khi đóng) → ít "tiếng chuông" hơn
            for k in 0..<bins {
                let a = gain[max(0, k - 1)], b = gain[k], c = gain[min(bins - 1, k + 1)]
                sm[k] = 0.25 * a + 0.5 * b + 0.25 * c
                let up = sm[k] > prevGain[k]
                let w: Float = up ? 0.2 : 0.65
                sm[k] = w * prevGain[k] + (1 - w) * sm[k]
                prevGain[k] = sm[k]
            }
            for k in 0..<bins {
                bufR[k] = re[f][k] * sm[k]; bufI[k] = im[f][k] * sm[k]
            }
            for k in 1..<(nFFT - bins + 1) {                       // đối xứng liên hợp
                bufR[nFFT - k] = bufR[k]; bufI[nFFT - k] = -bufI[k]
            }
            fft.transform(&bufR, &bufI, inverse: true)
            let s = f * hop
            for i in 0..<nFFT {
                out[s + i] += bufR[i] * win[i]
                wsum[s + i] += win[i] * win[i]
            }
        }
        var y = [Float](repeating: 0, count: x.count)
        for i in 0..<x.count {
            let w = wsum[pad + i]
            y[i] = w > 1e-6 ? out[pad + i] / w : 0
        }
        return y
    }

    /// FFT phức cơ số 2 tại chỗ (n là luỹ thừa của 2).
    final class FFT {
        let n: Int
        private var cosT: [Float], sinT: [Float], rev: [Int]
        init(n: Int) {
            self.n = n
            cosT = (0..<(n / 2)).map { cosf(2 * .pi * Float($0) / Float(n)) }
            sinT = (0..<(n / 2)).map { sinf(2 * .pi * Float($0) / Float(n)) }
            var bits = 0; while (1 << bits) < n { bits += 1 }
            rev = (0..<n).map { i in
                var r = 0, v = i
                for _ in 0..<bits { r = (r << 1) | (v & 1); v >>= 1 }
                return r
            }
        }
        func transform(_ re: inout [Float], _ im: inout [Float], inverse: Bool) {
            for i in 0..<n {
                let j = rev[i]
                if j > i { re.swapAt(i, j); im.swapAt(i, j) }
            }
            var size = 2
            while size <= n {
                let half = size / 2, step = n / size
                var start = 0
                while start < n {
                    for k in 0..<half {
                        let c = cosT[k * step]
                        let s = inverse ? sinT[k * step] : -sinT[k * step]
                        let a = start + k, b = a + half
                        let tr = re[b] * c - im[b] * s
                        let ti = re[b] * s + im[b] * c
                        re[b] = re[a] - tr; im[b] = im[a] - ti
                        re[a] += tr; im[a] += ti
                    }
                    start += size
                }
                size <<= 1
            }
            if inverse {
                let inv = 1 / Float(n)
                for i in 0..<n { re[i] *= inv; im[i] *= inv }
            }
        }
    }
}
