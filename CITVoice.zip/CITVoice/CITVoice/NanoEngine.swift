import Foundation

/// Cấu hình đọc từ config.json của model v3 Nano.
struct NanoConfig {
    let vocab: [String: Int]            // ký tự (1 code point) → id
    let bos: Int, eos: Int, pad: Int
    let emotionTags: [String: String]   // "<|emotion_k|>" → ký tự trong vocab
    let fps: Double
    static func load(from url: URL) throws -> NanoConfig {
        let obj = try JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any] ?? [:]
        guard let v = obj["vocab"] as? [String: Any] else { throw TTSError.notImplemented("config.json thiếu vocab") }
        var vocab: [String: Int] = [:]
        for (k, x) in v { if let n = x as? Int { vocab[k] = n } }
        func int(_ k: String) throws -> Int {
            guard let n = obj[k] as? Int else { throw TTSError.notImplemented("config.json thiếu \(k)") }
            return n
        }
        return NanoConfig(vocab: vocab, bos: try int("bos_id"), eos: try int("eos_id"), pad: try int("pad_id"),
                          emotionTags: obj["emotion_tags"] as? [String: String] ?? [:],
                          fps: (obj["flow_fps"] as? Double) ?? (24000.0 / 256.0 / 6.0))
    }
}

#if canImport(OnnxRuntimeBindings)
import OnnxRuntimeBindings

/// Engine v3 Nano chạy bằng ONNX Runtime — port của `OnnxV3NanoEngine` + `V3NanoVieNeuTTS.infer` (v3nano.py).
/// Không tạo watermark (bản Python có `apply_watermark`, ở đây chưa làm).
final class NanoEngine: SpeechEngine, @unchecked Sendable {
    let sampleRate = 24_000
    private let cfg: NanoConfig
    private let g2p: SeaG2P
    private let env: ORTEnv
    private let sText: ORTSession, sDur: ORTSession, sVE: ORTSession, sDec: ORTSession
    private let oText: String, oDur: String, oVE: String, oDec: String
    private let nullSpk: ORTValue, nullStyle: ORTValue, nullCtx: ORTValue, nullMask: ORTValue
    private let maxChunkSeconds = 15.0

    init(directory: URL, g2p: SeaG2P, threads: Int = 3) throws {
        self.g2p = g2p
        cfg = try NanoConfig.load(from: directory.appendingPathComponent("config.json"))
        let consts = try NPZ.load(url: directory.appendingPathComponent("constants.npz"))
        guard let ns = consts["null_spk"], let nst = consts["null_style"] else {
            throw TTSError.notImplemented("constants.npz thiếu null_spk / null_style")
        }
        let environment = try ORTEnv(loggingLevel: .warning)
        let opts = try ORTSessionOptions()
        try opts.setIntraOpNumThreads(Int32(threads))
        func open(_ f: String) throws -> ORTSession {
            try ORTSession(env: environment, modelPath: directory.appendingPathComponent(f).path, sessionOptions: opts)
        }
        let text = try open("text_encoder.onnx")
        let dur = try open("duration_predictor.onnx")
        let ve = try open("vector_estimator.onnx")
        let dec = try open("codec_decoder.onnx")
        let textOut = try text.outputNames().first ?? "ctx"
        let style0 = try Self.tensor(nst.data, [1] + nst.shape, .float)
        let ids0: [Int64] = [Int64(cfg.bos), Int64(cfg.eos)]
        guard let ctx0 = try text.run(withInputs: ["ids": try Self.tensor(ids0, [1, 2], .int64), "style": style0],
                                      outputNames: [textOut], runOptions: nil)[textOut] else {
            throw TTSError.notImplemented("text_encoder không trả về ngữ cảnh rỗng")
        }

        env = environment
        sText = text; sDur = dur; sVE = ve; sDec = dec
        oText = textOut
        oDur = try dur.outputNames().first ?? "log_s"
        oVE = try ve.outputNames().first ?? "v"
        oDec = try dec.outputNames().first ?? "wav"
        nullSpk = try Self.tensor(ns.data, [1, ns.data.count], .float)
        nullStyle = style0
        nullCtx = ctx0
        nullMask = try Self.tensor([UInt8](repeating: 1, count: 2), [1, 2], .uInt8)
    }

    // MARK: - Tensor helpers

    private static func tensor<T>(_ a: [T], _ shape: [Int], _ type: ORTTensorElementDataType) throws -> ORTValue {
        let data = a.withUnsafeBufferPointer { NSMutableData(bytes: $0.baseAddress, length: a.count * MemoryLayout<T>.stride) }
        return try ORTValue(tensorData: data, elementType: type, shape: shape.map { NSNumber(value: $0) })
    }

    private static func floats(_ v: ORTValue) throws -> [Float] {
        let d = try v.tensorData() as Data
        return d.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
    }

    private func run(_ s: ORTSession, _ out: String, _ inputs: [String: ORTValue]) throws -> ORTValue {
        guard let v = try s.run(withInputs: inputs, outputNames: [out], runOptions: nil)[out] else {
            throw TTSError.notImplemented("model không trả về \(out)")
        }
        return v
    }

    private static func randn(_ n: Int) -> [Float] {
        var out = [Float](repeating: 0, count: n)
        var i = 0
        while i < n {
            let u1 = Float.random(in: Float.leastNormalMagnitude..<1), u2 = Float.random(in: 0..<1)
            let r = sqrtf(-2 * logf(u1))
            out[i] = r * cosf(2 * .pi * u2)
            if i + 1 < n { out[i + 1] = r * sinf(2 * .pi * u2) }
            i += 2
        }
        return out
    }

    // MARK: - Một chunk âm vị → âm thanh

    private func encode(_ phonemes: String) -> [Int64] {
        var s = phonemes
        for (tag, ch) in cfg.emotionTags { s = s.replacingOccurrences(of: tag, with: ch) }
        var ids: [Int64] = [Int64(cfg.bos)]
        for sc in s.unicodeScalars { if let i = cfg.vocab[String(sc)] { ids.append(Int64(i)) } }   // ngoài vocab: bỏ qua
        ids.append(Int64(cfg.eos))
        return ids
    }

    private func infer(phonemes: String, spk: ORTValue, style: ORTValue, opts: SynthesisOptions) throws -> [Float] {
        let ids = encode(phonemes)
        let L = ids.count
        let mask = try Self.tensor(ids.map { $0 != Int64(cfg.pad) ? UInt8(1) : UInt8(0) }, [1, L], .uInt8)
        let ctx = try run(sText, oText, ["ids": try Self.tensor(ids, [1, L], .int64), "style": style])
        let logS = try Self.floats(try run(sDur, oDur, ["ctx": ctx, "ctx_mask_u8": mask, "spk": spk])).first ?? 0
        let secs = min(exp(Double(logS)) / Double(max(opts.speed, 0.001)), maxChunkSeconds)
        let frames = max(2, Int((secs * cfg.fps).rounded()))

        var x = Self.randn(144 * frames)
        let n = max(1, opts.steps)
        let tg: [Double] = (0...n).map { i in
            let u = Double(i) / Double(n)
            return u + Double(opts.sway) * (cos(Double.pi / 2 * u) - 1 + u)
        }
        for i in 0..<n {
            try Task.checkCancellation()
            let t = try Self.tensor([Float(tg[i])], [1], .float)
            let xv = try Self.tensor(x, [1, 144, frames], .float)
            var v = try Self.floats(try run(sVE, oVE, ["x": xv, "t": t, "ctx": ctx, "ctx_mask_u8": mask,
                                                       "spk": spk, "style": style]))
            if opts.cfg > 0 {
                let vu = try Self.floats(try run(sVE, oVE, ["x": xv, "t": t, "ctx": nullCtx, "ctx_mask_u8": nullMask,
                                                            "spk": nullSpk, "style": nullStyle]))
                for k in 0..<v.count { v[k] = vu[k] + opts.cfg * (v[k] - vu[k]) }
            }
            let dt = Float(tg[i + 1] - tg[i])
            for k in 0..<x.count { x[k] += dt * v[k] }
        }
        let wav = try Self.floats(try run(sDec, oDec, ["x": try Self.tensor(x, [1, 144, frames], .float)]))
        return wav.map { max(-1, min(1, $0)) }
    }

    // MARK: - SpeechEngine

    func synthesize(text: String, voice: Voice, options: SynthesisOptions,
                    progress: @escaping @Sendable (Double) -> Void) async throws -> [Float] {
        let chunker = TextChunker(g2p: g2p)
        struct Plan { var chunks: [String]; var gaps: [String]; var pause: Double }
        var plans: [Plan] = []
        for (seg, pause) in PauseTags.split(text) {
            if seg.isEmpty { plans.append(Plan(chunks: [], gaps: [], pause: pause)); continue }
            let (c, g) = try chunker.chunks(from: seg)
            plans.append(Plan(chunks: c, gaps: g, pause: pause))
        }
        let total = max(1, plans.reduce(0) { $0 + $1.chunks.count })
        let spk = try Self.tensor(voice.speakerEmb, [1, voice.speakerEmb.count], .float)
        let styleFlat = voice.style.flatMap { $0 }
        let style = try Self.tensor(styleFlat, [1, voice.style.count, voice.style.first?.count ?? 0], .float)

        var out: [Float] = []
        var done = 0
        for plan in plans {
            var wavs: [[Float]] = []
            for chunk in plan.chunks {
                try Task.checkCancellation()
                let ph = try chunker.phonemize(chunk: chunk)
                wavs.append(try infer(phonemes: ph, spk: spk, style: style, opts: options))
                done += 1
                progress(Double(done) / Double(total))
            }
            out += AudioUtils.join(wavs, sr: sampleRate, pauses: AudioUtils.gapsToSilence(plan.gaps))
            if plan.pause > 0 { out += [Float](repeating: 0, count: Int(plan.pause * Double(sampleRate))) }
        }
        return out
    }
}
#else
final class NanoEngine: SpeechEngine {
    let sampleRate = 24_000
    init(directory: URL, g2p: SeaG2P, threads: Int = 3) throws {
        throw TTSError.notImplemented("ONNX Runtime (bật package onnxruntime trong project.yml)")
    }
    func synthesize(text: String, voice: Voice, options: SynthesisOptions,
                    progress: @escaping @Sendable (Double) -> Void) async throws -> [Float] { [] }
}
#endif
