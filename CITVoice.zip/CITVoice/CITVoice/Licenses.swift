import SwiftUI

// =============================================================================
//  GIẤY PHÉP & GHI CÔNG (v0.7) — mọi thành phần bên thứ ba mà app dùng hoặc tải về.
//  Khi thêm thư viện / model mới: thêm một mục vào `LicenseCatalog.items` VÀ vào THIRD_PARTY_NOTICES.md.
//  Thông tin lấy từ trang nguồn (xem `url`). Giấy phép là của tác giả từng thành phần, không phải của app này.
// =============================================================================

enum LicenseKind: String {
    case mit = "MIT"
    case apache2 = "Apache-2.0"
    case apple = "Điều khoản của Apple"
    case agpl3 = "AGPL-3.0"
    case openrail = "OpenRAIL-M"
}

struct LicenseItem: Identifiable {
    let id: String
    let name: String
    let role: String          // dùng để làm gì trong app
    let holder: String        // chủ bản quyền / tác giả
    let kind: LicenseKind
    let url: String
    var extra: String? = nil  // ghi chú thêm
    var how: String = "Tải về máy khi dùng tính năng liên quan"
}

enum LicenseCatalog {
    static let items: [LicenseItem] = [
        LicenseItem(
            id: "vieneu",
            name: "VieNeu-TTS v3 Nano",
            role: "Model tạo giọng nói tiếng Việt, 11 giọng mẫu và các model nhân bản giọng (speaker/codec/reference encoder).",
            holder: "Phạm Nguyễn Ngọc Bảo (pnnbao-ump)",
            kind: .apache2,
            url: "https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Nano",
            extra: "Giấy phép ghi theo thẻ license của trang model. Các phiên bản VieNeu khác có thể dùng giấy phép khác; app chỉ dùng v3 Nano."),
        LicenseItem(
            id: "seag2p",
            name: "sea-g2p",
            role: "Chuyển văn bản tiếng Việt thành âm vị trước khi tạo giọng (mã Rust biên dịch vào app, kèm từ điển sea_g2p.bin).",
            holder: "pnnbao97",
            kind: .apache2,
            url: "https://github.com/pnnbao97/sea-g2p",
            how: "Đóng gói sẵn trong app"),
        LicenseItem(
            id: "ort",
            name: "ONNX Runtime",
            role: "Chạy các model ONNX (tạo giọng, nhân bản giọng) trên máy.",
            holder: "Microsoft Corporation",
            kind: .mit,
            url: "https://github.com/microsoft/onnxruntime",
            how: "Đóng gói sẵn trong app"),
        LicenseItem(
            id: "ortspm",
            name: "onnxruntime-swift-package-manager",
            role: "Gói Swift Package đóng gói ONNX Runtime cho iOS.",
            holder: "Microsoft Corporation",
            kind: .mit,
            url: "https://github.com/microsoft/onnxruntime-swift-package-manager",
            extra: "Khi build, app lấy bản sao của gói này và chỉ nhận nếu đúng commit của bản 1.24.2 (xem scripts/prepare.sh).",
            how: "Đóng gói sẵn trong app"),
        LicenseItem(
            id: "whisperkit",
            name: "WhisperKit",
            role: "Thư viện chạy nhận dạng giọng nói Whisper trên máy (tự tạo phụ đề).",
            holder: "Argmax, Inc.",
            kind: .mit,
            url: "https://github.com/argmaxinc/WhisperKit",
            how: "Đóng gói sẵn trong app"),
        LicenseItem(
            id: "whisper",
            name: "OpenAI Whisper (model nhận dạng)",
            role: "Model nhận dạng giọng nói (base / small). App tải bản Core ML do Argmax chuyển đổi.",
            holder: "OpenAI (model gốc); Argmax, Inc. (bản chuyển đổi Core ML)",
            kind: .mit,
            url: "https://github.com/openai/whisper",
            extra: "Bản Core ML: https://huggingface.co/argmaxinc/whisperkit-coreml"),
        LicenseItem(
            id: "uvr",
            name: "UVR MDX-Net (Inst HQ 3) — bản Core ML",
            role: "Model tách lời nói khỏi nhạc nền khi lồng tiếng.",
            holder: "Anjok07 và Kimberley Jensen (model UVR MDX-Net); Gyoom (chuyển đổi sang Core ML fp16, 2026)",
            kind: .mit,
            url: "https://huggingface.co/gyoom/UVR-MDX-CoreML",
            extra: "Trọng số gốc phát hành theo MIT tại https://github.com/TRvlvr/model_repo."),
        LicenseItem(
            id: "kaldi",
            name: "Kaldi / kaldi-native-fbank (tham khảo thuật toán)",
            role: "Cách tính đặc trưng fbank 80 mel cho model nhận dạng người nói khi nhân bản giọng. App tự viết lại bằng Swift, không chép mã nguồn.",
            holder: "Các tác giả Kaldi và kaldi-native-fbank",
            kind: .apache2,
            url: "https://github.com/csukuangfj/kaldi-native-fbank",
            how: "Chỉ tham khảo thuật toán"),
        LicenseItem(
            id: "apple",
            name: "Apple: Translation, Foundation Models, SF Symbols",
            role: "Dịch phụ đề trên máy (Translation), viết lại câu dịch cho ngắn gọn (Foundation Models, iOS 26+), biểu tượng giao diện (SF Symbols).",
            holder: "Apple Inc.",
            kind: .apple,
            url: "https://developer.apple.com/support/terms/",
            extra: "Dùng theo Apple Developer Program License Agreement và các điều khoản kèm theo (gồm yêu cầu sử dụng chấp nhận được của framework Foundation Models).",
            how: "Có sẵn trong iOS"),
        LicenseItem(
            id: "voicestudio",
            name: "VoiceStudio (tham khảo ý tưởng)",
            role: "Cách ước lượng thời lượng đọc theo ký tự/giây, đo độ dài giọng thật rồi mới chỉnh tốc độ để khớp khung phụ đề, cân bằng âm lượng giữa các dòng lồng tiếng và xuất phụ đề karaoke (.ass) và tạo video karaoke (có video gốc hoặc chỉ nền + giọng). App tự viết lại bằng Swift, không chép mã nguồn.",
            holder: "Palash Debnath và những người đóng góp VoiceStudio",
            kind: .agpl3,
            url: "https://github.com/debpalash/VoiceStudio",
            extra: "Không đóng gói mã hay model của VoiceStudio. Con số 16 ký tự/giây cho tiếng Việt lấy từ bảng speech_rate của dự án đó (app tự điều chỉnh theo giọng đang dùng).",
            how: "Chỉ tham khảo ý tưởng"),
        LicenseItem(
            id: "supertonic",
            name: "Supertonic-3 (model giọng nói tuỳ chọn)",
            role: "Giọng đọc thứ hai chạy trên máy bằng ONNX Runtime, có tiếng Việt. Quy trình suy luận và bước chuẩn hoá văn bản được viết lại bằng Swift theo mã mẫu của hãng.",
            holder: "Supertone Inc.",
            kind: .openrail,
            url: "https://huggingface.co/supertone-oss-archive/supertonic-3",
            extra: "Model theo giấy phép OpenRAIL-M (có điều khoản về mục đích sử dụng, đọc kỹ trước khi chia sẻ app). Mã mẫu của hãng theo giấy phép MIT, Copyright (c) 2026 Supertone Inc. Mã nguồn: https://github.com/supertone-oss-archive/supertonic",
            how: "Tải về máy khi bấm Tải Supertonic-3"),
    ]

    static let mitTemplate = """
    MIT License

    Copyright (c) %@

    Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    """

    /// Văn bản giấy phép đầy đủ của một mục.
    static func text(for item: LicenseItem) -> String {
        switch item.kind {
        case .mit:
            return String(format: mitTemplate, item.holder)
        case .apache2:
            if let url = Bundle.main.url(forResource: "LICENSE-Apache-2.0", withExtension: "txt"),
               let s = try? String(contentsOf: url, encoding: .utf8) {
                return "Bản quyền thuộc: \(item.holder)\n\nGiấy phép áp dụng cho thành phần này là Apache License 2.0. Toàn văn:\n\n" + s
            }
            return "Apache License 2.0 — toàn văn tại https://www.apache.org/licenses/LICENSE-2.0"
        case .openrail:
            return "Model Supertonic-3 được phát hành theo giấy phép OpenRAIL-M của Supertone Inc. Giấy phép cho phép dùng và phân phối lại kèm các điều khoản về mục đích sử dụng; toàn văn tại trang model: \(item.url) (tệp LICENSE). Mã mẫu của hãng theo giấy phép MIT, Copyright (c) 2026 Supertone Inc. App này không đóng gói model, người dùng tự tải về khi cần."
        case .agpl3:
            return "VoiceStudio được phát hành theo GNU Affero General Public License v3.0 (AGPL-3.0). App này chỉ tham khảo ý tưởng và tự viết lại mã, không sao chép hay đóng gói mã nguồn của VoiceStudio. Toàn văn giấy phép: https://www.gnu.org/licenses/agpl-3.0.html — mã nguồn VoiceStudio: \(item.url)"
        case .apple:
            return "Thành phần này là một phần của iOS / bộ công cụ của Apple và được dùng theo điều khoản của Apple: \(item.url)"
        }
    }
}

struct LicensesView: View {
    var body: some View {
        List {
            Section {
                Text("CIT Voice dùng các thư viện và model mã nguồn mở dưới đây. Cảm ơn các tác giả. Giấy phép là của từng tác giả; mỗi mục có toàn văn giấy phép và liên kết tới trang nguồn.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            Section("Thành phần bên thứ ba") {
                ForEach(LicenseCatalog.items) { item in
                    NavigationLink {
                        LicenseDetailView(item: item)
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(item.name).font(.subheadline.weight(.semibold))
                            Text(item.kind.rawValue).font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 2)
                    }
                }
            }
            Section("Về model tải từ mạng") {
                Text("Các model (giọng nói, nhận dạng, tách nhạc) được tải trực tiếp từ Hugging Face về máy bạn khi dùng tính năng tương ứng. Âm thanh và video của bạn được xử lý trên máy, không gửi đi đâu.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Giấy phép")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct LicenseDetailView: View {
    let item: LicenseItem

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text(item.name).font(.title3.weight(.bold))
                row("Dùng để", item.role)
                row("Tác giả / bản quyền", item.holder)
                row("Giấy phép", item.kind.rawValue)
                row("Cách có trong app", item.how)
                if let e = item.extra { row("Ghi chú", e) }
                if let u = URL(string: item.url) {
                    Link(destination: u) {
                        Label("Trang nguồn", systemImage: "arrow.up.right.square")
                            .font(.subheadline.weight(.semibold))
                    }
                    Text(item.url).font(.caption2).foregroundStyle(.secondary).textSelection(.enabled)
                }
                Divider()
                Text(LicenseCatalog.text(for: item))
                    .font(.system(.caption, design: .monospaced))
                    .textSelection(.enabled)
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .navigationTitle(item.name)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func row(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            Text(value).font(.subheadline)
        }
    }
}
