import Foundation

/// Port từ src/vieneu/_nano_audio.py: cắt im lặng hai đầu, fade mép, nối chunk với khoảng nghỉ đúng độ dài.
enum AudioUtils {
    static let gapSilence: [String: Double] = ["para": 0.55, "sentence": 0.32, "minor": 0.14]
    static let edgeThreshDB: Float = -45
    static let edgeKeepS = 0.04
    static let edgeFadeS = 0.015

    static func gapsToSilence(_ gaps: [String]) -> [Double] {
        gaps.map { gapSilence[$0] ?? gapSilence["sentence"]! }
    }

    /// (lead, tail): số mẫu im lặng ở đầu và cuối. Toàn im lặng -> (count, 0).
    static func edgeSilence(_ wav: [Float], sr: Int, threshDB: Float = edgeThreshDB, winS: Double = 0.01) -> (Int, Int) {
        let n = wav.count
        let win = max(1, Int(winS * Double(sr)))
        let nWin = n / win
        if nWin == 0 { return (n, 0) }
        let thresh = powf(10, threshDB / 20)
        var first = -1, last = -1
        for w in 0..<nWin {
            var sum: Float = 0
            let base = w * win
            for i in 0..<win { sum += abs(wav[base + i]) }
            if sum / Float(win) > thresh {
                if first < 0 { first = w }
                last = w
            }
        }
        if first < 0 { return (n, 0) }
        return (first * win, n - (last + 1) * win)
    }

    static func trimAndFade(_ wav: [Float], sr: Int) -> [Float] {
        if wav.isEmpty { return wav }
        let (lead, tail) = edgeSilence(wav, sr: sr)
        let keep = Int(edgeKeepS * Double(sr))
        let a = max(0, lead - keep)
        let b = wav.count - max(0, tail - keep)
        if b <= a { return [] }
        var out = Array(wav[a..<b])
        let n = min(Int(edgeFadeS * Double(sr)), out.count / 2)
        if n > 0 {
            for i in 0..<n {
                let ramp = Float(0.5 - 0.5 * cos(Double.pi * Double(i) / Double(max(n - 1, 1))))
                out[i] *= ramp
                out[out.count - 1 - i] *= ramp
            }
        }
        return out
    }

    static func pausePadSamples(prev: [Float], next: [Float], sr: Int, pauseS: Double) -> Int {
        var (leadPrev, tail) = edgeSilence(prev, sr: sr)
        if leadPrev == prev.count { tail = prev.count }
        let (lead, _) = edgeSilence(next, sr: sr)
        return max(0, Int(pauseS * Double(sr)) - tail - lead)
    }

    /// Ghép chunk: trim + fade từng chunk rồi chèn zeros để im-lặng-đuôi + zeros + im-lặng-đầu = pauses[i].
    static func join(_ chunks: [[Float]], sr: Int, pauses: [Double]) -> [Float] {
        if chunks.isEmpty { return [] }
        let trimmed = chunks.map { trimAndFade($0, sr: sr) }
        var out = trimmed[0]
        for i in 1..<max(trimmed.count, 1) where i < trimmed.count {
            let p = i - 1 < pauses.count ? pauses[i - 1] : 0
            let pad = pausePadSamples(prev: trimmed[i - 1], next: trimmed[i], sr: sr, pauseS: p)
            if pad > 0 { out.append(contentsOf: [Float](repeating: 0, count: pad)) }
            out.append(contentsOf: trimmed[i])
        }
        return out
    }

    // MARK: - Âm lượng

    /// Đưa giọng đọc về âm lượng dễ nghe: RMS (chỉ tính phần có tiếng) ≈ -20 dBFS, rồi giới hạn đỉnh để không vỡ tiếng.
    static func normalizeLoudness(_ wav: [Float], targetRMSdB: Float = -20, peakCeil: Float = 0.97) -> [Float] {
        guard !wav.isEmpty else { return wav }
        var sum: Double = 0
        var cnt = 0
        let gate: Float = 0.003
        for v in wav where abs(v) > gate { sum += Double(v * v); cnt += 1 }
        guard cnt > 0 else { return wav }
        let rms = Float((sum / Double(cnt)).squareRoot())
        guard rms > 1e-5 else { return wav }
        var gain = powf(10, targetRMSdB / 20) / rms
        gain = min(gain, 30)                                  // tối đa +29 dB
        var out = wav.map { $0 * gain }
        // Giới hạn mềm: đoạn vượt ngưỡng 0.8 được nén bằng tanh thay vì cắt phẳng (đỡ rè).
        let knee: Float = 0.8
        let room = peakCeil - knee
        for i in 0..<out.count {
            let a = abs(out[i])
            if a > knee {
                let over = (a - knee) / room
                out[i] = (out[i] < 0 ? -1 : 1) * (knee + room * tanhf(over))
            }
        }
        return out
    }

    /// Chuẩn bị giọng mẫu trước khi mã hoá: bỏ DC, lọc thông cao ~80 Hz (bỏ ù), chuẩn hoá âm lượng.
    static func prepareReference(_ wav: [Float], sr: Int) -> [Float] {
        guard !wav.isEmpty else { return wav }
        let mean = wav.reduce(0, +) / Float(wav.count)
        let rc = 1 / (2 * Float.pi * 80)
        let dt = 1 / Float(sr)
        let a = rc / (rc + dt)
        var y = [Float](repeating: 0, count: wav.count)
        var prevX = wav[0] - mean, prevY: Float = 0
        for i in 0..<wav.count {
            let x = wav[i] - mean
            let v = a * (prevY + x - prevX)
            y[i] = v; prevX = x; prevY = v
        }
        return normalizeLoudness(y, targetRMSdB: -22, peakCeil: 0.95)
    }

    /// Chọn đoạn `seconds` giây "sạch tiếng nói" nhất: nhiều năng lượng nhưng ổn định (tránh đoạn toàn nhạc/ồn hay chỉ im lặng).
    /// Trả về chỉ số bắt đầu.
    static func bestWindowStart(_ wav: [Float], sr: Int, seconds: Double) -> Int {
        let win = Int(seconds * Double(sr))
        guard wav.count > win + sr / 2 else { return 0 }
        let hop = sr / 4
        let frame = sr / 50                                   // 20 ms
        func frameRMS(_ a: Int, _ b: Int) -> Float {
            var s: Float = 0; for i in a..<b { s += wav[i] * wav[i] }
            return (s / Float(max(1, b - a))).squareRoot()
        }
        var best = 0
        var bestScore = -Float.infinity
        var start = 0
        while start + win <= wav.count {
            var rmss: [Float] = []
            var f = start
            while f + frame <= start + win { rmss.append(frameRMS(f, f + frame)); f += frame }
            let sorted = rmss.sorted()
            let noise = max(sorted[sorted.count / 10], 1e-5)       // sàn ồn (phân vị 10%)
            let speech = sorted[sorted.count * 9 / 10]             // mức tiếng nói (phân vị 90%)
            let snr = 20 * log10f(max(speech, 1e-5) / noise)
            let voiced = Float(rmss.filter { $0 > noise * 3 && $0 > 0.01 }.count) / Float(rmss.count)
            let score = min(snr, 40) + 20 * voiced                 // SNR cao + nhiều khung có tiếng
            if score > bestScore { bestScore = score; best = start }
            start += hop
        }
        return best
    }

    /// Ước lượng tỉ lệ tiếng nói / ồn (dB) và đỉnh âm lượng của một clip.
    static func quality(_ wav: [Float], sr: Int) -> (snr: Float, peak: Float) {
        let peak = wav.reduce(Float(0)) { max($0, abs($1)) }
        let frame = max(1, sr / 50)
        var rmss: [Float] = []
        var f = 0
        while f + frame <= wav.count {
            var s: Float = 0; for i in f..<(f + frame) { s += wav[i] * wav[i] }
            rmss.append((s / Float(frame)).squareRoot()); f += frame
        }
        guard rmss.count > 10 else { return (0, peak) }
        let sorted = rmss.sorted()
        let noise = max(sorted[sorted.count / 10], 1e-5)
        let speech = max(sorted[sorted.count * 9 / 10], 1e-5)
        return (20 * log10f(speech / noise), peak)
    }
}
