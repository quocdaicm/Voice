import Foundation

/// Port từ src/vieneu/_nano_audio.py: cắt im lặng hai đầu, fade mép, nối chunk với khoảng nghỉ đúng độ dài.
enum AudioUtils {
    static let gapSilence: [String: Double] = ["para": 0.55, "sentence": 0.32, "minor": 0.14]
    static let edgeThreshDB: Float = -45
    static let edgeKeepS = 0.04
    static let edgeFadeS = 0.015

    static func gapsToSilence(_ gaps: [String]) -> [Double] {
        gaps.map { gapSilence[$0] ?? gapSilence["sentence"]! }
    }

    /// (lead, tail): số mẫu im lặng ở đầu và cuối. Toàn im lặng -> (count, 0).
    static func edgeSilence(_ wav: [Float], sr: Int, threshDB: Float = edgeThreshDB, winS: Double = 0.01) -> (Int, Int) {
        let n = wav.count
        let win = max(1, Int(winS * Double(sr)))
        let nWin = n / win
        if nWin == 0 { return (n, 0) }
        let thresh = powf(10, threshDB / 20)
        var first = -1, last = -1
        for w in 0..<nWin {
            var sum: Float = 0
            let base = w * win
            for i in 0..<win { sum += abs(wav[base + i]) }
            if sum / Float(win) > thresh {
                if first < 0 { first = w }
                last = w
            }
        }
        if first < 0 { return (n, 0) }
        return (first * win, n - (last + 1) * win)
    }

    static func trimAndFade(_ wav: [Float], sr: Int) -> [Float] {
        if wav.isEmpty { return wav }
        let (lead, tail) = edgeSilence(wav, sr: sr)
        let keep = Int(edgeKeepS * Double(sr))
        let a = max(0, lead - keep)
        let b = wav.count - max(0, tail - keep)
        if b <= a { return [] }
        var out = Array(wav[a..<b])
        let n = min(Int(edgeFadeS * Double(sr)), out.count / 2)
        if n > 0 {
            for i in 0..<n {
                let ramp = Float(0.5 - 0.5 * cos(Double.pi * Double(i) / Double(max(n - 1, 1))))
                out[i] *= ramp
                out[out.count - 1 - i] *= ramp
            }
        }
        return out
    }

    static func pausePadSamples(prev: [Float], next: [Float], sr: Int, pauseS: Double) -> Int {
        var (leadPrev, tail) = edgeSilence(prev, sr: sr)
        if leadPrev == prev.count { tail = prev.count }
        let (lead, _) = edgeSilence(next, sr: sr)
        return max(0, Int(pauseS * Double(sr)) - tail - lead)
    }

    /// Ghép chunk: trim + fade từng chunk rồi chèn zeros để im-lặng-đuôi + zeros + im-lặng-đầu = pauses[i].
    static func join(_ chunks: [[Float]], sr: Int, pauses: [Double]) -> [Float] {
        if chunks.isEmpty { return [] }
        let trimmed = chunks.map { trimAndFade($0, sr: sr) }
        var out = trimmed[0]
        for i in 1..<max(trimmed.count, 1) where i < trimmed.count {
            let p = i - 1 < pauses.count ? pauses[i - 1] : 0
            let pad = pausePadSamples(prev: trimmed[i - 1], next: trimmed[i], sr: sr, pauseS: p)
            if pad > 0 { out.append(contentsOf: [Float](repeating: 0, count: pad)) }
            out.append(contentsOf: trimmed[i])
        }
        return out
    }
}
