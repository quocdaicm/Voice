import AVFoundation
import UIKit

/// Xuất âm thanh ra định dạng nhẹ hơn WAV.
/// Lưu ý: iOS không có bộ mã hoá MP3 sẵn (chỉ giải mã được). M4A (AAC) là định dạng nén tương đương, phát được mọi nơi.
/// Muốn có MP3 thật phải thêm thư viện LAME (giấy phép LGPL) — chưa làm.
enum AudioExporter {
    /// WAV → M4A (AAC mono). Ghi từng khối nên ít tốn RAM.
    static func m4a(from wav: URL) async throws -> URL {
        try await Task.detached(priority: .userInitiated) { () throws -> URL in
            let name = wav.deletingPathExtension().lastPathComponent
            let out = FileManager.default.temporaryDirectory.appendingPathComponent(name + ".m4a")
            try? FileManager.default.removeItem(at: out)

            let input = try AVAudioFile(forReading: wav)
            let fmt = input.processingFormat
            let cap: AVAudioFrameCount = 32_768
            guard let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: cap) else {
                throw TTSError.clone("Không đủ bộ nhớ để xuất M4A.")
            }
            let settings: [String: Any] = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVSampleRateKey: fmt.sampleRate,
                AVNumberOfChannelsKey: Int(fmt.channelCount),
                AVEncoderBitRateKey: 64_000,
            ]
            var output: AVAudioFile? = try AVAudioFile(forWriting: out, settings: settings,
                                                       commonFormat: .pcmFormatFloat32, interleaved: false)
            while input.framePosition < input.length {
                try input.read(into: buf, frameCount: cap)
                if buf.frameLength == 0 { break }
                try output?.write(from: buf)
            }
            output = nil   // đóng file để ghi nốt phần đuôi
            return out
        }.value
    }
}

/// Mở bảng chia sẻ của iOS cho một file (dùng sau khi xuất xong).
@MainActor
enum SharePresenter {
    static func share(_ url: URL) {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let window = scenes.flatMap { $0.windows }.first { $0.isKeyWindow } ?? scenes.flatMap { $0.windows }.first
        var top = window?.rootViewController
        while let next = top?.presentedViewController { top = next }
        let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        top?.present(vc, animated: true)
    }
}
