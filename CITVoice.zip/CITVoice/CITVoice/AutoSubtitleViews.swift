import SwiftUI

/// Sheet "Tự tạo phụ đề": chọn ngôn ngữ gốc + model → nhận dạng → dịch.
struct AutoSubtitleSheet: View {
    @ObservedObject var gen: SubtitleGenModel
    @ObservedObject var dub: DubbingModel
    var onFinished: () -> Void
    @Environment(\.dismiss) private var dismiss

    @State private var language: SourceLanguage = .auto
    @State private var model: ASRModel = .small

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    Card("Ngôn ngữ trong video", icon: "globe") {
                        Picker("Ngôn ngữ", selection: $language) {
                            ForEach(SourceLanguage.allCases) { l in Text(l.title).tag(l) }
                        }
                        .pickerStyle(.menu)
                        .tint(Brand.indigo)
                        Text("Nên chọn đúng ngôn ngữ nếu biết (chính xác hơn tự phát hiện). Mọi thứ chạy trên máy; lần đầu app tải model nhận dạng và gói dịch ngôn ngữ về máy.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Card("Model nhận dạng", icon: "waveform") {
                        Picker("Model", selection: $model) {
                            ForEach(ASRModel.allCases) { m in Text(m.title).tag(m) }
                        }
                        .pickerStyle(.inline)
                        .labelsHidden()
                        Text("Tiếng Thái, Hàn, Trung nên dùng model small.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    if gen.isBusy {
                        Card("Đang xử lý", icon: "hourglass") {
                            HStack(spacing: 10) {
                                ProgressView()
                                Text(gen.statusText).font(.subheadline)
                            }
                        }
                    }
                    if let n = gen.notice {
                        Text(n).font(.footnote).foregroundStyle(.orange)
                    }
                }
                .padding(16)
            }
            .background(AuroraBackground())
            .navigationTitle("Tự tạo phụ đề")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Đóng") {
                        gen.cancel()
                        dismiss()
                    }
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                HStack(spacing: 10) {
                    Button {
                        guard let url = dub.videoURL else { return }
                        Haptics.tap()
                        gen.run(video: url, duration: dub.videoDuration, language: language, model: model) { cues, name in
                            dub.setGenerated(cues: cues, name: name)
                            onFinished()
                        }
                    } label: {
                        Text(gen.isBusy ? "Đang xử lý…" : "Bắt đầu nhận dạng và dịch")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(gen.isBusy || dub.videoURL == nil)

                    if gen.isBusy {
                        Button { gen.cancel() } label: { SVGIcon("IcClear", size: 22) }
                            .buttonStyle(CircleIconButtonStyle(danger: true, size: 54))
                            .accessibilityLabel("Huỷ")
                    }
                }
                .padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 8)
                .background(.ultraThinMaterial)
                .overlay(alignment: .top) { Divider() }
            }
        }
        .translationHost(gen.bridge)
        .interactiveDismissDisabled(gen.isBusy)
        .alert("Lỗi", isPresented: Binding(
            get: { gen.errorMessage != nil },
            set: { if !$0 { gen.errorMessage = nil } }
        )) {
            Button("Đóng", role: .cancel) {}
        } message: {
            Text(gen.errorMessage ?? "")
        }
    }
}

/// Xem / sửa từng dòng phụ đề trước khi tạo giọng.
struct SubtitleEditorView: View {
    @Binding var cues: [SubtitleCue]
    var notice: String?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if let notice {
                    Text(notice).font(.footnote).foregroundStyle(.orange)
                }
                ForEach($cues) { $cue in
                    VStack(alignment: .leading, spacing: 6) {
                        Text("\(clock(cue.start)) → \(clock(cue.end))")
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(Brand.indigo)
                        TextField("Nội dung", text: $cue.text, axis: .vertical)
                            .font(.body)
                        if !cue.original.isEmpty, cue.original != cue.text {
                            Text(cue.original)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 2)
                }
                .onDelete { cues.remove(atOffsets: $0) }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("\(cues.count) dòng phụ đề")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if let url = srtFile() {
                        ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") { hideKeyboard(); dismiss() }.fontWeight(.semibold)
                }
            }
            .keyboardDoneButton()
        }
    }

    private func srtFile() -> URL? {
        guard !cues.isEmpty else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("phu-de.srt")
        try? SubtitleWriter.srt(cues).write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private func clock(_ t: Double) -> String {
        let ms = Int((max(0, t) * 10).rounded())
        let s = ms / 10
        return String(format: "%d:%02d.%d", s / 60, s % 60, ms % 10)
    }
}
