import SwiftUI

/// Sheet "Tự tạo phụ đề": chọn ngôn ngữ gốc + model → nhận dạng → dịch.
struct AutoSubtitleSheet: View {
    @ObservedObject var gen: SubtitleGenModel
    @ObservedObject var dub: DubbingModel
    @ObservedObject var stems: StemModelStore
    var onFinished: () -> Void
    @Environment(\.dismiss) private var dismiss

    @State private var language: SourceLanguage = .auto
    @State private var model: ASRModel = .turbo
    @State private var viaEnglish = true
    @State private var isolate = false
    @State private var shorten = true
    private let shortenAvailability = LineShortener.availability

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    Card("Ngôn ngữ trong video", icon: "globe") {
                        Picker("Ngôn ngữ", selection: $language) {
                            ForEach(SourceLanguage.allCases) { l in Text(l.title).tag(l) }
                        }
                        .pickerStyle(.menu)
                        .tint(Brand.indigo)
                        Text("Nên chọn đúng ngôn ngữ nếu biết (chính xác hơn tự phát hiện). Mọi thứ chạy trên máy; lần đầu app tải model nhận dạng và gói dịch ngôn ngữ về máy.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Card("Model nhận dạng", icon: "waveform") {
                        Picker("Model", selection: $model) {
                            ForEach(ASRModel.allCases) { m in Text(m.title).tag(m) }
                        }
                        .pickerStyle(.inline)
                        .labelsHidden()
                        Text("Model chính xác nhất nhận dạng đúng hơn rõ rệt (nhất là Trung, Thái, Hàn, Nhật) nhưng nặng và chạy lâu hơn. Máy cũ có thể chọn small.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Card("Tách nhạc nền trước khi nhận dạng", icon: "music.note") {
                        Toggle("Chỉ nhận dạng phần tiếng nói", isOn: $isolate).tint(Brand.indigo)
                        Text("Nên bật nếu video có nhạc nền hoặc tiếng ồn: nhận dạng sẽ đúng hơn và ít bịa chữ ở đoạn chỉ có nhạc. Chạy lâu hơn (khoảng vài phút cho mỗi 4 phút video) và cần model tách nhạc.")
                            .font(.footnote).foregroundStyle(.secondary)
                        if isolate {
                            switch stems.state {
                            case .ready:
                                Label("Model tách nhạc đã sẵn sàng", systemImage: "checkmark.circle.fill")
                                    .font(.footnote).foregroundStyle(.green)
                            case .downloading:
                                Text(stems.statusText).font(.footnote)
                                ProgressView(value: stems.progress).tint(Brand.indigo)
                            default:
                                if case .failed(let m) = stems.state { Text(m).font(.footnote).foregroundStyle(.red) }
                                Button {
                                    Task { await stems.download() }
                                } label: {
                                    Label("Tải model tách nhạc (~\(StemModelStore.approxMB) MB)", systemImage: "arrow.down.circle")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(SoftButtonStyle())
                            }
                        }
                    }
                    Card("Cách dịch", icon: "character.bubble") {
                        Toggle("Dịch qua tiếng Anh (khuyên dùng)", isOn: $viaEnglish).tint(Brand.indigo)
                        Text("Các cặp như Trung/Thái/Hàn/Nhật → Việt dịch thẳng thường sai nhiều. Dịch qua tiếng Anh rồi sang Việt thường đúng nghĩa hơn. Cần tải thêm gói tiếng Anh một lần.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Card("Rút ngắn câu dịch", icon: "scissors") {
                        switch shortenAvailability {
                        case .available:
                            Toggle("Tự rút ngắn dòng quá dài", isOn: $shorten).tint(Brand.indigo)
                            Text("Dùng model ngôn ngữ của Apple chạy trên máy để viết lại những dòng dịch dài hơn thời lượng, giúp giọng đọc không phải đọc quá nhanh. Bản gốc vẫn giữ để đối chiếu; bạn có thể sửa lại ở bước sau.")
                                .font(.footnote).foregroundStyle(.secondary)
                        case .unavailable(let why):
                            Text("Chưa dùng được: \(why) App sẽ đọc nhanh hơn (tối đa 1.6x) cho những dòng dài.")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    if gen.isBusy {
                        Card("Đang xử lý", icon: "hourglass") {
                            HStack(spacing: 10) {
                                ProgressView()
                                Text(gen.statusText).font(.subheadline)
                            }
                            if gen.stage == .loadingModel, gen.downloadedMB > 1 {
                                ProgressView(value: gen.downloadFraction).tint(Brand.indigo)
                            }
                        }
                    }
                    if let n = gen.notice {
                        Text(n).font(.footnote).foregroundStyle(.orange)
                    }
                }
                .padding(16)
            }
            .background(AuroraBackground())
            .navigationTitle("Tự tạo phụ đề")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Đóng") {
                        gen.cancel()
                        dismiss()
                    }
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                HStack(spacing: 10) {
                    Button {
                        guard let url = dub.videoURL else { return }
                        Haptics.tap()
                        gen.run(video: url, duration: dub.videoDuration, language: language, model: model, viaEnglish: viaEnglish,
                                shorten: shorten && shortenAvailability == .available,
                                stemModel: (isolate && stems.state == .ready) ? stems.compiledURL : nil) { cues, name in
                            dub.setGenerated(cues: cues, name: name)
                            onFinished()
                        }
                    } label: {
                        Text(gen.isBusy ? "Đang xử lý…" : "Bắt đầu nhận dạng và dịch")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(gen.isBusy || dub.videoURL == nil || (isolate && stems.state == .downloading))

                    if gen.isBusy {
                        Button { gen.cancel() } label: { SVGIcon("IcClear", size: 22) }
                            .buttonStyle(CircleIconButtonStyle(danger: true, size: 54))
                            .accessibilityLabel("Huỷ")
                    }
                }
                .padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 8)
                .background(.ultraThinMaterial)
                .overlay(alignment: .top) { Divider() }
            }
        }
        .translationHost(gen.bridge)
        .interactiveDismissDisabled(gen.isBusy)
        .alert("Lỗi", isPresented: Binding(
            get: { gen.errorMessage != nil },
            set: { if !$0 { gen.errorMessage = nil } }
        )) {
            Button("Đóng", role: .cancel) {}
        } message: {
            Text(gen.errorMessage ?? "")
        }
    }
}

/// Xem / sửa từng dòng phụ đề trước khi tạo giọng: sửa chữ, chỉnh mốc, nghe thử, xoá dòng.
struct SubtitleEditorView: View {
    @Binding var cues: [SubtitleCue]
    var notice: String?
    var previewingID: UUID?
    var onPreview: (SubtitleCue) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var shortening = false
    @State private var shortenNote: String?
    private let shortenAvailability = LineShortener.availability

    /// Số ký tự mỗi giây ước tính cho giọng đọc tiếng Việt ở tốc độ 1x.
    private let comfortable = 15.0
    private let tooFast = 24.0

    var body: some View {
        NavigationStack {
            List {
                if let notice {
                    Text(notice).font(.footnote).foregroundStyle(.orange)
                }
                shortenSection
                ForEach($cues) { $cue in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("\(clock(cue.start)) → \(clock(cue.end))")
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(Brand.indigo)
                            Spacer()
                            speedBadge(for: cue)
                            Button { onPreview(cue) } label: {
                                if previewingID == cue.id {
                                    ProgressView()
                                } else {
                                    Image(systemName: "play.circle.fill").font(.title3)
                                }
                            }
                            .buttonStyle(.borderless)
                            .disabled(previewingID != nil)
                            .accessibilityLabel("Nghe thử")
                        }
                        TextField("Nội dung", text: $cue.text, axis: .vertical)
                            .font(.body)
                        if !cue.original.isEmpty, cue.original != cue.text {
                            Text(cue.original)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        HStack(spacing: 12) {
                            Stepper(value: $cue.start, in: 0...7200, step: 0.1) {
                                Text("Từ \(clock(cue.start))").font(.caption.monospacedDigit())
                            }
                            Stepper(value: $cue.end, in: (cue.start + 0.2)...7200, step: 0.1) {
                                Text("Đến \(clock(cue.end))").font(.caption.monospacedDigit())
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
                .onDelete { cues.remove(atOffsets: $0) }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("\(cues.count) dòng phụ đề")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if let url = srtFile() {
                        ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") { hideKeyboard(); dismiss() }.fontWeight(.semibold)
                }
            }
            .keyboardDoneButton()
        }
    }

    @ViewBuilder
    private var shortenSection: some View {
        let long = LineShortener.candidates(cues).count
        VStack(alignment: .leading, spacing: 6) {
            switch shortenAvailability {
            case .available:
                Button {
                    runShorten()
                } label: {
                    HStack {
                        if shortening { ProgressView() } else { Image(systemName: "scissors") }
                        Text(shortening ? "Đang rút ngắn…" : "Rút ngắn \(long) dòng quá dài")
                            .font(.subheadline.weight(.semibold))
                    }
                }
                .buttonStyle(.borderless)
                .disabled(shortening || long == 0)
                if long == 0 && !shortening {
                    Text("Không có dòng nào dài quá khung thời gian.").font(.caption).foregroundStyle(.secondary)
                }
            case .unavailable(let why):
                Text("Rút ngắn tự động chưa dùng được: \(why)").font(.caption).foregroundStyle(.secondary)
            }
            if let n = shortenNote { Text(n).font(.caption).foregroundStyle(.secondary) }
        }
    }

    private func runShorten() {
        shortening = true
        shortenNote = nil
        var copy = cues
        Task {
            defer { shortening = false }
            do {
                let changed = try await LineShortener.shortenAll(&copy)
                cues = copy
                shortenNote = changed > 0 ? "Đã rút ngắn \(changed) dòng. Bạn có thể sửa lại bằng tay." : "Không rút được dòng nào (giữ nguyên)."
            } catch {
                shortenNote = "Rút ngắn bị dừng: \(error.localizedDescription)"
            }
        }
    }

    /// Khung thời gian của một dòng = từ lúc nó bắt đầu đến khi dòng sau bắt đầu (cách app đặt giọng).
    private func slot(for cue: SubtitleCue) -> Double {
        let next = cues.filter { $0.start > cue.start }.map { $0.start }.min()
        return max(0.4, (next ?? cue.end) - cue.start - 0.05)
    }

    @ViewBuilder
    private func speedBadge(for cue: SubtitleCue) -> some View {
        let cps = Double(cue.text.count) / slot(for: cue)
        if cps > tooFast {
            Label("Quá dài, sẽ chồng", systemImage: "exclamationmark.triangle.fill")
                .font(.caption2.weight(.semibold)).foregroundStyle(.red)
        } else if cps > comfortable {
            Label("Dài, đọc nhanh", systemImage: "hare.fill")
                .font(.caption2.weight(.semibold)).foregroundStyle(.orange)
        }
    }

    private func srtFile() -> URL? {
        guard !cues.isEmpty else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("phu-de.srt")
        try? SubtitleWriter.srt(cues.sorted { $0.start < $1.start }).write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private func clock(_ t: Double) -> String {
        let d = Int((max(0, t) * 10).rounded())
        let s = d / 10
        return String(format: "%d:%02d.%d", s / 60, s % 60, d % 10)
    }
}
