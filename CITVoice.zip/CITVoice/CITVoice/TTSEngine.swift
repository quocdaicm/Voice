import Foundation

// =============================================================================
//  LỘ TRÌNH (đọc phần này trước khi làm tiếp)
//  Nguồn tham chiếu: cit-voice-studio-main.zip → src/vieneu/v3nano.py (engine ONNX, không cần torch)
//
//  GIAI ĐOẠN 1  ✅ (file này)  Khung app, tải model từ HuggingFace, danh sách 11 giọng,
//                              phát/lưu WAV, workflow GitHub Actions → IPA chưa ký.
//                              Engine hiện tại là `PlaceholderEngine` (chỉ phát tiếng bíp).
//
//  GIAI ĐOẠN 2  🔶 Văn bản → âm vị: đã port tách câu/chunk/thẻ (TextChunker, PauseTags) và nối sea-g2p qua
//                  C-ABI có sẵn (vendor/sea-g2p, Phonemizer.swift; CI build SeaG2PFFI.xcframework). CHƯA build thử.
//  GIAI ĐOẠN 3  🔶 Âm vị → giọng nói. ĐÃ VIẾT: NanoEngine.swift (ONNX Runtime), NPZ.swift, AudioUtils.swift,
//                  OnnxBoolPatch.swift (vá mask bool). CHƯA CHẠY THỬ trên máy thật — cần build + thử.
//  GIAI ĐOẠN 4  🔶 Nhân bản giọng: ĐÃ VIẾT (VoiceCloner, SpeakerFbank, Resampler, ReferenceAudio, CloneView,
//                  CustomVoiceStore). CHƯA chạy thử trên máy thật. Chưa có: khử nhiễu denoiser, watermark.
//                  Còn lại: tốc độ, lịch sử, nhiều đoạn, xuất MP3/M4A…
// =============================================================================
//
// ── GIAI ĐOẠN 2: văn bản → âm vị ─────────────────────────────────────────────
//  Python tham chiếu: src/vieneu_utils/phonemize_text.py
//     phonemize_text_with_emotions(text)      // gắn thẻ cảm xúc [cười] → <|emotion_k|>
//     normalize_to_chunks_v3_with_gaps(text)  // chia câu thành chunk + khoảng nghỉ (gap)
//  Lõi là thư viện `sea-g2p` (Rust, https://github.com/pnnbao97/sea-g2p, xem src/g2p/mod.rs):
//     SEAPipeline(lang="vi").run(text, punc_norm=True) → chuỗi IPA, vd "zˈaːɜ ˈɛɜt̪ pˈe ..."
//     (chuẩn hoá số/ngày/từ tiếng Anh + tra từ điển nhị phân ~20 MB, mmap)
//  Việc cần làm:
//   1. Tạo crate bọc C-ABI `rust/seag2p-ffi` (staticlib) phụ thuộc sea-g2p, xuất:
//        char* sea_pipeline_run(const char* utf8_text);   void sea_free(char* s);
//      LƯU Ý: PyPI sdist sea_g2p-*.tar.gz (~20 MB) có sẵn mã Rust + từ điển; nếu crate lõi
//      không tách riêng thì lấy từ sdist/GitHub trong bước CI rồi tự viết hàm bọc.
//   2. Bật các bước (đang comment) trong .github/workflows/build-ios.yml để build
//      aarch64-apple-ios + aarch64-apple-ios-sim → Frameworks/SeaG2P.xcframework,
//      rồi bật dòng `framework:` trong project.yml + thêm bridging header.
//   3. Port bằng Swift từ src/vieneu_utils/core_utils.py: split_into_sentences,
//      pack_sentences_into_chunks (chunk ≤ ~15 giây — `_MAX_CHUNK_SECONDS`), _classify_gap,
//      pause_tags.py (thẻ nghỉ), thẻ cảm xúc.
//   4. Kiểm tra: cùng 1 câu, so chuỗi âm vị của iOS với bản Python (nên có vài câu mẫu làm test).
//   Giao diện cần có: `protocol Phonemizer { func chunks(from text: String) -> [(phonemes: String, gapSeconds: Double)] }`
//
// ── GIAI ĐOẠN 3: âm vị → âm thanh (OnnxV3NanoEngine trong v3nano.py) ─────────────
//  1. Thêm ONNX Runtime: Swift Package `onnxruntime-swift-package-manager` (đang comment trong project.yml).
//  2. Đọc config.json: vocab (ký tự→id), bos_id/eos_id/pad_id, emotion_tags (thẻ → 1 ký tự trong vocab),
//     group (=6), flow_fps (mặc định 24000/256/6 = 15.625). Ký tự ngoài vocab thì bỏ qua.
//  3. Đọc constants.npz: null_spk [192], null_style [50,256]. NPZ = file zip chứa .npy → tự viết bộ đọc
//     (dùng framework Compression nếu nén deflate) hoặc chuyển sang .bin/.json ngay trong CI.
//  4. Với mỗi chunk (infer()):
//       ids   = [bos] + vocab[ký tự]... + [eos]                      // int64 [1,L]
//       ctx   = text_encoder(ids, style)                             // style = [1,50,256] của giọng
//       logS  = duration_predictor(ctx, ctx_mask, spk)               // spk = [1,192]
//       secs  = min(exp(logS)/speed, 15);  T = max(2, round(secs*fps))
//       x     = N(0,1) shape [1,144,T];  steps=16 (8 + sway=-1 cho nhanh);  cfg=3.0
//       u = linspace(0,1,steps+1);  tg = u + sway*(cos(pi/2*u) - 1 + u)
//       lặp i: v  = vector_estimator(x, t=tg[i], ctx, ctx_mask, spk, style)
//              nếu cfg>0: vu = vector_estimator(x, t, null_ctx, null_mask, null_spk, null_style)
//                         v = vu + cfg*(v - vu)
//              x += (tg[i+1]-tg[i]) * v
//       wav   = codec_decoder(x)  → float [-1,1] @ 24 kHz, rồi trim_and_fade
//     null_ctx = text_encoder([[bos,eos]], null_style) — tính 1 lần khi nạp model.
//  5. Ghép các chunk + khoảng nghỉ: xem _nano_audio.py (join_audio_chunks, gaps_to_silence, trim_and_fade).
//  6. Hiệu năng iPhone: intra_op threads 2–4, graph optimization ALL, `steps=8, sway=-1` để nhanh gấp ~2,
//     cfg=0 giảm một nửa tính toán nhưng giọng kém rõ. Chạy trên luồng nền, báo tiến độ theo chunk.
//     Nếu thiếu RAM: tạo session tuần tự và giải phóng khi không dùng.
//  7. Thay `PlaceholderEngine` bằng `NanoEngine: SpeechEngine` trong AppModel (ContentView.swift).
//
// ── GIAI ĐOẠN 4: hoàn thiện ───────────────────────────────────────────────────
//  - Lưu lịch sử (JSON trong Documents), xuất MP3/M4A (AVAssetWriter), chia sẻ.
//  - Nhập văn bản dài / file .txt, tạo từng đoạn và hiện tiến độ; huỷ giữa chừng.
//  - Từ điển phát âm (pronunciation.py), hội thoại nhiều giọng (conversation), phụ đề SRT (srt.py, dubbing.py).
//  - Nhân bản giọng: tải speaker_encoder/codec_encoder/reference_encoder.onnx (+denoiser.onnx),
//    thu mic 3–8 giây (AVAudioRecorder), port Kaldi fbank 80 mel (_v3_turbo_engine/speaker/fbank.py),
//    resample về 24 kHz; xem `prepare_reference()` trong v3nano.py → (speaker_emb[192], style[50,256]);
//    lưu giọng ra file JSON cùng định dạng voices_v3_nano.json. Nhớ kèm xác nhận quyền sử dụng giọng.
//  - Icon app, màn hình giới thiệu, ký IPA (hoặc dùng công cụ sideload).
// =============================================================================

struct SynthesisOptions {
    var steps: Int = 16        // số bước Euler (8 nhanh hơn ~2x)
    var cfg: Float = 3.0       // classifier-free guidance
    var sway: Float = 0        // dùng -1 khi steps = 8
    var speed: Float = 1.0
    var pauses: PauseProfile = .standard   // khoảng nghỉ giữa đoạn / câu / dấu phẩy
    var normalize: Bool = true             // false: app tự chuẩn hoá âm lượng một lần cho cả bản (khi đọc nhiều đoạn)
}

enum TTSError: LocalizedError {
    case emptyText
    case voiceMissing
    case notImplemented(String)
    case clone(String)

    var errorDescription: String? {
        switch self {
        case .emptyText: return "Hãy nhập văn bản."
        case .voiceMissing: return "Không tìm thấy giọng đã chọn."
        case .notImplemented(let what): return "Chưa làm: \(what)"
        case .clone(let msg): return msg
        }
    }
}

protocol SpeechEngine {
    var sampleRate: Int { get }
    /// Trả về mẫu âm thanh mono float [-1, 1].
    func synthesize(text: String, voice: Voice, options: SynthesisOptions,
                    progress: @escaping @Sendable (Double) -> Void) async throws -> [Float]
}

/// GIAI ĐOẠN 1: chỉ tạo tiếng bíp để thử luồng giao diện → phát → chia sẻ.
/// TODO(PHASE-3): thay bằng NanoEngine (ONNX) khi xong giai đoạn 2 và 3.
struct PlaceholderEngine: SpeechEngine {
    let sampleRate = 24_000

    func synthesize(text: String, voice: Voice, options: SynthesisOptions,
                    progress: @escaping @Sendable (Double) -> Void) async throws -> [Float] {
        let seconds = max(0.8, min(8.0, Double(text.count) * 0.06 / Double(max(options.speed, 0.1))))
        let freq: Double = voice.gender == "female" ? 330 : 190
        let n = Int(seconds * Double(sampleRate))
        let fade = Int(0.03 * Double(sampleRate))
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            var env = 1.0
            if i < fade { env = Double(i) / Double(fade) }
            if i > n - fade { env = Double(n - i) / Double(fade) }
            out[i] = Float(0.25 * env * sin(2 * Double.pi * freq * Double(i) / Double(sampleRate)))
        }
        return out
    }
}
