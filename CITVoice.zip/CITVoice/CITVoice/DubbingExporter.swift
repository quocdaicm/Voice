import AVFoundation

enum DubError: LocalizedError {
    case noVideoTrack
    case noDubAudio
    case export(String)
    case tooLong

    var errorDescription: String? {
        switch self {
        case .noVideoTrack: return "Không đọc được hình ảnh của video."
        case .noDubAudio: return "Không có âm thanh lồng tiếng để ghép."
        case .export(let m): return "Xuất video lỗi: \(m)"
        case .tooLong: return "Video dài quá 30 phút. Hãy cắt ngắn hơn."
        }
    }
}

/// Ghép âm thanh lồng tiếng (WAV) vào video, có thể giữ âm gốc ở mức nhỏ. Xuất .mp4.
enum DubbingExporter {
    static func export(video: URL, dub: URL, originalVolume: Float,
                       onProgress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        let asset = AVURLAsset(url: video)
        let dubAsset = AVURLAsset(url: dub)
        let duration = try await asset.load(.duration)

        guard let vTrack = try await asset.loadTracks(withMediaType: .video).first else { throw DubError.noVideoTrack }
        guard let dTrack = try await dubAsset.loadTracks(withMediaType: .audio).first else { throw DubError.noDubAudio }

        let comp = AVMutableComposition()
        guard let cv = comp.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw DubError.noVideoTrack
        }
        try cv.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: vTrack, at: .zero)
        cv.preferredTransform = try await vTrack.load(.preferredTransform)

        var params: [AVMutableAudioMixInputParameters] = []

        if originalVolume > 0,
           let aTrack = try await asset.loadTracks(withMediaType: .audio).first,
           let ca = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            try ca.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: aTrack, at: .zero)
            let p = AVMutableAudioMixInputParameters(track: ca)
            p.setVolume(originalVolume, at: .zero)
            params.append(p)
        }

        guard let cd = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw DubError.noDubAudio
        }
        let dubDur = try await dubAsset.load(.duration)
        let useDur = CMTimeMinimum(dubDur, duration)
        try cd.insertTimeRange(CMTimeRange(start: .zero, duration: useDur), of: dTrack, at: .zero)
        let pd = AVMutableAudioMixInputParameters(track: cd)
        pd.setVolume(1.0, at: .zero)
        params.append(pd)

        let mix = AVMutableAudioMix()
        mix.inputParameters = params

        guard let session = AVAssetExportSession(asset: comp, presetName: AVAssetExportPresetHighestQuality) else {
            throw DubError.export("không tạo được phiên xuất")
        }
        let out = FileManager.default.temporaryDirectory
            .appendingPathComponent("cit-dub-\(Int(Date().timeIntervalSince1970)).mp4")
        try? FileManager.default.removeItem(at: out)
        session.outputURL = out
        session.outputFileType = session.supportedFileTypes.contains(.mp4) ? .mp4 : .mov
        session.audioMix = mix
        session.shouldOptimizeForNetworkUse = true

        let poll = Task {
            while !Task.isCancelled {
                onProgress(Double(session.progress))
                try? await Task.sleep(nanoseconds: 200_000_000)
            }
        }
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            session.exportAsynchronously { cont.resume() }
        }
        poll.cancel()

        guard session.status == .completed else {
            throw DubError.export(session.error?.localizedDescription ?? "không rõ nguyên nhân")
        }
        onProgress(1)
        return out
    }
}
