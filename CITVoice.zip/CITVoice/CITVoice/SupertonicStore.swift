import Foundation

/// Tải / quản lý model Supertonic-3 (ONNX, ~vài trăm MB) và các giọng mẫu.
/// Nguồn: Hugging Face `supertone-oss-archive/supertonic-3`, ghim đúng bản chụp như README của hãng.
@MainActor
final class SupertonicStore: ObservableObject {
    enum State: Equatable {
        case notInstalled
        case downloading
        case ready
        case failed(String)
    }

    static let repo = "supertone-oss-archive/supertonic-3"
    static let revision = "aafc6e32416a594460b32413efc49d7fe4ce6d46"

    /// Bắt buộc phải có.
    static let requiredFiles = [
        "onnx/tts.json", "onnx/unicode_indexer.json",
        "onnx/duration_predictor.onnx", "onnx/text_encoder.onnx",
        "onnx/vector_estimator.onnx", "onnx/vocoder.onnx",
        "voice_styles/M1.json", "voice_styles/F1.json",
    ]
    /// Giọng thêm: thiếu file nào thì bỏ qua file đó.
    static let optionalVoices = ["M2", "M3", "M4", "M5", "F2", "F3", "F4", "F5"]

    @Published var state: State = .notInstalled
    @Published var fileProgress: Double = 0
    @Published var statusText = ""

    /// AppModel gắn vào để làm mới danh sách giọng khi cài / xoá model.
    var onChange: (() -> Void)?

    let directory: URL

    init() {
        var dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Models/Supertonic3", isDirectory: true)
        for sub in ["onnx", "voice_styles"] {
            try? FileManager.default.createDirectory(at: dir.appendingPathComponent(sub, isDirectory: true),
                                                     withIntermediateDirectories: true)
        }
        var rv = URLResourceValues()
        rv.isExcludedFromBackup = true
        try? dir.setResourceValues(rv)
        directory = dir
        state = Self.requiredPresent(in: dir) ? .ready : .notInstalled
    }

    private static func requiredPresent(in dir: URL) -> Bool {
        requiredFiles.allSatisfy { FileManager.default.fileExists(atPath: dir.appendingPathComponent($0).path) }
    }

    /// Các giọng mẫu đang có trên máy, dưới dạng `Voice` để dùng chung với danh sách giọng của app.
    var availableVoices: [Voice] {
        guard state == .ready else { return [] }
        let all = ["M1", "F1"] + Self.optionalVoices
        return all.compactMap { name -> Voice? in
            guard FileManager.default.fileExists(atPath: directory.appendingPathComponent("voice_styles/\(name).json").path) else { return nil }
            let male = name.hasPrefix("M")
            let n = String(name.dropFirst())
            return Voice(id: "Supertonic \(male ? "Nam" : "Nữ") \(n)",
                         description: "Supertonic-3 · giọng \(male ? "nam" : "nữ") \(n)",
                         gender: male ? "male" : "female",
                         speakerEmb: [], style: [], isCustom: false,
                         engine: "supertonic", preset: name)
        }
    }

    private func fetch(_ name: String, index: Int, count: Int, optional: Bool) async throws {
        let dest = directory.appendingPathComponent(name)
        if FileManager.default.fileExists(atPath: dest.path) { return }
        statusText = "(\(index + 1)/\(count)) \(name)"
        fileProgress = 0
        guard let url = URL(string: "https://huggingface.co/\(Self.repo)/resolve/\(Self.revision)/\(name)") else { return }
        let dl = FileDownloader(destination: dest) { [weak self] written, total in
            let mb = Double(written) / 1_048_576
            Task { @MainActor in
                guard let self else { return }
                if total > 0 {
                    self.statusText = String(format: "(%d/%d) %@ — %.0f / %.0f MB", index + 1, count, name, mb, Double(total) / 1_048_576)
                    self.fileProgress = Double(written) / Double(total)
                } else {
                    self.statusText = String(format: "(%d/%d) %@ — %.0f MB", index + 1, count, name, mb)
                }
            }
        }
        do { try await dl.start(url: url) } catch { if !optional { throw error } }
    }

    func download() async {
        guard state != .downloading else { return }
        state = .downloading
        do {
            let optional = Self.optionalVoices.map { "voice_styles/\($0).json" }
            let count = Self.requiredFiles.count + optional.count
            for (i, f) in Self.requiredFiles.enumerated() { try await fetch(f, index: i, count: count, optional: false) }
            for (j, f) in optional.enumerated() { try await fetch(f, index: Self.requiredFiles.count + j, count: count, optional: true) }
            state = Self.requiredPresent(in: directory) ? .ready : .notInstalled
        } catch {
            state = .failed(error.localizedDescription)
        }
        onChange?()
    }

    func deleteModel() {
        try? FileManager.default.removeItem(at: directory)
        for sub in ["onnx", "voice_styles"] {
            try? FileManager.default.createDirectory(at: directory.appendingPathComponent(sub, isDirectory: true),
                                                     withIntermediateDirectories: true)
        }
        state = .notInstalled
        onChange?()
    }
}
