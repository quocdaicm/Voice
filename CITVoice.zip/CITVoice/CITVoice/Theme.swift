import SwiftUI
import UIKit

// MARK: - Màu & gradient thương hiệu

enum Brand {
    static let indigo = Color(red: 0.369, green: 0.361, blue: 0.902)   // #5E5CE6
    static let violet = Color(red: 0.482, green: 0.302, blue: 0.941)   // #7B4DF0
    static let purple = Color(red: 0.753, green: 0.333, blue: 0.949)   // #C055F2

    static let gradient = LinearGradient(
        colors: [indigo, violet, purple],
        startPoint: .topLeading, endPoint: .bottomTrailing)
}

// MARK: - Logo vẽ bằng code (khớp với icon app)

struct LogoMark: View {
    var size: CGFloat = 40

    private let heights: [CGFloat] = [0.23, 0.47, 0.73, 1.0, 0.73, 0.47, 0.23]

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.225, style: .continuous)
                .fill(Brand.gradient)
            RoundedRectangle(cornerRadius: size * 0.225, style: .continuous)
                .fill(RadialGradient(colors: [.white.opacity(0.32), .clear],
                                     center: UnitPoint(x: 0.28, y: 0.18),
                                     startRadius: 0, endRadius: size * 0.9))
            HStack(spacing: size * 0.04) {
                ForEach(0..<heights.count, id: \.self) { i in
                    Capsule()
                        .fill(.white.opacity(i == 0 || i == 6 ? 0.72 : (i == 1 || i == 5 ? 0.86 : 1)))
                        .frame(width: i == 3 ? size * 0.11 : size * 0.066,
                               height: size * 0.66 * heights[i])
                }
            }
        }
        .frame(width: size, height: size)
        .shadow(color: Brand.indigo.opacity(0.35), radius: size * 0.16, y: size * 0.08)
        .accessibilityHidden(true)
    }
}

// MARK: - Thẻ (card) kiểu iOS grouped

struct Card<Content: View>: View {
    var title: String?
    var icon: String?
    let content: () -> Content

    init(_ title: String? = nil, icon: String? = nil, @ViewBuilder content: @escaping () -> Content) {
        self.title = title
        self.icon = icon
        self.content = content
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let title {
                HStack(spacing: 6) {
                    if let icon {
                        Image(systemName: icon)
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(Brand.indigo)
                    }
                    Text(title)
                        .font(.footnote.weight(.semibold))
                        .textCase(.uppercase)
                        .foregroundStyle(.secondary)
                }
            }
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.35), lineWidth: 0.5)
        )
        .shadow(color: .black.opacity(0.06), radius: 10, y: 4)
    }
}

// MARK: - Nút

struct PrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 54)
            .background(
                Image("BtnPrimary")                       // SVG vector (Assets.xcassets)
                    .resizable()
                    .scaledToFill()
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .opacity(isEnabled ? 1 : 0.4)
            )
            .shadow(color: Brand.indigo.opacity(isEnabled ? 0.35 : 0), radius: 12, y: 6)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct SoftButtonStyle: ButtonStyle {
    var tint: Color = Brand.indigo

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(tint)
            .padding(.horizontal, 14)
            .frame(minHeight: 40)
            .background(tint.opacity(configuration.isPressed ? 0.22 : 0.12),
                        in: Capsule())
            .animation(.easeOut(duration: 0.15), value: configuration.isPressed)
    }
}

struct CircleIconButtonStyle: ButtonStyle {
    var danger = false
    var size: CGFloat = 48

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(
                Image(danger ? "BtnRoundRed" : "BtnRound")   // SVG vector
                    .resizable()
                    .scaledToFit()
            )
            .shadow(color: (danger ? Color.red : Brand.indigo).opacity(0.3), radius: 8, y: 4)
            .scaleEffect(configuration.isPressed ? 0.92 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

/// Nút ghi âm lớn: nền SVG có quầng sáng + vòng, icon SVG ở giữa.
struct RecordButton: View {
    var isRecording: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                Image(isRecording ? "BtnRecordRed" : "BtnRecord")
                    .resizable().scaledToFit()
                SVGIcon(isRecording ? "IcStop" : "IcMic", size: 32)
                    .foregroundStyle(.white)
            }
            .frame(width: 128, height: 128)
        }
        .buttonStyle(PressScaleStyle())
        .accessibilityLabel(isRecording ? "Dừng ghi" : "Ghi âm giọng mẫu")
    }
}

struct PressScaleStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

// MARK: - Icon SVG (template, tô màu theo foregroundStyle)

struct SVGIcon: View {
    let name: String
    var size: CGFloat = 20
    init(_ name: String, size: CGFloat = 20) { self.name = name; self.size = size }

    var body: some View {
        Image(name)
            .renderingMode(.template)
            .resizable()
            .scaledToFit()
            .frame(width: size, height: size)
    }
}

/// Icon SVG + chữ (thay cho Label(systemImage:)).
struct SVGLabel: View {
    let title: String
    let icon: String
    var size: CGFloat = 18
    init(_ title: String, icon: String, size: CGFloat = 18) { self.title = title; self.icon = icon; self.size = size }

    var body: some View {
        HStack(spacing: 6) {
            SVGIcon(icon, size: size)
            Text(title)
        }
    }
}

// MARK: - Nền & banner SVG

/// Nền aurora toàn màn hình (SVG, có bản Sáng/Tối trong Assets).
struct AuroraBackground: View {
    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
            Image("BgAurora")
                .resizable()
                .scaledToFill()
        }
        .ignoresSafeArea()
    }
}

/// Banner đầu trang: nền SVG gradient + sóng âm, logo và tiêu đề đè lên.
struct HeroBanner: View {
    var body: some View {
        ZStack(alignment: .leading) {
            Image("HeroWave")
                .resizable()
                .scaledToFill()
            HStack(spacing: 14) {
                LogoMark(size: 56)
                Text("CIT Voice")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white)
            .padding(.leading, 18)
        }
        .frame(height: 124)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .shadow(color: Brand.indigo.opacity(0.35), radius: 16, y: 8)
        .accessibilityElement(children: .combine)
    }
}

// MARK: - Hàng trong thẻ (icon vuông bo góc như Cài đặt iOS)

struct IconBadge: View {
    let systemName: String
    var color: Color = Brand.indigo

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: 30, height: 30)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: 7, style: .continuous))
    }
}

// MARK: - Trạng thái (pill)

struct StatusPill: View {
    let text: String
    let systemImage: String
    let color: Color

    var body: some View {
        Label(text, systemImage: systemImage)
            .font(.caption.weight(.semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(color.opacity(0.14), in: Capsule())
    }
}

// MARK: - Haptics

enum Haptics {
    static func tap() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func select() { UISelectionFeedbackGenerator().selectionChanged() }
    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    static func error() { UINotificationFeedbackGenerator().notificationOccurred(.error) }
}

// MARK: - Sóng âm động (hiển thị khi đang phát / đang tạo)

struct WaveformBars: View {
    var active: Bool
    var color: Color = Brand.indigo
    private let base: [CGFloat] = [0.35, 0.65, 1.0, 0.7, 0.45, 0.85, 0.5]

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !active)) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate
            HStack(spacing: 3) {
                ForEach(0..<base.count, id: \.self) { i in
                    let wobble: CGFloat = active ? CGFloat((sin(t * 6 + Double(i) * 0.9) + 1) / 2) : 0.5
                    let level: CGFloat = active ? (0.35 + 0.65 * wobble) : 0.6
                    let barHeight: CGFloat = 6 + 18 * base[i] * level
                    Capsule()
                        .fill(color)
                        .frame(width: 3.5, height: barHeight)
                }
            }
            .frame(height: 26)
        }
    }
}

// MARK: - Ẩn bàn phím

func hideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                                    to: nil, from: nil, for: nil)
}

extension View {
    /// Chạm vào vùng trống (hoặc kéo cuộn) thì ẩn bàn phím; không chặn các nút bên trong.
    func dismissKeyboardOnTap() -> some View {
        simultaneousGesture(TapGesture().onEnded { hideKeyboard() })
    }

    /// Nút "Xong" phía trên bàn phím.
    func keyboardDoneButton() -> some View {
        toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Xong") { hideKeyboard() }.fontWeight(.semibold)
            }
        }
    }
}
