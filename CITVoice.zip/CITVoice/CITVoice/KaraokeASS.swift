import Foundation

// =============================================================================
//  KaraokeASS (v0.12) — xuất phụ đề karaoke (.ass): từng từ "sáng" dần theo giọng đọc.
//
//  Ý TƯỞNG và cấu trúc tệp tham khảo VoiceStudio (https://github.com/debpalash/VoiceStudio, AGPL-3.0,
//  services/karaoke_ass.py): mỗi dòng phụ đề là một sự kiện `Dialogue` với các thẻ `\kf` cho từng từ,
//  độ dài thẻ tính bằng hiệu của các mốc đã làm tròn centi giây để không bị trôi dần ở dòng dài.
//  Mã Swift TỰ VIẾT LẠI, không chép mã nguồn. Điểm khác: chia thời gian theo độ dài từ (và dấu ngắt)
//  thay vì chia đều, vì tiếng Việt mỗi từ dài ngắn khác nhau.
//
//  Dùng với: VLC, ffmpeg (`-vf ass=...`), CapCut/Premiere (qua công cụ nhập .ass) hoặc trình dựng phụ đề khác.
// =============================================================================

enum KaraokeASS {
    struct Style {
        var fontName = "Arial"
        var fontSize = 64
        /// Màu đã đọc xong (ASS dùng &HAABBGGRR). Mặc định vàng.
        var highlight = "&H0000E7FF"
        /// Màu chưa đọc tới. Mặc định trắng.
        var base = "&H00FFFFFF"
        var outline = "&H00101010"
    }

    /// Dựng nội dung .ass từ các dòng phụ đề (thường là dòng đã khớp giọng, xem `DubbingModel.fittedCues`).
    static func build(_ cues: [SubtitleCue], playRes: (x: Int, y: Int) = (1920, 1080), style: Style = Style()) -> String {
        var out = """
        [Script Info]
        ; Tạo bởi CIT Voice
        ScriptType: v4.00+
        PlayResX: \(playRes.x)
        PlayResY: \(playRes.y)
        WrapStyle: 0
        ScaledBorderAndShadow: yes

        [V4+ Styles]
        Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
        Style: Default,\(style.fontName),\(style.fontSize),\(style.highlight),\(style.base),\(style.outline),&H7F000000,0,0,0,0,100,100,0,0,1,3,1,2,96,96,48,1

        [Events]
        Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text

        """
        for c in cues.sorted(by: { $0.start < $1.start }) {
            let text = c.text.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard !text.isEmpty else { continue }
            let start = c.start
            let end = max(c.end, c.start + 0.1)
            out += "Dialogue: 0,\(stamp(start)),\(stamp(end)),Default,,0,0,0,,\(karaokeText(text, start: start, end: end))\n"
        }
        return out
    }

    // MARK: - Từng dòng

    /// `{\kf…}từ {\kf…}từ …` — mỗi từ quét đến lúc từ sau bắt đầu, từ cuối quét đến hết dòng.
    static func karaokeText(_ text: String, start: Double, end: Double) -> String {
        let tokens = text.split(whereSeparator: { $0.isWhitespace }).map(String.init)
        guard !tokens.isEmpty else { return "" }
        let weights = tokens.map(weight)
        let total = max(weights.reduce(0, +), 1)
        var starts: [Double] = []
        var acc = 0.0
        for w in weights {
            starts.append(start + (end - start) * acc / total)
            acc += w
        }
        var out = ""
        var at = cs(start)
        for (i, tok) in tokens.enumerated() {
            let nextTime = i + 1 < tokens.count ? starts[i + 1] : end
            let next = max(cs(nextTime), at + 1)          // thẻ không bao giờ dài 0
            out += "{\\kf\(next - at)}\(escape(tok))\(i + 1 < tokens.count ? " " : "")"
            at = next
        }
        return out
    }

    /// Mốc bắt đầu/kết thúc từng từ trong một dòng (cùng cách chia như `karaokeText`). Dùng cho video karaoke.
    static func wordTimings(_ text: String, start: Double, end: Double) -> [(token: String, start: Double, end: Double)] {
        let tokens = text.split(whereSeparator: { $0.isWhitespace }).map(String.init)
        guard !tokens.isEmpty else { return [] }
        let weights = tokens.map(weight)
        let total = max(weights.reduce(0, +), 1)
        var out: [(token: String, start: Double, end: Double)] = []
        var acc = 0.0
        for (i, tok) in tokens.enumerated() {
            let a = start + (end - start) * acc / total
            acc += weights[i]
            let b = start + (end - start) * acc / total
            out.append((tok, a, b))
        }
        return out
    }

    /// Trọng số thời gian của một từ: theo số ký tự chữ, cộng thêm khi có dấu ngắt (đọc tới đó thường nghỉ).
    private static func weight(_ token: String) -> Double {
        let letters = token.filter { $0.isLetter || $0.isNumber }.count
        var w = Double(max(letters, 1))
        if let last = token.last {
            if ",;:".contains(last) { w += 2 }
            else if ".!?…".contains(last) { w += 4 }
        }
        return w
    }

    // MARK: - Định dạng

    private static func cs(_ seconds: Double) -> Int { Int((seconds * 100).rounded()) }

    /// H:MM:SS.CC
    private static func stamp(_ seconds: Double) -> String {
        let total = max(0, cs(seconds))
        let h = total / 360_000
        let m = (total % 360_000) / 6000
        let s = (total % 6000) / 100
        let c = total % 100
        return String(format: "%d:%02d:%02d.%02d", h, m, s, c)
    }

    /// Dấu ngoặc nhọn sẽ mở khối lệnh của ASS nên phải thoát; xuống dòng thành \N.
    private static func escape(_ t: String) -> String {
        t.replacingOccurrences(of: "{", with: "\\{")
            .replacingOccurrences(of: "}", with: "\\}")
            .replacingOccurrences(of: "\r\n", with: "\\N")
            .replacingOccurrences(of: "\n", with: "\\N")
            .replacingOccurrences(of: "\r", with: "\\N")
    }
}
