import Foundation
import CryptoKit

// =============================================================================
//  DubFit (v0.9) — khớp độ dài giọng lồng tiếng với khung phụ đề.
//
//  Ý TƯỞNG tham khảo từ VoiceStudio (https://github.com/debpalash/VoiceStudio, AGPL-3.0):
//   - ước lượng thời lượng đọc theo "ký tự / giây" của từng ngôn ngữ (services/speech_rate.py;
//     con số 16 ký tự/giây cho tiếng Việt lấy từ bảng của dự án đó),
//   - "đo lại thay vì đoán": sau khi tạo giọng thì đo độ dài thật rồi mới chỉnh tốc độ (fit_planner / dub_qc),
//   - cân bằng âm lượng giữa các dòng.
//  Toàn bộ mã Swift bên dưới TỰ VIẾT LẠI, không chép mã nguồn của VoiceStudio.
//  Ghi công nằm ở `Licenses.swift` và `THIRD_PARTY_NOTICES.md`.
// =============================================================================

/// Một dòng vẫn đọc dài hơn khung dù đã đọc nhanh tối đa.
struct DubCueReport: Identifiable {
    let id = UUID()
    let number: Int          // số thứ tự dòng trong phụ đề
    let start: Double        // giây
    let text: String
    let available: Double    // khung cho phép (giây)
    let length: Double       // độ dài giọng thật (giây)
    let speed: Float         // tốc độ đã dùng ở lần tạo cuối
}

/// Gom số đo thật (ký tự / giây) trong lúc tạo giọng để lần sau dự đoán chuẩn hơn.
struct RateTracker {
    private(set) var chars = 0
    private(set) var seconds = 0.0     // đã quy về tốc độ 1.0x

    mutating func add(text: String, seconds s: Double, speed: Float) {
        let c = DubFit.charCount(text)
        guard c > 0, s > 0.05, speed > 0 else { return }
        chars += c
        seconds += s * Double(speed)
    }

    /// Ký tự / giây ở tốc độ 1.0x; nil nếu chưa đủ dữ liệu.
    var cps: Double? {
        guard chars >= 150, seconds > 3 else { return nil }
        return Double(chars) / seconds
    }
}

enum DubFit {
    /// Tiếng Việt, theo bảng của VoiceStudio (chỉ là mốc khởi đầu, app tự học lại từ giọng đang dùng).
    static let defaultCPS = 16.0
    static let maxSpeed: Double = 1.6
    private static let cpsKey = "dub.cps1"

    /// Ký tự / giây đã học (ở tốc độ 1.0x).
    static var learnedCPS: Double {
        let v = UserDefaults.standard.double(forKey: cpsKey)
        return (v > 4 && v < 40) ? v : defaultCPS
    }

    /// Trộn số đo mới vào giá trị đã học (nửa cũ, nửa mới).
    static func learn(from tracker: RateTracker) {
        guard let measured = tracker.cps, measured > 4, measured < 40 else { return }
        let blended = 0.5 * learnedCPS + 0.5 * measured
        UserDefaults.standard.set(blended, forKey: cpsKey)
    }

    static func charCount(_ text: String) -> Int {
        text.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "\n", with: " ")
            .count
    }

    // MARK: - Dự báo trước khi tạo

    struct Forecast {
        var total = 0
        var needFaster = 0      // phải đọc nhanh hơn tốc độ đang chọn
        var hopeless = 0        // kể cả 1.6x cũng không kịp
    }

    static func forecast(cues: [SubtitleCue], videoDuration: Double, speed: Double) -> Forecast {
        let list = cues.sorted { $0.start < $1.start }
            .filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        var f = Forecast()
        let cps = learnedCPS * max(0.3, speed)
        for (i, c) in list.enumerated() {
            let nextStart = i + 1 < list.count ? list[i + 1].start : max(videoDuration, c.end + 1)
            let available = max(0.4, nextStart - c.start - 0.05)
            let need = Double(charCount(c.text)) / cps / available
            f.total += 1
            if need > 1.0 { f.needFaster += 1 }
            if need > maxSpeed { f.hopeless += 1 }
        }
        return f
    }

    // MARK: - Cân bằng âm lượng giữa các dòng

    /// RMS của phần có tiếng (bỏ đoạn im). 0 nếu quá ngắn / quá nhỏ.
    static func rms(_ wav: [Float]) -> Float {
        var sum = 0.0
        var n = 0
        for s in wav {
            let a = abs(s)
            if a > 0.01 { sum += Double(a * a); n += 1 }
        }
        guard n > 200 else { return 0 }
        return Float((sum / Double(n)).squareRoot())
    }

    /// Đưa dòng về gần mức `reference`, tối đa ±4 dB, không vượt đỉnh 0.95.
    static func leveled(_ wav: [Float], rms r: Float, reference: Float) -> [Float] {
        guard r > 0, reference > 0, !wav.isEmpty else { return wav }
        let lim = powf(10, 4.0 / 20)
        var g = reference / r
        g = min(max(g, 1 / lim), lim)
        var peak: Float = 0
        for s in wav { peak = max(peak, abs(s)) }
        if peak > 0 { g = min(g, 0.95 / peak) }
        if abs(g - 1) < 0.03 { return wav }
        return wav.map { $0 * g }
    }
}

// =============================================================================
//  DubCache (v0.10) — nhớ giọng từng dòng đã tạo để sửa vài dòng rồi tạo lại không phải đọc lại cả video.
//  Ý tưởng "tạo lại phần thay đổi" tham khảo VoiceStudio (dub_resume / incremental), mã tự viết.
//  Khoá = văn bản + giọng + tốc độ/chất lượng + khung cho phép + tần số lấy mẫu; đổi bất kỳ thứ gì thì tạo lại dòng đó.
// =============================================================================
enum DubCache {
    private static var dir: URL {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let d = base.appendingPathComponent("DubCache", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    static func key(text: String, voice: Voice, steps: Int, cfg: Float, sway: Float,
                    baseSpeed: Float, available: Double, sr: Int) -> String {
        let fp = voice.speakerEmb.prefix(8).map { String(format: "%.4f", $0) }.joined(separator: ",")
        let raw = [text.trimmingCharacters(in: .whitespacesAndNewlines), voice.id, fp,
                   "\(voice.speakerEmb.count)", "\(steps)", String(format: "%.2f", cfg),
                   String(format: "%.2f", sway), String(format: "%.3f", baseSpeed),
                   "\(Int((available * 20).rounded()))", "\(sr)"].joined(separator: "|")
        return SHA256.hash(data: Data(raw.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    /// Tệp: 4 byte đầu là tốc độ đã dùng (Float32), phần còn lại là mẫu âm Float32.
    static func load(_ key: String) -> (samples: [Float], speed: Float)? {
        let url = dir.appendingPathComponent(key + ".f32")
        guard let data = try? Data(contentsOf: url), data.count >= 8 else { return nil }
        let count = data.count / 4
        var floats = [Float](repeating: 0, count: count)
        _ = floats.withUnsafeMutableBytes { data.copyBytes(to: $0) }
        let speed = floats.removeFirst()
        try? FileManager.default.setAttributes([.modificationDate: Date()], ofItemAtPath: url.path)
        guard speed > 0, speed < 4, !floats.isEmpty else { return nil }
        return (floats, speed)
    }

    static func store(_ key: String, samples: [Float], speed: Float) {
        guard !samples.isEmpty else { return }
        var all = [speed]
        all.append(contentsOf: samples)
        let data = all.withUnsafeBufferPointer { Data(buffer: $0) }
        try? data.write(to: dir.appendingPathComponent(key + ".f32"), options: .atomic)
    }

    static var sizeMB: Double {
        let files = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.fileSizeKey])) ?? []
        let total = files.reduce(0) { $0 + ((try? $1.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0) }
        return Double(total) / 1_048_576
    }

    static func clear() {
        try? FileManager.default.removeItem(at: dir)
    }

    /// Giữ bộ nhớ đệm không quá `maxMB`: xoá tệp cũ nhất trước.
    static func trim(maxMB: Double = 400) {
        let fm = FileManager.default
        let keys: [URLResourceKey] = [.fileSizeKey, .contentModificationDateKey]
        guard let files = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys) else { return }
        var entries = files.map { u -> (URL, Int, Date) in
            let v = try? u.resourceValues(forKeys: Set(keys))
            return (u, v?.fileSize ?? 0, v?.contentModificationDate ?? .distantPast)
        }
        var total = entries.reduce(0) { $0 + $1.1 }
        let limit = Int(maxMB * 1_048_576)
        guard total > limit else { return }
        entries.sort { $0.2 < $1.2 }
        for e in entries where total > limit {
            try? fm.removeItem(at: e.0)
            total -= e.1
        }
    }
}
