import SwiftUI
import UIKit
import UniformTypeIdentifiers

// MARK: - File giọng (JSON, cùng định dạng voices_v3_nano.json)

enum VoiceFileError: LocalizedError {
    case invalid
    var errorDescription: String? {
        "File không phải file giọng hợp lệ (cần JSON có mục \"presets\", mỗi giọng gồm speaker_emb 192 số và style 50×256)."
    }
}

enum VoiceFileIO {
    private struct File: Codable {
        var default_voice: String?
        var presets: [String: Preset]
    }
    private struct Preset: Codable {
        var description: String
        var gender: String
        var speaker_emb: [Float]
        var style: [[Float]]
    }

    static func encode(_ voices: [Voice]) throws -> Data {
        var presets: [String: Preset] = [:]
        for v in voices {
            presets[v.id] = Preset(description: v.description, gender: v.gender,
                                   speaker_emb: v.speakerEmb, style: v.style)
        }
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        return try enc.encode(File(default_voice: voices.first?.id, presets: presets))
    }

    static func decode(_ data: Data) throws -> [Voice] {
        guard let file = try? JSONDecoder().decode(File.self, from: data) else { throw VoiceFileError.invalid }
        let list = file.presets.compactMap { key, p -> Voice? in
            guard p.speaker_emb.count == 192, p.style.count == 50, p.style.allSatisfy({ $0.count == 256 }) else { return nil }
            return Voice(id: key, description: p.description, gender: p.gender,
                         speakerEmb: p.speaker_emb, style: p.style, isCustom: true)
        }
        guard !list.isEmpty else { throw VoiceFileError.invalid }
        return list.sorted { $0.id.localizedCompare($1.id) == .orderedAscending }
    }
}

// MARK: - Sao lưu / khôi phục model

enum ModelBackupError: LocalizedError {
    case notFound
    case notReady
    var errorDescription: String? {
        switch self {
        case .notFound: return "Thư mục đã chọn không có đủ file model (cần config.json, constants.npz và 4 file .onnx)."
        case .notReady: return "Chưa có model để sao lưu."
        }
    }
}

extension ModelStore {
    static let backupFolderName = "CITVoice-Model"
    static let backupInfoName = "citvoice-model-info.json"
    private static let markers = [".bool-patched", ".clone-patched"]

    /// Tạo thư mục tạm chứa model (liên kết cứng, không tốn thêm dung lượng) kèm file thông tin đã vá.
    func makeBackupFolder() throws -> URL {
        guard state == .ready else { throw ModelBackupError.notReady }
        let fm = FileManager.default
        let stage = fm.temporaryDirectory.appendingPathComponent(Self.backupFolderName, isDirectory: true)
        try? fm.removeItem(at: stage)
        try fm.createDirectory(at: stage, withIntermediateDirectories: true)
        for name in Self.files + Self.cloneFiles {
            let src = directory.appendingPathComponent(name)
            guard fm.fileExists(atPath: src.path) else { continue }
            let dst = stage.appendingPathComponent(name)
            do { try fm.linkItem(at: src, to: dst) } catch { try fm.copyItem(at: src, to: dst) }
        }
        let info: [String: Bool] = [
            "boolPatched": fm.fileExists(atPath: directory.appendingPathComponent(".bool-patched").path),
            "clonePatched": fm.fileExists(atPath: directory.appendingPathComponent(".clone-patched").path),
        ]
        try JSONEncoder().encode(info).write(to: stage.appendingPathComponent(Self.backupInfoName))
        return stage
    }

    private static func locate(in picked: URL) -> URL? {
        let fm = FileManager.default
        func ok(_ u: URL) -> Bool {
            files.allSatisfy { fm.fileExists(atPath: u.appendingPathComponent($0).path) }
        }
        if ok(picked) { return picked }
        let sub = picked.appendingPathComponent(backupFolderName, isDirectory: true)
        if ok(sub) { return sub }
        if let kids = try? fm.contentsOfDirectory(at: picked, includingPropertiesForKeys: nil) {
            for k in kids where ok(k) { return k }
        }
        return nil
    }

    /// Chép model từ thư mục sao lưu vào app. Trả về số file đã chép.
    func restore(from picked: URL) async throws -> Int {
        let scoped = picked.startAccessingSecurityScopedResource()
        defer { if scoped { picked.stopAccessingSecurityScopedResource() } }
        guard let src = Self.locate(in: picked) else { throw ModelBackupError.notFound }
        let dir = directory
        let names = Self.files + Self.cloneFiles
        let markers = Self.markers
        let cloneNames = Self.cloneFiles
        let infoName = Self.backupInfoName

        let copied = try await Task.detached(priority: .userInitiated) { () throws -> Int in
            let fm = FileManager.default
            var count = 0
            var copiedClone = false
            for name in names {
                let from = src.appendingPathComponent(name)
                guard fm.fileExists(atPath: from.path) else { continue }
                let tmp = dir.appendingPathComponent(name + ".restoring")
                try? fm.removeItem(at: tmp)
                var coordErr: NSError?
                var inner: Error?
                NSFileCoordinator().coordinate(readingItemAt: from, options: [], error: &coordErr) { readable in
                    do { try fm.copyItem(at: readable, to: tmp) } catch { inner = error }
                }
                if let e = coordErr ?? inner { try? fm.removeItem(at: tmp); throw e }
                let dest = dir.appendingPathComponent(name)
                try? fm.removeItem(at: dest)
                try fm.moveItem(at: tmp, to: dest)
                count += 1
                if cloneNames.contains(name) { copiedClone = true }
            }
            // dấu "đã vá" theo file thông tin của bản sao lưu; không có thì để app vá lại
            var info: [String: Bool] = [:]
            if let d = try? Data(contentsOf: src.appendingPathComponent(infoName)),
               let j = try? JSONDecoder().decode([String: Bool].self, from: d) { info = j }
            try? fm.removeItem(at: dir.appendingPathComponent(markers[0]))
            if info["boolPatched"] == true { try Data().write(to: dir.appendingPathComponent(markers[0])) }
            if copiedClone {
                try? fm.removeItem(at: dir.appendingPathComponent(markers[1]))
                if info["clonePatched"] == true { try Data().write(to: dir.appendingPathComponent(markers[1])) }
            }
            return count
        }.value

        state = Self.allFilesPresent(Self.files, in: dir) ? .ready : .notInstalled
        cloneState = Self.allFilesPresent(Self.cloneFiles, in: dir) ? .ready : .notInstalled
        return copied
    }
}

// MARK: - Chọn nơi lưu (Tệp)

struct ExportJob: Identifiable {
    let id = UUID()
    let urls: [URL]
    var cleanup: URL?
}

struct ExportPicker: UIViewControllerRepresentable {
    let job: ExportJob
    var onFinish: () -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let p = UIDocumentPickerViewController(forExporting: job.urls, asCopy: true)
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(onFinish) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onFinish: () -> Void
        init(_ f: @escaping () -> Void) { onFinish = f }
        func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { onFinish() }
        func documentPickerWasCancelled(_ c: UIDocumentPickerViewController) { onFinish() }
    }
}

// MARK: - Thẻ giao diện

struct BackupCard: View {
    @ObservedObject var store: ModelStore
    @ObservedObject var model: AppModel

    private enum Kind { case voices, model }

    @State private var importKind: Kind = .voices
    @State private var importing = false
    @State private var exportJob: ExportJob?
    @State private var busy: String?
    @State private var message: String?

    private var customCount: Int { model.voices.filter { $0.isCustom }.count }

    private var importTypes: [UTType] {
        importKind == .voices ? [.json] : [.folder]
    }

    var body: some View {
        Card("Sao lưu & khôi phục", icon: "externaldrive") {
            Text("Giọng nói").font(.subheadline.weight(.semibold))
            HStack(spacing: 8) {
                Button { importKind = .voices; importing = true } label: {
                    pill("Nhập giọng", "square.and.arrow.down")
                }
                Button { exportVoices() } label: {
                    pill("Lưu giọng đã nhân bản (\(customCount))", "square.and.arrow.up")
                }
                .disabled(customCount == 0)
            }
            Divider()
            Text("Model giọng nói").font(.subheadline.weight(.semibold))
            HStack(spacing: 8) {
                Button { exportModel() } label: { pill("Lưu model ra máy", "externaldrive.badge.plus") }
                    .disabled(store.state != .ready)
                Button { importKind = .model; importing = true } label: { pill("Khôi phục model", "arrow.counterclockwise") }
            }
            if let busy {
                HStack(spacing: 8) { ProgressView(); Text(busy).font(.footnote) }
            }
            if let message {
                Text(message).font(.footnote).foregroundStyle(.secondary)
            }
            Text("Giọng được lưu thành một file .json, model thành thư mục \(ModelStore.backupFolderName) — chọn nơi lưu trong app Tệp (hoặc iCloud Drive). Khi cần, bấm Nhập giọng / Khôi phục model và chọn lại file hoặc thư mục đó, không phải tải lại.")
                .font(.caption).foregroundStyle(.secondary)
        }
        .disabled(busy != nil || model.isGenerating)
        .filePicker(isPresented: $importing, types: importTypes) { result in
            switch result {
            case .success(let url): handleImport(url)
            case .failure(let e): message = e.localizedDescription
            }
        }
        .sheet(item: $exportJob) { job in
            ExportPicker(job: job) {
                if let c = job.cleanup { try? FileManager.default.removeItem(at: c) }
                exportJob = nil
            }
        }
    }

    private func pill(_ title: String, _ system: String) -> some View {
        Label(title, systemImage: system)
            .font(.footnote.weight(.semibold))
            .foregroundStyle(Brand.indigo)
            .padding(.horizontal, 12)
            .frame(minHeight: 38)
            .background(Brand.indigo.opacity(0.12), in: Capsule())
    }

    private func exportVoices() {
        do {
            guard let url = try model.exportCustomVoicesFile() else { message = "Chưa có giọng nhân bản nào để lưu."; return }
            message = nil
            exportJob = ExportJob(urls: [url], cleanup: url)
        } catch { message = error.localizedDescription }
    }

    private func exportModel() {
        busy = "Đang chuẩn bị…"
        message = nil
        Task {
            defer { busy = nil }
            do {
                let folder = try store.makeBackupFolder()
                exportJob = ExportJob(urls: [folder], cleanup: folder)
            } catch { message = error.localizedDescription }
        }
    }

    private func handleImport(_ url: URL) {
        switch importKind {
        case .voices:
            do {
                let n = try model.importVoices(from: url)
                message = "Đã nhập \(n) giọng."
                Haptics.success()
            } catch {
                message = error.localizedDescription
                Haptics.error()
            }
        case .model:
            busy = "Đang chép model vào app…"
            message = nil
            Task {
                defer { busy = nil }
                do {
                    let n = try await store.restore(from: url)
                    model.resetEngine()
                    message = "Đã khôi phục \(n) file model."
                    Haptics.success()
                } catch {
                    message = error.localizedDescription
                    Haptics.error()
                }
            }
        }
    }
}
