import SwiftUI
import AVFoundation
import PhotosUI
import Photos

/// Video chọn từ thư viện ảnh: chép ra thư mục tạm để dùng.
struct PickedVideo: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .movie) { received in
            let ext = received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent("dub-src-\(UUID().uuidString).\(ext)")
            try FileManager.default.copyItem(at: received.file, to: dest)
            return PickedVideo(url: dest)
        }
    }
}

@MainActor
final class DubbingModel: ObservableObject {
    enum Phase: Equatable { case idle, separating, synthesizing, exporting }

    @Published var videoURL: URL?
    @Published var videoName = ""
    @Published var videoDuration: Double = 0
    @Published var thumbnail: UIImage?
    @Published var cues: [SubtitleCue] = []
    @Published var subtitleName = ""
    @Published var keepOriginal = true
    @Published var originalLevel: Double = 0.9   // âm gốc khi không có giọng lồng tiếng
    @Published var duckLevel: Double = 0.15       // âm gốc khi giọng lồng tiếng đang đọc
    @Published var removeVoice = false            // tách lời gốc, chỉ giữ nhạc nền (cần model tách nhạc)

    @Published var phase: Phase = .idle
    @Published var progress: Double = 0
    @Published var statusText = ""
    @Published var outputURL: URL?
    @Published var tightCount = 0
    @Published var tightLines: [DubCueReport] = []   // dòng vẫn dài hơn khung dù đã đọc nhanh tối đa
    @Published var speedUpCount = 0                  // số dòng phải đọc nhanh hơn tốc độ đã chọn
    @Published var cachedCount = 0                   // số dòng dùng lại từ bộ nhớ đệm (không phải tạo lại)
    @Published var fittedSRT: URL?                   // phụ đề với mốc thời gian khớp giọng lồng tiếng
    @Published var karaokeASS: URL?                  // phụ đề karaoke (.ass): từng từ sáng theo giọng
    @Published var karaokeVideoURL: URL?             // video đã vẽ chữ karaoke
    @Published var isMakingKaraoke = false
    @Published var karaokeProgress = 0.0
    @Published var karaokeError: String?
    private var fittedCues: [SubtitleCue] = []       // các dòng đã khớp giọng (nguồn cho .srt/.ass/video karaoke)
    private var karaokeTask: Task<Void, Never>?
    var hasFittedCues: Bool { !fittedCues.isEmpty }
    @Published var cacheMB: Double = DubCache.sizeMB
    @Published var errorMessage: String?
    @Published var savedMessage: String?
    @Published var previewingID: UUID?
    let previewPlayer = AudioPlayer()

    private var task: Task<Void, Never>?
    private let maxSpeed: Float = 1.6
    private var backgroundURL: URL?              // nhạc nền đã tách (dùng lại nếu chạy lại cùng video)
    private var backgroundSource: URL?

    var isBusy: Bool { phase != .idle }
    var canStart: Bool { videoURL != nil && !cues.isEmpty && !isBusy }

    // MARK: - Nạp dữ liệu

    func setVideo(url: URL, name: String) async {
        let asset = AVURLAsset(url: url)
        do {
            let d = try await asset.load(.duration).seconds
            guard d.isFinite, d > 0 else { throw DubError.noVideoTrack }
            if d > 30 * 60 { throw DubError.tooLong }
            videoDuration = d
        } catch {
            errorMessage = error.localizedDescription
            return
        }
        videoURL = url
        videoName = name
        discardBackground()
        outputURL = nil
        savedMessage = nil
        tightCount = 0
        tightLines = []
        speedUpCount = 0
        cachedCount = 0
        fittedSRT = nil
        karaokeASS = nil
        karaokeVideoURL = nil
        karaokeError = nil
        fittedCues = []
        thumbnail = await Task.detached(priority: .userInitiated) { () -> UIImage? in
            let gen = AVAssetImageGenerator(asset: AVURLAsset(url: url))
            gen.appliesPreferredTrackTransform = true
            gen.maximumSize = CGSize(width: 1000, height: 1000)
            guard let cg = try? gen.copyCGImage(at: CMTime(seconds: 0.5, preferredTimescale: 600), actualTime: nil)
            else { return nil }
            return UIImage(cgImage: cg)
        }.value
    }

    func setSubtitles(text: String, name: String) {
        let parsed = SubtitleParser.parse(text)
        guard !parsed.isEmpty else {
            errorMessage = "Không đọc được dòng phụ đề nào. Hãy dùng file .srt hoặc .vtt."
            return
        }
        cues = parsed
        subtitleName = name
        outputURL = nil
    }

    func setGenerated(cues newCues: [SubtitleCue], name: String) {
        cues = newCues
        subtitleName = name
        outputURL = nil
    }

    func loadEmbedded() async {
        guard let url = videoURL else { return }
        let found = await EmbeddedSubtitles.read(from: url)
        if found.isEmpty {
            errorMessage = "Video không có track phụ đề rời (phụ đề đóng cứng vào hình thì không đọc được). Hãy chọn file .srt."
        } else {
            cues = found
            subtitleName = "Phụ đề trong video"
            outputURL = nil
        }
    }

    // MARK: - Tạo video lồng tiếng

    /// Nghe thử giọng của một dòng phụ đề.
    func preview(cue: SubtitleCue, app: AppModel, store: ModelStore) {
        guard previewingID == nil, !isBusy else { return }
        let text = cue.text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        previewingID = cue.id
        Task {
            defer { previewingID = nil }
            do {
                guard let voice = app.voices.first(where: { $0.id == app.selectedVoiceID }) else { throw TTSError.voiceMissing }
                let (engine, _) = try await app.makeEngine(store: store)
                let opts = app.synthesisOptions()
                let wav = try await engine.synthesize(text: text, voice: voice, options: opts) { _ in }
                let url = FileManager.default.temporaryDirectory.appendingPathComponent("dub-preview.wav")
                try WAV.write(samples: wav, sampleRate: engine.sampleRate, to: url)
                previewPlayer.pause()
                previewPlayer.unload()
                try previewPlayer.play(url: url)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    /// Lưu video kết quả vào thư viện Ảnh.
    func saveToPhotos(_ url: URL) {
        Task {
            let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            guard status == .authorized || status == .limited else {
                errorMessage = "Chưa được cấp quyền lưu vào Ảnh. Vào Cài đặt > CIT Voice > Ảnh để cho phép."
                return
            }
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
                }
                savedMessage = "Đã lưu vào Ảnh."
                Haptics.success()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func cancel() { task?.cancel() }

    /// Vẽ chữ karaoke lên video đã lồng tiếng (`outputURL`) theo các dòng đã khớp giọng.
    func makeKaraokeVideo(style: KaraokeVideoStyle) {
        guard let input = outputURL, !fittedCues.isEmpty, !isMakingKaraoke else { return }
        isMakingKaraoke = true
        karaokeProgress = 0
        karaokeError = nil
        karaokeVideoURL = nil
        let cues = fittedCues
        karaokeTask = Task { [weak self] in
            defer { self?.isMakingKaraoke = false; self?.karaokeTask = nil }
            do {
                let url = try await KaraokeVideoExporter.export(video: input, cues: cues, style: style) { p in
                    Task { @MainActor in self?.karaokeProgress = p }
                }
                self?.karaokeVideoURL = url
            } catch is CancellationError {
                // người dùng bấm Huỷ
            } catch {
                self?.karaokeError = error.localizedDescription
            }
        }
    }

    func cancelKaraoke() { karaokeTask?.cancel() }

    func clearCache() {
        DubCache.clear()
        cacheMB = DubCache.sizeMB
    }

    private func discardBackground() {
        if let u = backgroundURL { try? FileManager.default.removeItem(at: u) }
        backgroundURL = nil
        backgroundSource = nil
    }

    func start(app: AppModel, store: ModelStore, stems: StemModelStore) {
        guard canStart, let video = videoURL else { return }
        let separate = keepOriginal && removeVoice
        if separate, stems.state != .ready {
            errorMessage = "Chưa tải model tách nhạc. Hãy tải ở mục \"Giọng đọc\" hoặc tắt tuỳ chọn tách lời."
            return
        }
        phase = separate ? .separating : .synthesizing
        progress = 0
        tightCount = 0
        tightLines = []
        speedUpCount = 0
        cachedCount = 0
        fittedSRT = nil
        karaokeASS = nil
        karaokeVideoURL = nil
        karaokeError = nil
        fittedCues = []
        outputURL = nil
        UIApplication.shared.isIdleTimerDisabled = true

        let cues = self.cues.sorted { $0.start < $1.start }.filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        guard !cues.isEmpty else { phase = .idle; errorMessage = "Phụ đề trống."; UIApplication.shared.isIdleTimerDisabled = false; return }
        let duration = videoDuration
        let keep = keepOriginal
        let level = Float(originalLevel)
        let duck = separate ? level : Float(duckLevel)      // đã tách lời thì không cần hạ nhạc khi giọng đọc nói
        let compiled = stems.compiledURL
        // phần trăm của từng giai đoạn: tách nhạc 35% (nếu bật) → tạo giọng → ghép video 15%
        let sepShare = separate ? 0.35 : 0.0
        let synthShare = 0.85 - sepShare
        var spans: [(start: Double, end: Double)] = []

        task = Task {
            defer {
                phase = .idle
                task = nil
                UIApplication.shared.isIdleTimerDisabled = false
            }
            do {
                guard let voice = app.voices.first(where: { $0.id == app.selectedVoiceID }) else { throw TTSError.voiceMissing }

                var bg: URL?
                if separate {
                    if let u = backgroundURL, backgroundSource == video, FileManager.default.fileExists(atPath: u.path) {
                        bg = u                                   // đã tách lần trước, dùng lại
                    } else {
                        discardBackground()
                        statusText = "Đang tách lời khỏi nhạc nền"
                        let out = try await StemSeparator.instrumental(from: video, compiledModel: compiled) { p in
                            Task { @MainActor [weak self] in self?.progress = sepShare * p }
                        }
                        backgroundURL = out
                        backgroundSource = video
                        bg = out
                    }
                    progress = sepShare
                    phase = .synthesizing
                }

                let (engine, _) = try await app.makeEngine(store: store)
                let sr = engine.sampleRate
                var mix = [Float](repeating: 0, count: Int((duration + 2) * Double(sr)))
                let baseSpeed = Float(app.speed)
                let steps = app.quality.steps
                let sway: Float = app.quality.sway
                let cfgScale = Float(app.cfgScale)
                var tracker = RateTracker()
                var levelRef: Float?
                var report: [DubCueReport] = []
                var sped = 0
                var cached = 0
                var fitted: [SubtitleCue] = []
                DubCache.trim()

                for (i, cue) in cues.enumerated() {
                    try Task.checkCancellation()
                    statusText = "Đang tạo giọng \(i + 1)/\(cues.count)"
                    let nextStart = i + 1 < cues.count ? cues[i + 1].start : duration
                    let available = max(0.4, nextStart - cue.start - 0.05)

                    var speed = baseSpeed
                    var wav: [Float]
                    var len: Double
                    let ckey = DubCache.key(text: cue.text, voice: voice, steps: steps, cfg: cfgScale, sway: sway,
                                            baseSpeed: baseSpeed, available: available, sr: sr)
                    if let hit = DubCache.load(ckey) {
                        // Dòng này không đổi so với lần trước → dùng lại, khỏi tạo giọng.
                        wav = hit.samples
                        speed = hit.speed
                        len = Double(wav.count) / Double(sr)
                        cached += 1
                    } else {
                        // Lần 1: tốc độ người dùng chọn. Cắt im lặng hai đầu để dòng bắt đầu đúng mốc và đỡ tốn khung.
                        var opts = SynthesisOptions(steps: steps, cfg: cfgScale, sway: sway, speed: speed)
                        let first = try await engine.synthesize(text: cue.text, voice: voice, options: opts) { _ in }
                        wav = AudioUtils.trimAndFade(first, sr: sr)
                        len = Double(wav.count) / Double(sr)
                        tracker.add(text: cue.text, seconds: len, speed: speed)

                        // Dài hơn khung → đo độ dài thật rồi đọc nhanh lên (tối đa 2 lần chỉnh, ≤ maxSpeed).
                        var attempts = 0
                        while len > available, speed < maxSpeed, attempts < 2 {
                            try Task.checkCancellation()
                            speed = min(maxSpeed, speed * Float(len / available) * 1.03)
                            opts.speed = speed
                            let again = try await engine.synthesize(text: cue.text, voice: voice, options: opts) { _ in }
                            wav = AudioUtils.trimAndFade(again, sr: sr)
                            len = Double(wav.count) / Double(sr)
                            attempts += 1
                        }
                        DubCache.store(ckey, samples: wav, speed: speed)
                    }
                    if speed > baseSpeed * 1.001 { sped += 1 }
                    if len > available + 0.05 {
                        report.append(DubCueReport(number: cue.index, start: cue.start, text: cue.text,
                                                   available: available, length: len, speed: speed))
                    }

                    // Cân bằng âm lượng giữa các dòng (so với mức trung bình đang trôi của chính video này).
                    let cueRMS = DubFit.rms(wav)
                    if cueRMS > 0 {
                        if let ref = levelRef {
                            wav = DubFit.leveled(wav, rms: cueRMS, reference: ref)
                            levelRef = 0.85 * ref + 0.15 * cueRMS
                        } else {
                            levelRef = cueRMS
                        }
                    }

                    progress = sepShare + synthShare * Double(i + 1) / Double(cues.count)
                    if wav.isEmpty { continue }

                    spans.append((cue.start, cue.start + len))
                    fitted.append(SubtitleCue(index: cue.index, start: cue.start,
                                              end: cue.start + max(len, 0.2), text: cue.text))
                    let startIdx = Int(cue.start * Double(sr))
                    if startIdx < mix.count {
                        let n = min(wav.count, mix.count - startIdx)
                        for k in 0..<n { mix[startIdx + k] += wav[k] }
                    }
                }
                tightLines = report
                tightCount = report.count
                speedUpCount = sped
                cachedCount = cached
                DubFit.learn(from: tracker)
                DubCache.trim()
                cacheMB = DubCache.sizeMB
                let srtURL = FileManager.default.temporaryDirectory.appendingPathComponent("phu-de-khop-giong.srt")
                if (try? SubtitleWriter.srt(fitted).write(to: srtURL, atomically: true, encoding: .utf8)) != nil {
                    fittedSRT = srtURL
                }
                fittedCues = fitted
                let assURL = FileManager.default.temporaryDirectory.appendingPathComponent("phu-de-karaoke.ass")
                if (try? KaraokeASS.build(fitted).write(to: assURL, atomically: true, encoding: .utf8)) != nil {
                    karaokeASS = assURL
                }

                // chuẩn hoá nếu bị vượt đỉnh khi hai đoạn chồng nhau
                let peak = mix.reduce(0) { max($0, abs($1)) }
                if peak > 0.98 { let g = 0.98 / peak; for k in 0..<mix.count { mix[k] *= g } }

                statusText = "Đang ghép vào video…"
                phase = .exporting
                let samples = mix
                let wavURL = FileManager.default.temporaryDirectory.appendingPathComponent("dub-voice-\(UUID().uuidString).wav")
                try await Task.detached(priority: .userInitiated) {
                    try WAV.write(samples: samples, sampleRate: sr, to: wavURL)
                }.value

                let out = try await DubbingExporter.export(video: video, dub: wavURL,
                                                           originalVolume: keep ? level : 0,
                                                           duckVolume: duck, speechSpans: spans,
                                                           background: bg) { p in
                    Task { @MainActor [weak self] in self?.progress = 0.85 + 0.15 * p }
                }
                try? FileManager.default.removeItem(at: wavURL)
                outputURL = out
                Haptics.success()
            } catch is CancellationError {
                // người dùng huỷ
            } catch {
                errorMessage = error.localizedDescription
                Haptics.error()
            }
        }
    }
}
