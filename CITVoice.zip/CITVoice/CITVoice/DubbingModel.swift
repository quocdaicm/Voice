import SwiftUI
import AVFoundation
import PhotosUI

/// Video chọn từ thư viện ảnh: chép ra thư mục tạm để dùng.
struct PickedVideo: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .movie) { received in
            let ext = received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent("dub-src-\(UUID().uuidString).\(ext)")
            try FileManager.default.copyItem(at: received.file, to: dest)
            return PickedVideo(url: dest)
        }
    }
}

@MainActor
final class DubbingModel: ObservableObject {
    enum Phase: Equatable { case idle, synthesizing, exporting }

    @Published var videoURL: URL?
    @Published var videoName = ""
    @Published var videoDuration: Double = 0
    @Published var thumbnail: UIImage?
    @Published var cues: [SubtitleCue] = []
    @Published var subtitleName = ""
    @Published var keepOriginal = true

    @Published var phase: Phase = .idle
    @Published var progress: Double = 0
    @Published var statusText = ""
    @Published var outputURL: URL?
    @Published var tightCount = 0
    @Published var errorMessage: String?

    private var task: Task<Void, Never>?
    private let maxSpeed: Float = 1.6

    var isBusy: Bool { phase != .idle }
    var canStart: Bool { videoURL != nil && !cues.isEmpty && !isBusy }

    // MARK: - Nạp dữ liệu

    func setVideo(url: URL, name: String) async {
        let asset = AVURLAsset(url: url)
        do {
            let d = try await asset.load(.duration).seconds
            guard d.isFinite, d > 0 else { throw DubError.noVideoTrack }
            if d > 30 * 60 { throw DubError.tooLong }
            videoDuration = d
        } catch {
            errorMessage = error.localizedDescription
            return
        }
        videoURL = url
        videoName = name
        outputURL = nil
        tightCount = 0
        thumbnail = await Task.detached(priority: .userInitiated) { () -> UIImage? in
            let gen = AVAssetImageGenerator(asset: AVURLAsset(url: url))
            gen.appliesPreferredTrackTransform = true
            gen.maximumSize = CGSize(width: 1000, height: 1000)
            guard let cg = try? gen.copyCGImage(at: CMTime(seconds: 0.5, preferredTimescale: 600), actualTime: nil)
            else { return nil }
            return UIImage(cgImage: cg)
        }.value
    }

    func setSubtitles(text: String, name: String) {
        let parsed = SubtitleParser.parse(text)
        guard !parsed.isEmpty else {
            errorMessage = "Không đọc được dòng phụ đề nào. Hãy dùng file .srt hoặc .vtt."
            return
        }
        cues = parsed
        subtitleName = name
        outputURL = nil
    }

    func setGenerated(cues newCues: [SubtitleCue], name: String) {
        cues = newCues
        subtitleName = name
        outputURL = nil
    }

    func loadEmbedded() async {
        guard let url = videoURL else { return }
        let found = await EmbeddedSubtitles.read(from: url)
        if found.isEmpty {
            errorMessage = "Video không có track phụ đề rời (phụ đề đóng cứng vào hình thì không đọc được). Hãy chọn file .srt."
        } else {
            cues = found
            subtitleName = "Phụ đề trong video"
            outputURL = nil
        }
    }

    // MARK: - Tạo video lồng tiếng

    func cancel() { task?.cancel() }

    func start(app: AppModel, store: ModelStore) {
        guard canStart, let video = videoURL else { return }
        phase = .synthesizing
        progress = 0
        tightCount = 0
        outputURL = nil
        UIApplication.shared.isIdleTimerDisabled = true

        let cues = self.cues.filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        guard !cues.isEmpty else { phase = .idle; errorMessage = "Phụ đề trống."; UIApplication.shared.isIdleTimerDisabled = false; return }
        let duration = videoDuration
        let keep = keepOriginal

        task = Task {
            defer {
                phase = .idle
                task = nil
                UIApplication.shared.isIdleTimerDisabled = false
            }
            do {
                guard let voice = app.voices.first(where: { $0.id == app.selectedVoiceID }) else { throw TTSError.voiceMissing }
                let (engine, _) = try await app.makeEngine(store: store)
                let sr = engine.sampleRate
                var mix = [Float](repeating: 0, count: Int((duration + 2) * Double(sr)))
                let baseSpeed = Float(app.speed)
                let steps = app.fastMode ? 8 : 16
                let sway: Float = app.fastMode ? -1 : 0
                var tight = 0

                for (i, cue) in cues.enumerated() {
                    try Task.checkCancellation()
                    statusText = "Đang tạo giọng \(i + 1)/\(cues.count)"
                    let nextStart = i + 1 < cues.count ? cues[i + 1].start : duration
                    let available = max(0.4, nextStart - cue.start - 0.05)

                    var opts = SynthesisOptions(steps: steps, cfg: 3.0, sway: sway, speed: baseSpeed)
                    var wav = try await engine.synthesize(text: cue.text, voice: voice, options: opts) { _ in }
                    var len = Double(wav.count) / Double(sr)

                    if len > available {            // dài hơn khung → đọc nhanh lên rồi tạo lại
                        opts.speed = min(maxSpeed, baseSpeed * Float(len / available) * 1.03)
                        wav = try await engine.synthesize(text: cue.text, voice: voice, options: opts) { _ in }
                        len = Double(wav.count) / Double(sr)
                        if len > available { tight += 1 }
                    }

                    let startIdx = Int(cue.start * Double(sr))
                    if startIdx < mix.count {
                        let n = min(wav.count, mix.count - startIdx)
                        for k in 0..<n { mix[startIdx + k] += wav[k] }
                    }
                    progress = 0.85 * Double(i + 1) / Double(cues.count)
                }
                tightCount = tight

                // chuẩn hoá nếu bị vượt đỉnh khi hai đoạn chồng nhau
                let peak = mix.reduce(0) { max($0, abs($1)) }
                if peak > 0.98 { let g = 0.98 / peak; for k in 0..<mix.count { mix[k] *= g } }

                statusText = "Đang ghép vào video…"
                phase = .exporting
                let samples = mix
                let wavURL = FileManager.default.temporaryDirectory.appendingPathComponent("dub-voice-\(UUID().uuidString).wav")
                try await Task.detached(priority: .userInitiated) {
                    try WAV.encode(samples: samples, sampleRate: sr).write(to: wavURL)
                }.value

                let out = try await DubbingExporter.export(video: video, dub: wavURL,
                                                           originalVolume: keep ? 0.15 : 0) { p in
                    Task { @MainActor [weak self] in self?.progress = 0.85 + 0.15 * p }
                }
                try? FileManager.default.removeItem(at: wavURL)
                outputURL = out
                Haptics.success()
            } catch is CancellationError {
                // người dùng huỷ
            } catch {
                errorMessage = error.localizedDescription
                Haptics.error()
            }
        }
    }
}
