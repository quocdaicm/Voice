import AVFoundation

@MainActor
final class AudioPlayer: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var isPlaying = false
    @Published var currentTime: TimeInterval = 0
    @Published var duration: TimeInterval = 0
    @Published var level: Float = 0            // 0…1, âm lượng tức thời (để làm sóng nhấp nhô)
    @Published private(set) var loadedURL: URL?

    private var player: AVAudioPlayer?
    private var timer: Timer?

    var progress: Double { duration > 0 ? min(1, max(0, currentTime / duration)) : 0 }

    /// Nạp file (chưa phát) để có thể tua.
    func load(url: URL) throws {
        if loadedURL == url, player != nil { return }
        timer?.invalidate()
        let p = try AVAudioPlayer(contentsOf: url)
        p.delegate = self
        p.isMeteringEnabled = true
        p.prepareToPlay()
        player = p
        loadedURL = url
        duration = p.duration
        currentTime = 0
        level = 0
        isPlaying = false
    }

    /// Phát (hoặc phát tiếp) file này.
    func play(url: URL) throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .default)
        try session.setActive(true)
        try load(url: url)
        guard let p = player else { return }
        if p.currentTime >= p.duration - 0.05 { p.currentTime = 0 }
        p.play()
        isPlaying = true
        startTimer()
    }

    /// Tạm dừng, giữ nguyên vị trí.
    func pause() {
        player?.pause()
        isPlaying = false
        level = 0
        timer?.invalidate()
    }

    /// Bỏ file đang nạp để lần sau nạp lại cả khi trùng đường dẫn (file đã bị ghi đè).
    func unload() { player?.stop(); player = nil; loadedURL = nil; isPlaying = false }

    /// Giữ tên cũ cho code đang gọi: tạm dừng.
    func stop() { pause() }

    func seek(url: URL, toProgress value: Double) {
        do { try load(url: url) } catch { return }
        guard let p = player else { return }
        p.currentTime = min(max(0, value), 1) * p.duration
        currentTime = p.currentTime
    }

    func skip(by seconds: TimeInterval) {
        guard let p = player else { return }
        p.currentTime = min(max(0, p.currentTime + seconds), max(0, p.duration - 0.05))
        currentTime = p.currentTime
    }

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
    }

    private func tick() {
        guard let p = player else { return }
        currentTime = p.currentTime
        p.updateMeters()
        let db = p.averagePower(forChannel: 0)          // −160…0 dB
        let linear = pow(10, db / 20)
        level = level * 0.6 + min(1, linear * 2.2) * 0.4  // làm mượt
    }

    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Task { @MainActor in
            self.isPlaying = false
            self.timer?.invalidate()
            self.level = 0
            self.currentTime = 0
            self.player?.currentTime = 0
        }
    }
}
