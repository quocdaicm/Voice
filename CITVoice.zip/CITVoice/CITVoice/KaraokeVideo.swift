import AVFoundation
import CoreImage
import UIKit

// =============================================================================
//  KaraokeVideo (v0.13) — tạo video karaoke: vẽ chữ từng từ sáng dần theo giọng lên video đã lồng tiếng.
//
//  Ý TƯỞNG karaoke từng từ theo mốc thời gian tham khảo VoiceStudio (AGPL-3.0, services/karaoke_ass.py);
//  VoiceStudio đốt chữ bằng ffmpeg/libass, còn iPhone không có libass nên app TỰ vẽ từng khung hình
//  bằng Core Graphics + Core Image (mã tự viết, không chép mã nguồn).
//  Âm thanh giữ nguyên từ video đầu vào (đã có giọng lồng tiếng).
// =============================================================================

struct KaraokeVideoStyle {
    var sizeFactor: CGFloat = 1.0
    var highlight: UIColor = UIColor(red: 1.0, green: 0.91, blue: 0.0, alpha: 1)
    var base: UIColor = .white

    static let sizes: [(name: String, factor: CGFloat)] = [("Nhỏ", 0.8), ("Vừa", 1.0), ("Lớn", 1.3)]
    static let colors: [(name: String, color: UIColor)] = [
        ("Vàng", UIColor(red: 1.0, green: 0.91, blue: 0.0, alpha: 1)),
        ("Xanh lá", UIColor(red: 0.35, green: 0.95, blue: 0.45, alpha: 1)),
        ("Hồng", UIColor(red: 1.0, green: 0.45, blue: 0.75, alpha: 1)),
        ("Cam", UIColor(red: 1.0, green: 0.6, blue: 0.1, alpha: 1)),
    ]
}

/// Hình chữ của MỘT dòng: bản trắng, bản màu sáng, và vị trí từng từ để biết quét tới đâu.
struct KaraokeOverlay {
    struct Word {
        let rect: CGRect          // toạ độ gốc trên-trái, trong khung chữ
        let line: Int
        let start: Double
        let end: Double
    }
    let base: CIImage
    let highlight: CIImage
    let size: CGSize
    let words: [Word]
    let lineCount: Int

    /// Các vùng (toạ độ Core Image, gốc dưới-trái) đã "sáng" tại thời điểm t.
    func highlightRects(at t: Double) -> [CGRect] {
        func flip(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat) -> CGRect {
            CGRect(x: x, y: size.height - (y + h), width: w, height: h)
        }
        var out: [CGRect] = []
        for line in 0..<lineCount {
            let ws = words.filter { $0.line == line }
            guard let first = ws.first, let last = ws.last else { continue }
            let top = max(0, first.rect.minY - 4)
            let h = min(size.height - top, first.rect.height + 8)
            if t >= last.end {
                out.append(flip(0, top, size.width, h))
            } else if t > first.start, let cur = ws.last(where: { $0.start <= t }) {
                let f = max(0, min(1, (t - cur.start) / max(cur.end - cur.start, 0.001)))
                let edge = cur.rect.minX + CGFloat(f) * cur.rect.width
                out.append(flip(0, top, edge, h))
            }
        }
        return out
    }

    static func make(text: String, start: Double, end: Double, renderSize: CGSize, style: KaraokeVideoStyle) -> KaraokeOverlay? {
        let timings = KaraokeASS.wordTimings(text, start: start, end: end)
        guard !timings.isEmpty else { return nil }
        let fontSize = max(22, renderSize.height * 0.045 * style.sizeFactor)
        let font = UIFont.boldSystemFont(ofSize: fontSize)
        func attrs(_ color: UIColor) -> [NSAttributedString.Key: Any] {
            [.font: font, .foregroundColor: color, .strokeColor: UIColor.black, .strokeWidth: NSNumber(value: -6.0)]
        }
        let measureAttrs = attrs(.white)
        let space = (" " as NSString).size(withAttributes: measureAttrs).width
        let maxWidth = renderSize.width * 0.88
        let pad: CGFloat = 10
        let lineH = font.lineHeight * 1.1

        // Chia dòng theo chiều rộng
        let widths: [CGFloat] = timings.map { ($0.token as NSString).size(withAttributes: measureAttrs).width }
        var lines: [[Int]] = [[]]
        var curW: CGFloat = 0
        for (i, w) in widths.enumerated() {
            let need = (lines[lines.count - 1].isEmpty ? 0 : space) + w
            if curW + need > maxWidth, !lines[lines.count - 1].isEmpty {
                lines.append([i]); curW = w
            } else {
                lines[lines.count - 1].append(i); curW += need
            }
        }
        let lineWidths: [CGFloat] = lines.map { idxs in
            idxs.reduce(CGFloat(0)) { $0 + widths[$1] } + CGFloat(max(0, idxs.count - 1)) * space
        }
        let boxW = min(renderSize.width, (lineWidths.max() ?? 0) + 2 * pad)
        let boxH = CGFloat(lines.count) * lineH + 2 * pad
        var words: [Word] = []
        for (li, idxs) in lines.enumerated() {
            var x = (boxW - lineWidths[li]) / 2
            let y = pad + CGFloat(li) * lineH
            for i in idxs {
                words.append(Word(rect: CGRect(x: x, y: y, width: widths[i], height: lineH),
                                  line: li, start: timings[i].start, end: timings[i].end))
                x += widths[i] + space
            }
        }

        func render(_ color: UIColor) -> CIImage? {
            let fmt = UIGraphicsImageRendererFormat()
            fmt.scale = 1
            fmt.opaque = false
            let img = UIGraphicsImageRenderer(size: CGSize(width: boxW, height: boxH), format: fmt).image { _ in
                let a = attrs(color)
                for (i, w) in words.enumerated() {
                    (timings[i].token as NSString).draw(at: CGPoint(x: w.rect.minX, y: w.rect.minY), withAttributes: a)
                }
            }
            guard let cg = img.cgImage else { return nil }
            return CIImage(cgImage: cg)
        }
        guard let b = render(style.base), let h = render(style.highlight) else { return nil }
        return KaraokeOverlay(base: b, highlight: h, size: CGSize(width: boxW, height: boxH),
                              words: words, lineCount: lines.count)
    }
}

/// Giữ vài dòng gần nhất (khung hình được xử lý lần lượt nên gần như luôn trúng).
final class KaraokeOverlayCache: @unchecked Sendable {
    private var items: [Int: KaraokeOverlay] = [:]
    private var order: [Int] = []
    private let lock = NSLock()

    func overlay(_ index: Int, make: () -> KaraokeOverlay?) -> KaraokeOverlay? {
        lock.lock(); defer { lock.unlock() }
        if let o = items[index] { return o }
        guard let o = make() else { return nil }
        items[index] = o
        order.append(index)
        if order.count > 6 { items[order.removeFirst()] = nil }
        return o
    }
}

/// Ghép chữ karaoke lên một khung hình: tìm dòng đang hiện, lấy hình chữ, quét phần đã sáng.
final class KaraokeRenderer: @unchecked Sendable {
    enum Placement { case bottom, center }

    private let list: [SubtitleCue]
    private let starts: [Double]
    private let ends: [Double]
    private let style: KaraokeVideoStyle
    private let placement: Placement
    private let cache = KaraokeOverlayCache()

    /// `holdUntilNext`: giữ dòng hiện tới khi dòng sau bắt đầu (cảnh nền), thay vì tắt ngay sau khi hết giọng.
    init?(cues: [SubtitleCue], style: KaraokeVideoStyle, placement: Placement, holdUntilNext: Bool = false) {
        let cleaned = cues.sorted { $0.start < $1.start }
            .map { c -> SubtitleCue in
                var d = c
                d.text = c.text.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                d.end = max(c.end, c.start + 0.2)
                return d
            }
            .filter { !$0.text.isEmpty }
        guard !cleaned.isEmpty else { return nil }
        list = cleaned
        starts = cleaned.map { $0.start - 0.05 }
        var e: [Double] = []
        for (i, c) in cleaned.enumerated() {
            if holdUntilNext {
                e.append(i + 1 < cleaned.count ? cleaned[i + 1].start - 0.05 : c.end + 0.6)
            } else {
                e.append(c.end + 0.2)
            }
        }
        ends = e
        self.style = style
        self.placement = placement
    }

    /// Dòng đang hiện tại thời điểm t: dòng cuối có start ≤ t và t chưa quá end.
    private func activeIndex(_ t: Double) -> Int? {
        var lo = 0, hi = starts.count - 1, found = -1
        while lo <= hi {
            let mid = (lo + hi) / 2
            if starts[mid] <= t { found = mid; lo = mid + 1 } else { hi = mid - 1 }
        }
        guard found >= 0, t < ends[found] else { return nil }
        return found
    }

    func frame(at t: Double, over src: CIImage) -> CIImage {
        guard let idx = activeIndex(t),
              let ov = cache.overlay(idx, make: {
                  KaraokeOverlay.make(text: list[idx].text, start: list[idx].start, end: list[idx].end,
                                      renderSize: src.extent.size, style: style)
              }) else { return src }
        var layer = ov.base
        for r in ov.highlightRects(at: t) {
            layer = ov.highlight.cropped(to: r).composited(over: layer)
        }
        let x = src.extent.minX + (src.extent.width - ov.size.width) / 2
        let y: CGFloat
        switch placement {
        case .bottom: y = src.extent.minY + src.extent.height * 0.08
        case .center: y = src.extent.minY + (src.extent.height - ov.size.height) / 2
        }
        return layer.transformed(by: CGAffineTransform(translationX: x, y: y))
            .composited(over: src)
            .cropped(to: src.extent)
    }
}

enum KaraokeVideoExporter {
    /// `video`: video đã lồng tiếng (có âm thanh). `cues`: các dòng đã khớp giọng (mốc thời gian theo video).
    static func export(video: URL, cues: [SubtitleCue], style: KaraokeVideoStyle,
                       onProgress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        let asset = AVURLAsset(url: video)
        guard try await !asset.loadTracks(withMediaType: .video).isEmpty else { throw DubError.noVideoTrack }
        guard let renderer = KaraokeRenderer(cues: cues, style: style, placement: .bottom) else {
            throw DubError.export("không có dòng phụ đề nào để vẽ")
        }

        let comp = AVMutableVideoComposition(asset: asset, applyingCIFiltersWithHandler: { request in
            let out = renderer.frame(at: request.compositionTime.seconds, over: request.sourceImage)
            request.finish(with: out, context: nil)
        })

        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            throw DubError.export("không tạo được phiên xuất")
        }
        let out = FileManager.default.temporaryDirectory
            .appendingPathComponent("cit-karaoke-\(Int(Date().timeIntervalSince1970)).mp4")
        try? FileManager.default.removeItem(at: out)
        session.outputURL = out
        session.outputFileType = session.supportedFileTypes.contains(.mp4) ? .mp4 : .mov
        session.videoComposition = comp
        session.shouldOptimizeForNetworkUse = true

        let poll = Task {
            while !Task.isCancelled {
                onProgress(Double(session.progress))
                try? await Task.sleep(nanoseconds: 300_000_000)
            }
        }
        await withTaskCancellationHandler {
            await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
                session.exportAsynchronously { cont.resume() }
            }
        } onCancel: {
            session.cancelExport()
        }
        poll.cancel()
        try Task.checkCancellation()

        guard session.status == .completed else {
            throw DubError.export(session.error?.localizedDescription ?? "không rõ nguyên nhân")
        }
        onProgress(1)
        return out
    }
}
