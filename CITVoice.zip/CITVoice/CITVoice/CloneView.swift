import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

/// Màn "Nhân bản giọng nói": tải model nhân bản → ghi âm/chọn file giọng mẫu → xác nhận quyền → tạo giọng.
struct CloneView: View {
    @ObservedObject var store: ModelStore
    @ObservedObject var model: AppModel
    @ObservedObject var player: AudioPlayer
    @StateObject private var recorder = VoiceRecorder()

    @State private var name = ""
    @State private var sampleURL: URL?
    @State private var sampleLabel = ""
    @State private var consent = false
    @State private var importing = false
    @State private var photoItem: PhotosPickerItem?
    @State private var showFolder = false
    @StateObject private var stems = StemModelStore()
    @State private var separate = false
    @State private var denoise = true
    @State private var working: String?
    @State private var workProgress: Double = 0
    @State private var warnings: [String] = []
    @State private var sampleDuration: Double = 0
    @State private var trimOn = false
    @State private var trimStart: Double = 0
    @State private var trimLen: Double = 8
    @State private var loadingPhoto = false
    @State private var created: String?

    private static let audioTypes: [UTType] = [.audio, .mp3, .wav, .mpeg4Audio, .aiff, .movie, .mpeg4Movie, .quickTimeMovie, .data, .content, .item]
        + ["m4a", "aac", "caf", "flac", "ogg", "opus", "mp4", "mov"].compactMap { UTType(filenameExtension: $0) }

    private var canCreate: Bool {
        sampleURL != nil && consent && !name.trimmingCharacters(in: .whitespaces).isEmpty
            && store.state == .ready && store.cloneState == .ready
            && !model.isEnrolling && !recorder.isRecording
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                modelSection
                sampleSection
                createSection
                managedSection
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .scrollDismissesKeyboard(.immediately)
        .dismissKeyboardOnTap()
        .keyboardDoneButton()
        .background(AuroraBackground())
        .navigationTitle("Nhân bản giọng")
        .navigationBarTitleDisplayMode(.inline)
        .filePicker(isPresented: $importing, types: Self.audioTypes) { result in
            switch result {
            case .success(let url):
                importAudio(url)
            case .failure(let error):
                model.errorMessage = error.localizedDescription
            }
        }
        .sheet(isPresented: $showFolder) {
            AppFolderSheet(onPick: { url in importAudio(url) }, onOther: { importing = true })
        }
        .onChange(of: photoItem) { item in
            guard let item else { return }
            loadingPhoto = true
            Task {
                defer { loadingPhoto = false; photoItem = nil }
                do {
                    guard let v = try await item.loadTransferable(type: PickedVideo.self) else { return }
                    let usable = try await ReferenceAudio.playable(v.url)
                    await setSample(usable, label: "Video từ thư viện Ảnh")
                } catch {
                    model.errorMessage = "Không đọc được video này: \(error.localizedDescription)"
                }
            }
        }
        .onChange(of: recorder.recordedURL) { url in
            if let url { Task { await setSample(url, label: "Bản ghi âm", allowSeparate: false) } }
        }
    }

    // MARK: - Sections

    @ViewBuilder
    private var modelSection: some View {
        Card {
            if store.state != .ready {
                HStack(spacing: 12) {
                    IconBadge(systemName: "exclamationmark.circle.fill", color: .orange)
                    Text("Cần tải model v3 Nano ở màn hình chính trước.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            } else {
                switch store.cloneState {
                case .ready:
                    HStack(spacing: 12) {
                        IconBadge(systemName: "checkmark.seal.fill", color: .green)
                        Text("Model nhân bản giọng · Đã cài").font(.body.weight(.semibold))
                    }
                case .downloading:
                    HStack(spacing: 12) {
                        IconBadge(systemName: "arrow.down.circle.fill")
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Đang tải model…").font(.body.weight(.semibold))
                            Text(store.cloneStatusText).font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    ProgressView(value: store.cloneProgress).tint(Brand.indigo)
                case .notInstalled:
                    HStack(spacing: 12) {
                        IconBadge(systemName: "icloud.and.arrow.down.fill")
                        Text("Cần tải thêm ~100 MB").font(.body.weight(.semibold))
                    }
                    Button {
                        Haptics.tap()
                        Task { await store.downloadClone() }
                    } label: {
                        SVGLabel("Tải model nhân bản giọng", icon: "IcDownload")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                case .failed(let msg):
                    HStack(spacing: 12) {
                        IconBadge(systemName: "exclamationmark.triangle.fill", color: .red)
                        Text(msg).font(.footnote).foregroundStyle(.red)
                    }
                    Button {
                        Task { await store.downloadClone() }
                    } label: {
                        Label("Thử lại", systemImage: "arrow.clockwise").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                }
            }
        }
    }

    @ViewBuilder
    private var sampleSection: some View {
        Card("Giọng mẫu", icon: "waveform.badge.mic") {
            // Nút ghi âm lớn ở giữa
            VStack(spacing: 10) {
                RecordButton(isRecording: recorder.isRecording) {
                    Haptics.tap()
                    Task { await toggleRecording() }
                }

                Text(recorder.isRecording
                     ? String(format: "Đang ghi… %.0f / %.0f s", recorder.elapsed, VoiceRecorder.maxSeconds)
                     : "Chạm để ghi âm")
                    .font(.subheadline.weight(.medium).monospacedDigit())
                    .foregroundStyle(recorder.isRecording ? .red : .secondary)

                Button {
                    showFolder = true
                } label: {
                    SVGLabel("Hoặc chọn file âm thanh", icon: "IcFolder")
                }
                .buttonStyle(SoftButtonStyle())
                .disabled(recorder.isRecording)

                // Cách dự phòng: video/âm thanh lưu trong app Ảnh (vd. video tải từ TikTok) → tự tách lấy tiếng.
                PhotosPicker(selection: $photoItem, matching: .videos) {
                    Label(loadingPhoto ? "Đang đọc video…" : "Hoặc chọn video từ thư viện Ảnh",
                          systemImage: "photo.on.rectangle")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(SoftButtonStyle())
                .disabled(recorder.isRecording || loadingPhoto)

                Toggle(isOn: $separate) {
                    Text("Tách tiếng nói khỏi nhạc nền (nên bật nếu file có nhạc/ồn)")
                        .font(.footnote)
                }
                .tint(Brand.indigo)
                Toggle(isOn: $denoise) {
                    Text("Khử tạp âm nền (tiếng xì, ù, quạt, ồn phòng)")
                        .font(.footnote)
                }
                .tint(Brand.indigo)
                if separate { stemModelRow }
                if let working {
                    VStack(spacing: 6) {
                        HStack(spacing: 8) { ProgressView(); Text(working).font(.footnote) }
                        if workProgress > 0 { ProgressView(value: workProgress).tint(Brand.indigo) }
                    }
                }
            }
            .frame(maxWidth: .infinity)

            if let url = sampleURL {
                VStack(alignment: .leading, spacing: 6) {
                    Text(sampleLabel)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    WaveformPlayer(url: url, player: player, showShare: false) { model.errorMessage = $0 }
                    ForEach(warnings, id: \.self) { w in
                        Label(w, systemImage: "exclamationmark.triangle.fill")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                    if sampleDuration > 6 { trimControls }
                }
            }

            Text("5–10 giây, một người nói, nơi yên tĩnh.")
                .font(.footnote).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var createSection: some View {
        Card("Tạo giọng", icon: "sparkles") {
            TextField("Tên giọng", text: $name)
                .submitLabel(.done)
                .onSubmit { hideKeyboard() }
                .padding(12)
                .background(Color(.tertiarySystemGroupedBackground),
                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))

            Toggle(isOn: $consent) {
                Text("Tôi xác nhận đây là giọng của tôi, hoặc tôi được chủ giọng cho phép nhân bản và sử dụng.")
                    .font(.footnote)
            }
            .tint(Brand.indigo)

            Button {
                guard let url0 = sampleURL else { return }
                Haptics.tap()
                let url = trimmedSample(url0)
                model.enrollVoice(from: url, name: name, store: store, denoise: denoise) { ok in
                    if ok {
                        Haptics.success()
                        created = name.trimmingCharacters(in: .whitespacesAndNewlines)
                        name = ""
                        consent = false
                    }
                }
            } label: {
                HStack(spacing: 8) {
                    if model.isEnrolling { ProgressView().tint(.white) }
                    else { SVGIcon("IcSpark", size: 20) }
                    Text(model.isEnrolling ? "Đang tạo giọng…" : "Tạo giọng")
                }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(!canCreate)

            if let created {
                Label("Đã thêm giọng \"\(created)\" và chọn sẵn ở màn hình chính.", systemImage: "checkmark.circle.fill")
                    .font(.footnote).foregroundStyle(.green)
            }

            Text("Chỉ nhân bản giọng bạn có quyền sử dụng. Không dùng để mạo danh, lừa đảo hay đánh lừa người khác; hãy nói rõ khi âm thanh là giọng tổng hợp.")
                .font(.footnote).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var managedSection: some View {
        let custom = model.voices.filter { $0.isCustom }
        if !custom.isEmpty {
            Card("Giọng đã nhân bản", icon: "person.crop.circle.badge.checkmark") {
                ForEach(Array(custom.enumerated()), id: \.element.id) { idx, v in
                    if idx > 0 { Divider() }
                    HStack(spacing: 12) {
                        IconBadge(systemName: "mic.fill", color: .pink)
                        Text(v.id).font(.body)
                        Spacer()
                        Button(role: .destructive) {
                            Haptics.tap()
                            model.removeCustomVoice(v)
                        } label: {
                            SVGIcon("IcTrash", size: 18)
                        }
                        .buttonStyle(.borderless)
                    }
                }
            }
        }
    }

    @ViewBuilder
    private var stemModelRow: some View {
        switch stems.state {
        case .ready:
            Label("Model tách nhạc đã sẵn sàng", systemImage: "checkmark.circle.fill")
                .font(.footnote).foregroundStyle(.green)
        case .downloading:
            VStack(alignment: .leading, spacing: 4) {
                Text(stems.statusText).font(.footnote)
                ProgressView(value: stems.progress).tint(Brand.indigo)
            }
        default:
            if case .failed(let m) = stems.state { Text(m).font(.footnote).foregroundStyle(.red) }
            Button {
                Task { await stems.download() }
            } label: {
                Label("Tải model tách nhạc (~\(StemModelStore.approxMB) MB)", systemImage: "arrow.down.circle")
                    .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
            }
            .buttonStyle(SoftButtonStyle())
        }
    }

    @ViewBuilder
    private var trimControls: some View {
        VStack(alignment: .leading, spacing: 6) {
            Toggle(isOn: $trimOn) {
                Text("Tự chọn đoạn dùng làm mẫu").font(.footnote.weight(.semibold))
            }
            .tint(Brand.indigo)
            if trimOn {
                let maxLen = min(15, sampleDuration)
                Text(String(format: "Bắt đầu: %.1f s", trimStart)).font(.footnote.monospacedDigit())
                Slider(value: $trimStart, in: 0...max(0.1, sampleDuration - trimLen))
                Text(String(format: "Độ dài: %.0f s", trimLen)).font(.footnote.monospacedDigit())
                Slider(value: $trimLen, in: 3...max(3.1, maxLen), step: 1)
                    .onChange(of: trimLen) { _ in trimStart = min(trimStart, max(0, sampleDuration - trimLen)) }
                Text("Nghe lại bằng trình phát phía trên rồi chọn đoạn chỉ có một người nói, rõ tiếng.")
                    .font(.caption).foregroundStyle(.secondary)
            } else {
                Text("Đang để app tự chọn đoạn tiếng nói sạch nhất.").font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - Actions

    /// Đặt giọng mẫu: (tuỳ chọn) tách tiếng nói khỏi nhạc nền, rồi phân tích chất lượng.
    private func setSample(_ url: URL, label: String, allowSeparate: Bool = true) async {
        var final = url
        var lab = label
        if separate && allowSeparate {
            if stems.state == .ready {
                working = "Đang tách tiếng nói khỏi nhạc nền…"
                workProgress = 0
                do {
                    final = try await VocalIsolator.vocals(from: url, compiledModel: stems.compiledURL) { p in
                        Task { @MainActor in workProgress = p }
                    }
                    lab += " · đã tách tiếng nói"
                } catch {
                    model.errorMessage = "Không tách được tiếng nói, dùng file gốc: \(error.localizedDescription)"
                }
                working = nil
                workProgress = 0
            } else {
                model.errorMessage = "Hãy tải model tách nhạc trước (nút ở trên), rồi chọn lại file."
            }
        }
        sampleURL = final
        sampleLabel = lab
        created = nil
        trimOn = false
        trimStart = 0
        await analyze(final)
    }

    /// Đo độ dài, âm lượng, độ ồn để cảnh báo sớm.
    private func analyze(_ url: URL) async {
        let res: (Double, [String])? = await Task.detached(priority: .utility) { () -> (Double, [String])? in
            guard let clip = try? ReferenceAudio.load(url: url, maxSeconds: 30) else { return nil }
            let q = AudioUtils.quality(clip.samples, sr: clip.sampleRate)
            var w: [String] = []
            if clip.seconds < 5 { w.append("Giọng mẫu hơi ngắn (\(Int(clip.seconds)) s). Nên dùng 8–15 giây.") }
            if q.peak < 0.05 { w.append("Giọng mẫu rất nhỏ. App sẽ tự tăng âm lượng nhưng chất lượng có thể kém.") }
            if q.snr < 15 { w.append("Có nhiều tạp âm hoặc nhạc nền, giọng tạo ra dễ bị rè. Hãy bật \"Tách tiếng nói khỏi nhạc nền\" hoặc chọn file sạch hơn.") }
            return (clip.seconds, w)
        }.value
        sampleDuration = res?.0 ?? 0
        warnings = res?.1 ?? []
        trimLen = min(8, max(3, sampleDuration))
    }

    /// Nếu người dùng tự cắt đoạn mẫu thì ghi đoạn đó ra file mới, không thì dùng nguyên file.
    private func trimmedSample(_ url: URL) -> URL {
        guard trimOn, let clip = try? ReferenceAudio.load(url: url, maxSeconds: 30) else { return url }
        let sr = clip.sampleRate
        let a = min(clip.samples.count, Int(trimStart * Double(sr)))
        let b = min(clip.samples.count, a + Int(trimLen * Double(sr)))
        guard b - a > sr else { return url }
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("clone-trim-\(UUID().uuidString).wav")
        do { try WAV.write(samples: Array(clip.samples[a..<b]), sampleRate: sr, to: out); return out } catch { return url }
    }

    private func importAudio(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        let label = url.lastPathComponent
        Task {
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            do {
                let copy = try await Task.detached(priority: .userInitiated) { try ReferenceAudio.importCopy(from: url) }.value
                let usable = try await ReferenceAudio.playable(copy)
                await setSample(usable, label: label)
            } catch {
                model.errorMessage = "Không đọc được file này: \(error.localizedDescription)"
            }
        }
    }

    private func toggleRecording() async {
        if recorder.isRecording {
            recorder.stop()
            return
        }
        player.stop()
        do { try await recorder.start() } catch { model.errorMessage = error.localizedDescription }
    }
}
