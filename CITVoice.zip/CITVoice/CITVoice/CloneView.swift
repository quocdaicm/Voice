import SwiftUI
import UniformTypeIdentifiers

/// Màn "Nhân bản giọng nói": tải model nhân bản → ghi âm/chọn file giọng mẫu → xác nhận quyền → tạo giọng.
struct CloneView: View {
    @ObservedObject var store: ModelStore
    @ObservedObject var model: AppModel
    @ObservedObject var player: AudioPlayer
    @StateObject private var recorder = VoiceRecorder()

    @State private var name = ""
    @State private var sampleURL: URL?
    @State private var sampleLabel = ""
    @State private var consent = false
    @State private var importing = false
    @State private var created: String?

    private var canCreate: Bool {
        sampleURL != nil && consent && !name.trimmingCharacters(in: .whitespaces).isEmpty
            && store.state == .ready && store.cloneState == .ready
            && !model.isEnrolling && !recorder.isRecording
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                modelSection
                sampleSection
                createSection
                managedSection
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .scrollDismissesKeyboard(.immediately)
        .dismissKeyboardOnTap()
        .keyboardDoneButton()
        .background(AuroraBackground())
        .navigationTitle("Nhân bản giọng")
        .navigationBarTitleDisplayMode(.inline)
        .fileImporter(isPresented: $importing, allowedContentTypes: [.audio]) { result in
            switch result {
            case .success(let url):
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let ext = url.pathExtension.isEmpty ? "audio" : url.pathExtension
                let dest = FileManager.default.temporaryDirectory.appendingPathComponent("clone-import-\(UUID().uuidString).\(ext)")
                do {
                    try FileManager.default.copyItem(at: url, to: dest)
                    sampleURL = dest
                    sampleLabel = url.lastPathComponent
                    created = nil
                } catch {
                    model.errorMessage = error.localizedDescription
                }
            case .failure(let error):
                model.errorMessage = error.localizedDescription
            }
        }
        .onChange(of: recorder.recordedURL) { url in
            if let url { sampleURL = url; sampleLabel = "Bản ghi âm"; created = nil }
        }
    }

    // MARK: - Sections

    @ViewBuilder
    private var modelSection: some View {
        Card {
            if store.state != .ready {
                HStack(spacing: 12) {
                    IconBadge(systemName: "exclamationmark.circle.fill", color: .orange)
                    Text("Cần tải model v3 Nano ở màn hình chính trước.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            } else {
                switch store.cloneState {
                case .ready:
                    HStack(spacing: 12) {
                        IconBadge(systemName: "checkmark.seal.fill", color: .green)
                        Text("Model nhân bản giọng · Đã cài").font(.body.weight(.semibold))
                    }
                case .downloading:
                    HStack(spacing: 12) {
                        IconBadge(systemName: "arrow.down.circle.fill")
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Đang tải model…").font(.body.weight(.semibold))
                            Text(store.cloneStatusText).font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    ProgressView(value: store.cloneProgress).tint(Brand.indigo)
                case .notInstalled:
                    HStack(spacing: 12) {
                        IconBadge(systemName: "icloud.and.arrow.down.fill")
                        Text("Cần tải thêm ~100 MB").font(.body.weight(.semibold))
                    }
                    Button {
                        Haptics.tap()
                        Task { await store.downloadClone() }
                    } label: {
                        SVGLabel("Tải model nhân bản giọng", icon: "IcDownload")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                case .failed(let msg):
                    HStack(spacing: 12) {
                        IconBadge(systemName: "exclamationmark.triangle.fill", color: .red)
                        Text(msg).font(.footnote).foregroundStyle(.red)
                    }
                    Button {
                        Task { await store.downloadClone() }
                    } label: {
                        Label("Thử lại", systemImage: "arrow.clockwise").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                }
            }
        }
    }

    @ViewBuilder
    private var sampleSection: some View {
        Card("Giọng mẫu", icon: "waveform.badge.mic") {
            // Nút ghi âm lớn ở giữa
            VStack(spacing: 10) {
                RecordButton(isRecording: recorder.isRecording) {
                    Haptics.tap()
                    Task { await toggleRecording() }
                }

                Text(recorder.isRecording
                     ? String(format: "Đang ghi… %.0f / %.0f s", recorder.elapsed, VoiceRecorder.maxSeconds)
                     : "Chạm để ghi âm")
                    .font(.subheadline.weight(.medium).monospacedDigit())
                    .foregroundStyle(recorder.isRecording ? .red : .secondary)

                Button {
                    importing = true
                } label: {
                    SVGLabel("Hoặc chọn file âm thanh", icon: "IcFolder")
                }
                .buttonStyle(SoftButtonStyle())
                .disabled(recorder.isRecording)
            }
            .frame(maxWidth: .infinity)

            if let url = sampleURL {
                VStack(alignment: .leading, spacing: 6) {
                    Text(sampleLabel)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    WaveformPlayer(url: url, player: player, showShare: false) { model.errorMessage = $0 }
                }
            }

            Text("5–10 giây, một người nói, nơi yên tĩnh.")
                .font(.footnote).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var createSection: some View {
        Card("Tạo giọng", icon: "sparkles") {
            TextField("Tên giọng", text: $name)
                .submitLabel(.done)
                .onSubmit { hideKeyboard() }
                .padding(12)
                .background(Color(.tertiarySystemGroupedBackground),
                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))

            Toggle(isOn: $consent) {
                Text("Tôi xác nhận đây là giọng của tôi, hoặc tôi được chủ giọng cho phép nhân bản và sử dụng.")
                    .font(.footnote)
            }
            .tint(Brand.indigo)

            Button {
                guard let url = sampleURL else { return }
                Haptics.tap()
                model.enrollVoice(from: url, name: name, store: store) { ok in
                    if ok {
                        Haptics.success()
                        created = name.trimmingCharacters(in: .whitespacesAndNewlines)
                        name = ""
                        consent = false
                    }
                }
            } label: {
                HStack(spacing: 8) {
                    if model.isEnrolling { ProgressView().tint(.white) }
                    else { SVGIcon("IcSpark", size: 20) }
                    Text(model.isEnrolling ? "Đang tạo giọng…" : "Tạo giọng")
                }
            }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(!canCreate)

            if let created {
                Label("Đã thêm giọng \"\(created)\" và chọn sẵn ở màn hình chính.", systemImage: "checkmark.circle.fill")
                    .font(.footnote).foregroundStyle(.green)
            }

            Text("Chỉ nhân bản giọng bạn có quyền sử dụng. Không dùng để mạo danh, lừa đảo hay đánh lừa người khác; hãy nói rõ khi âm thanh là giọng tổng hợp.")
                .font(.footnote).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var managedSection: some View {
        let custom = model.voices.filter { $0.isCustom }
        if !custom.isEmpty {
            Card("Giọng đã nhân bản", icon: "person.crop.circle.badge.checkmark") {
                ForEach(Array(custom.enumerated()), id: \.element.id) { idx, v in
                    if idx > 0 { Divider() }
                    HStack(spacing: 12) {
                        IconBadge(systemName: "mic.fill", color: .pink)
                        Text(v.id).font(.body)
                        Spacer()
                        Button(role: .destructive) {
                            Haptics.tap()
                            model.removeCustomVoice(v)
                        } label: {
                            SVGIcon("IcTrash", size: 18)
                        }
                        .buttonStyle(.borderless)
                    }
                }
            }
        }
    }

    // MARK: - Actions

    private func toggleRecording() async {
        if recorder.isRecording {
            recorder.stop()
            return
        }
        player.stop()
        do { try await recorder.start() } catch { model.errorMessage = error.localizedDescription }
    }
}
