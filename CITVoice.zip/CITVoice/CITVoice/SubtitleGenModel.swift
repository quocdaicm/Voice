import SwiftUI
#if canImport(WhisperKit)
import WhisperKit
#endif

struct RawSegment {
    var start: Double
    var end: Double
    var text: String
}

enum SourceLanguage: String, CaseIterable, Identifiable {
    case auto, en, zh, th, ko, ja, fr, de, es, ru, id, vi
    var id: String { rawValue }
    /// Mã gửi cho Whisper; nil = tự phát hiện.
    var code: String? { self == .auto ? nil : rawValue }
    var title: String {
        switch self {
        case .auto: return "Tự phát hiện"
        case .en: return "English"
        case .zh: return "中文 (Trung)"
        case .th: return "ไทย (Thái)"
        case .ko: return "한국어 (Hàn)"
        case .ja: return "日本語 (Nhật)"
        case .fr: return "Français"
        case .de: return "Deutsch"
        case .es: return "Español"
        case .ru: return "Русский"
        case .id: return "Bahasa Indonesia"
        case .vi: return "Tiếng Việt (không dịch)"
        }
    }
}

enum ASRModel: String, CaseIterable, Identifiable {
    case base, small, turbo
    var id: String { rawValue }
    /// Tên thư mục model trên Hugging Face (argmaxinc/whisperkit-coreml).
    var variant: String {
        switch self {
        case .base: return "openai_whisper-base"
        case .small: return "openai_whisper-small"
        case .turbo: return "openai_whisper-large-v3-v20240930_turbo_632MB"
        }
    }
    var approxMB: Double {
        switch self {
        case .base: return 150
        case .small: return 500
        case .turbo: return 650
        }
    }
    var title: String {
        switch self {
        case .base: return "Nhanh (base, ~150 MB) — dễ sai"
        case .small: return "Cân bằng (small, ~500 MB)"
        case .turbo: return "Chính xác nhất (large-v3 turbo, ~650 MB)"
        }
    }
}

/// Gộp các đoạn quá ngắn, tách các đoạn quá dài để vừa để lồng tiếng.
enum SubtitleRefiner {
    static func refine(_ input: [RawSegment], videoDuration: Double) -> [RawSegment] {
        var segs = input.compactMap { s -> RawSegment? in
            let t = SubtitleParser.clean(s.text)
            guard !t.isEmpty, s.end.isFinite, s.start.isFinite else { return nil }
            return RawSegment(start: max(0, s.start), end: max(s.end, s.start + 0.3), text: t)
        }.sorted { $0.start < $1.start }

        // Whisper hay "ảo giác" ở đoạn im lặng/nhạc: lặp mãi một câu → bỏ các đoạn lặp liên tiếp từ lần thứ 3
        var run = 0
        var lastKey = ""
        segs = segs.filter { seg in
            let key = seg.text.lowercased().trimmingCharacters(in: .punctuationCharacters.union(.whitespaces))
            if key == lastKey { run += 1 } else { run = 1; lastKey = key }
            return run <= 2
        }

        // Gộp các đoạn liền nhau cho tới khi hết câu: Whisper hay cắt giữa câu, dịch nửa câu sẽ sai nghĩa.
        func endsSentence(_ t: String) -> Bool {
            guard let c = t.trimmingCharacters(in: .whitespaces).last else { return true }
            return ".!?。！？…".contains(c)
        }
        var merged: [RawSegment] = []
        for s in segs {
            if var last = merged.last,
               !endsSentence(last.text) || last.end - last.start < 1.2,
               s.start - last.end < 0.8,
               s.end - last.start <= 12,
               last.text.count + s.text.count < 200 {
                last.end = s.end
                let cjk = last.text.unicodeScalars.last.map { $0.value > 0x2E80 } ?? false
                last.text += (cjk ? "" : " ") + s.text
                merged[merged.count - 1] = last
            } else {
                merged.append(s)
            }
        }
        segs = merged

        // tách đoạn dài
        var result: [RawSegment] = []
        for s in segs {
            if s.end - s.start > 14 || s.text.count > 220 {
                result.append(contentsOf: split(s))
            } else {
                result.append(s)
            }
        }
        if videoDuration > 0 {
            result = result.filter { $0.start < videoDuration }.map { s in
                var x = s; x.end = min(x.end, videoDuration); return x
            }
        }
        return result
    }

    private static func sentences(_ text: String) -> [String] {
        var out: [String] = []
        var cur = ""
        let chars = Array(text)
        for (i, ch) in chars.enumerated() {
            cur.append(ch)
            let cjkEnd = "。！？…".contains(ch)
            let latinEnd = ".!?".contains(ch) && (i + 1 >= chars.count || chars[i + 1] == " ")
            if cjkEnd || latinEnd {
                out.append(cur.trimmingCharacters(in: .whitespaces)); cur = ""
            }
        }
        if !cur.trimmingCharacters(in: .whitespaces).isEmpty { out.append(cur.trimmingCharacters(in: .whitespaces)) }
        return out
    }

    private static func split(_ s: RawSegment) -> [RawSegment] {
        let parts = sentences(s.text)
        guard parts.count > 1 else { return [s] }
        let total = Double(parts.reduce(0) { $0 + $1.count })
        let dur = s.end - s.start
        let maxDur = 12.0
        // gom câu thành nhóm ≤ ~12 giây (ước lượng theo số ký tự)
        var groups: [[String]] = [[]]
        var acc = 0.0
        for p in parts {
            let d = dur * Double(p.count) / total
            if acc + d > maxDur, !groups[groups.count - 1].isEmpty { groups.append([]); acc = 0 }
            groups[groups.count - 1].append(p); acc += d
        }
        var out: [RawSegment] = []
        var t = s.start
        for g in groups {
            let n = g.reduce(0) { $0 + $1.count }
            let d = dur * Double(n) / total
            out.append(RawSegment(start: t, end: t + d, text: g.joined(separator: " ")))
            t += d
        }
        return out
    }
}

/// Quy trình: trích âm thanh → nhận dạng (WhisperKit, trên máy) → dịch sang tiếng Việt (Apple Translation, trên máy).
@MainActor
final class SubtitleGenModel: ObservableObject {
    enum Stage { case idle, extracting, separating, loadingModel, recognizing, translating, shortening }

    @Published var stage: Stage = .idle
    @Published var errorMessage: String?
    @Published var notice: String?
    @Published var downloadFraction: Double = 0   // ước lượng tiến độ tải model nhận dạng
    @Published var downloadedMB: Double = 0
    @Published var sepProgress: Double = 0
    @Published var shortenDone = 0
    @Published var shortenTotal = 0
    let bridge = TranslationBridge()

    private var task: Task<Void, Never>?

    var isBusy: Bool { stage != .idle }
    var statusText: String {
        switch stage {
        case .idle: return ""
        case .extracting: return "Đang trích âm thanh từ video…"
        case .separating: return String(format: "Đang tách tiếng nói khỏi nhạc nền… %.0f%%", sepProgress * 100)
        case .loadingModel:
            return downloadedMB > 1
                ? String(format: "Đang tải model nhận dạng: %.0f MB…", downloadedMB)
                : "Đang nạp model nhận dạng (lần đầu có thể mất vài phút)…"
        case .recognizing: return "Đang nhận dạng giọng nói…"
        case .translating: return "Đang dịch sang tiếng Việt…"
        case .shortening:
            return shortenTotal > 0 ? "Đang rút ngắn câu dịch \(shortenDone)/\(shortenTotal)…" : "Đang rút ngắn câu dịch…"
        }
    }

    func cancel() {
        task?.cancel()
        bridge.cancel()
    }

    /// `onDone(cues, tên)` được gọi khi xong.
    func run(video: URL, duration: Double, language: SourceLanguage, model: ASRModel, viaEnglish: Bool = true, shorten: Bool = false, stemModel: URL? = nil,
             onDone: @escaping ([SubtitleCue], String) -> Void) {
        guard !isBusy else { return }
        errorMessage = nil
        notice = nil
        UIApplication.shared.isIdleTimerDisabled = true
        task = Task {
            defer {
                stage = .idle
                task = nil
                UIApplication.shared.isIdleTimerDisabled = false
            }
            var wavURL: URL?
            defer { if let u = wavURL { try? FileManager.default.removeItem(at: u) } }
            do {
                var wav: URL
                if let compiled = stemModel {
                    // Tách tiếng nói khỏi nhạc nền trước khi nhận dạng → ít sai và ít "ảo giác" hơn.
                    stage = .separating
                    sepProgress = 0
                    do {
                        wav = try await VocalIsolator.vocals16k(from: video, compiledModel: compiled, duration: duration) { [weak self] p in
                            Task { @MainActor in self?.sepProgress = p }
                        }
                    } catch is CancellationError {
                        throw CancellationError()
                    } catch {
                        notice = "Không tách được tiếng nói (\(error.localizedDescription)); nhận dạng trên âm thanh gốc."
                        stage = .extracting
                        wav = try await AudioExtractor.wav16k(from: video)
                    }
                } else {
                    stage = .extracting
                    wav = try await AudioExtractor.wav16k(from: video)
                }
                wavURL = wav
                try Task.checkCancellation()

                let (raw, detected) = try await recognize(wav: wav, language: language, model: model)
                try Task.checkCancellation()
                let segs = SubtitleRefiner.refine(raw, videoDuration: duration)
                guard !segs.isEmpty else { throw SubtitleGenError.nothingRecognized }

                let source = language.code ?? detected
                var texts = segs.map { $0.text }
                var translated = false
                if language == .auto {
                    notice = "Ngôn ngữ tự phát hiện: \"\(source)\". Nếu sai, hãy chọn đúng ngôn ngữ và chạy lại."
                }
                if source != "vi" {
                    stage = .translating
                    // Cặp ngôn ngữ hiếm (Trung/Thái/Hàn/Nhật → Việt) thường dịch kém khi đi thẳng; qua tiếng Anh chuẩn hơn.
                    let pivot = viaEnglish && source != "en"
                    let first = pivot ? "en" : "vi"
                    let a1 = await TranslationBridge.availability(source: source, target: first)
                    var a2 = TranslationAvailabilityState.ready
                    if pivot { a2 = await TranslationBridge.availability(source: "en", target: "vi") }
                    if a1 == .unsupported || a2 == .unsupported {
                        let msg = "Máy chưa hỗ trợ dịch \"\(source)\" → tiếng Việt trên máy (cần iOS 18 trở lên). Phụ đề đang là bản gốc — hãy sửa thành tiếng Việt trước khi lồng tiếng."
                        notice = [notice, msg].compactMap { $0 }.joined(separator: "\n")
                    } else {
                        do {
                            texts = try await bridge.translate(source: source, target: first, texts: texts)
                            if pivot { texts = try await bridge.translate(source: "en", target: "vi", texts: texts) }
                            translated = true
                        } catch is CancellationError {
                            throw CancellationError()
                        } catch {
                            let msg = "Dịch lỗi: \(error.localizedDescription). Phụ đề đang là bản gốc — hãy sửa thành tiếng Việt trước khi lồng tiếng."
                            notice = [notice, msg].compactMap { $0 }.joined(separator: "\n")
                        }
                    }
                }
                try Task.checkCancellation()

                var cues = segs.enumerated().map { i, s in
                    SubtitleCue(index: i + 1, start: s.start, end: s.end, text: texts[i],
                                original: (translated || source != "vi") ? s.text : "")
                }
                // Rút ngắn câu dịch quá dài (chỉ khi người dùng bật, máy hỗ trợ, và đã có bản tiếng Việt)
                if shorten, translated || source == "vi" {
                    if case .available = LineShortener.availability {
                        stage = .shortening
                        shortenDone = 0; shortenTotal = LineShortener.candidates(cues).count
                        let changed = try await LineShortener.shortenAll(&cues) { [weak self] done, total in
                            self?.shortenDone = done; self?.shortenTotal = total
                        }
                        if changed > 0 {
                            let extra = "Đã tự rút ngắn \(changed) dòng cho vừa thời lượng — bản gốc vẫn hiện bên dưới để bạn đối chiếu."
                            notice = [notice, extra].compactMap { $0 }.joined(separator: "\n")
                        }
                    } else if case .unavailable(let why) = LineShortener.availability {
                        let extra = "Không rút ngắn được câu dịch: \(why)"
                        notice = [notice, extra].compactMap { $0 }.joined(separator: "\n")
                    }
                }
                try Task.checkCancellation()
                onDone(cues, translated ? "Tự tạo (\(source) → vi)" : "Tự nhận dạng (\(source))")
                Haptics.success()
            } catch is CancellationError {
                // người dùng huỷ
            } catch {
                errorMessage = error.localizedDescription
                Haptics.error()
            }
        }
    }

    nonisolated static func folderSize(_ dir: URL) -> Int64 {
        guard let e = FileManager.default.enumerator(at: dir, includingPropertiesForKeys: [.totalFileAllocatedSizeKey]) else { return 0 }
        var total: Int64 = 0
        for case let u as URL in e {
            total += Int64((try? u.resourceValues(forKeys: [.totalFileAllocatedSizeKey]))?.totalFileAllocatedSize ?? 0)
        }
        return total
    }

    /// Thư mục lưu model nhận dạng: Application Support (không hiện trong Tệp, không bị sao lưu iCloud).
    static func asrDirectory() -> URL {
        var dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Models/Whisper", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var rv = URLResourceValues()
        rv.isExcludedFromBackup = true
        try? dir.setResourceValues(rv)
        return dir
    }

    /// Trả về (các đoạn, mã ngôn ngữ phát hiện được).
    private func recognize(wav: URL, language: SourceLanguage, model: ASRModel) async throws -> ([RawSegment], String) {
        #if canImport(WhisperKit)
        stage = .loadingModel
        let dir = Self.asrDirectory()
        downloadedMB = 0; downloadFraction = 0
        let approx = model.approxMB
        let poller = Task { [weak self] in
            while !Task.isCancelled {
                let mb = Double(Self.folderSize(dir)) / 1_048_576
                self?.downloadedMB = mb
                self?.downloadFraction = min(0.98, mb / approx)
                try? await Task.sleep(nanoseconds: 1_000_000_000)
            }
        }
        defer { poller.cancel() }
        let pipe = try await WhisperKit(WhisperKitConfig(model: model.variant, downloadBase: dir))
        try Task.checkCancellation()
        stage = .recognizing

        var opts = DecodingOptions()
        opts.task = .transcribe
        if let code = language.code {
            opts.language = code
            opts.detectLanguage = false
        } else {
            opts.language = nil
            opts.detectLanguage = true
        }
        opts.skipSpecialTokens = true
        opts.temperatureFallbackCount = 5          // gặp đoạn khó thì thử lại nhiều lần thay vì bỏ qua
        opts.noSpeechThreshold = 0.6
        opts.chunkingStrategy = .vad

        let results: [TranscriptionResult] = try await pipe.transcribe(audioPath: wav.path, decodeOptions: opts)
        var segs: [RawSegment] = []
        for r in results {
            for s in r.segments {
                segs.append(RawSegment(start: Double(s.start), end: Double(s.end), text: s.text))
            }
        }
        let lang = results.first(where: { !$0.language.isEmpty })?.language ?? (language.code ?? "en")
        return (segs, lang)
        #else
        throw SubtitleGenError.recognizerMissing
        #endif
    }
}
