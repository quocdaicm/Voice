import SwiftUI

@main
struct CITVoiceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
