import Foundation
import AVFoundation
#if canImport(CoreML)
import CoreML
#endif

// =============================================================================
//  TÁCH LỜI GỐC KHỎI NHẠC NỀN (v0.7)
//  Model: UVR-MDX-NET Inst_HQ_3 bản Core ML fp16 (~34 MB) — https://huggingface.co/gyoom/UVR-MDX-CoreML
//  Hợp đồng đầu vào/ra (theo model card): NCHW [1, 4, 3072, 256] fp16, 4 kênh = [L_re, L_im, R_re, R_im],
//  chỉ số phẳng ((plane*dimF)+bin)*dimT + frame. n_fft 6144, hop 1024, cửa sổ Hann tuần hoàn, center=True (reflect),
//  STFT không chuẩn hoá, bỏ bin Nyquist. Model Inst HQ 3 trả về *nhạc nền* (instrumental) → dùng trực tiếp.
//  STFT/iSTFT tự viết bằng Swift thuần (FFT cơ số 2 × 3) — logic đã kiểm bằng bản Python tương đương (sai số ~1e-7).
// =============================================================================

enum StemError: LocalizedError {
    case modelMissing
    case unsupportedDevice
    case badOutput(String)
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .modelMissing: return "Chưa tải model tách nhạc."
        case .unsupportedDevice: return "Thiết bị này chưa hỗ trợ model tách nhạc (cần chip ARM64)."
        case .badOutput(let m): return "Model tách nhạc trả về dữ liệu không đúng: \(m)"
        case .failed(let m): return "Tách nhạc lỗi: \(m)"
        }
    }
}

// MARK: - Tải & biên dịch model

@MainActor
final class StemModelStore: ObservableObject {
    enum State: Equatable { case notInstalled, downloading, ready, failed(String) }

    static let repo = "gyoom/UVR-MDX-CoreML"
    static let packageName = "UVR-MDX-NET-Inst_HQ_3.mlpackage"
    /// Ba file tạo nên một .mlpackage (Manifest + đặc tả + trọng số).
    static let files = [
        "Manifest.json",
        "Data/com.apple.CoreML/model.mlmodel",
        "Data/com.apple.CoreML/weights/weight.bin",
    ]
    static let approxMB = 34

    @Published var state: State = .notInstalled
    @Published var progress: Double = 0
    @Published var statusText = ""

    let directory: URL
    var compiledURL: URL { directory.appendingPathComponent("InstHQ3.mlmodelc", isDirectory: true) }
    private var packageURL: URL { directory.appendingPathComponent(Self.packageName, isDirectory: true) }

    init() {
        var dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Models/MDXNet", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var rv = URLResourceValues()
        rv.isExcludedFromBackup = true
        try? dir.setResourceValues(rv)
        directory = dir
        state = FileManager.default.fileExists(atPath: dir.appendingPathComponent("InstHQ3.mlmodelc").path) ? .ready : .notInstalled
    }

    func download() async {
        guard state != .downloading else { return }
        state = .downloading
        progress = 0
        do {
            let fm = FileManager.default
            for (i, rel) in Self.files.enumerated() {
                let dest = packageURL.appendingPathComponent(rel)
                try fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
                if fm.fileExists(atPath: dest.path) { continue }
                statusText = "Đang tải model tách nhạc (\(i + 1)/\(Self.files.count))…"
                let url = URL(string: "https://huggingface.co/\(Self.repo)/resolve/main/\(Self.packageName)/\(rel)")!
                let count = Self.files.count
                let dl = FileDownloader(destination: dest) { [weak self] written, total in
                    let frac = total > 0 ? Double(written) / Double(total) : 0
                    Task { @MainActor in
                        self?.progress = (Double(i) + frac) / Double(count)
                        self?.statusText = String(format: "Đang tải model tách nhạc: %.0f MB…", Double(written) / 1_048_576)
                    }
                }
                try await dl.start(url: url)
            }
            statusText = "Đang chuẩn bị model cho máy này…"
            #if canImport(CoreML)
            let compiled = try await MLModel.compileModel(at: packageURL)
            try? fm.removeItem(at: compiledURL)
            try fm.moveItem(at: compiled, to: compiledURL)
            #endif
            try? fm.removeItem(at: packageURL)        // giữ bản đã biên dịch, bỏ bản gốc cho nhẹ
            state = .ready
            statusText = ""
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func delete() {
        try? FileManager.default.removeItem(at: compiledURL)
        try? FileManager.default.removeItem(at: packageURL)
        state = .notInstalled
    }
}

// MARK: - FFT cơ số 2 và 3·2^k (độ dài 4096 hoặc 6144)

/// FFT phức thuận, tại chỗ, số thực Float. Không an toàn luồng: mỗi luồng dùng một bản riêng.
final class MixedFFT {
    let n: Int
    private let m: Int          // 1 hoặc 3
    private let l: Int          // độ dài con = n / m (luỹ thừa của 2)
    private let twRe: UnsafeMutablePointer<Float>
    private let twIm: UnsafeMutablePointer<Float>
    private let bitrev: UnsafeMutablePointer<Int32>
    private let c1Re: UnsafeMutablePointer<Float>, c1Im: UnsafeMutablePointer<Float>
    private let c2Re: UnsafeMutablePointer<Float>, c2Im: UnsafeMutablePointer<Float>
    private let sRe: UnsafeMutablePointer<Float>, sIm: UnsafeMutablePointer<Float>

    init?(n: Int) {
        func isPow2(_ x: Int) -> Bool { x > 0 && (x & (x - 1)) == 0 }
        if isPow2(n) { m = 1 } else if n % 3 == 0, isPow2(n / 3) { m = 3 } else { return nil }
        self.n = n
        l = n / m
        let half = max(1, l / 2)
        twRe = .allocate(capacity: half); twIm = .allocate(capacity: half)
        for j in 0..<half {
            let a = -2.0 * Double.pi * Double(j) / Double(l)
            twRe[j] = Float(cos(a)); twIm[j] = Float(sin(a))
        }
        bitrev = .allocate(capacity: l)
        var bits = 0
        while (1 << bits) < l { bits += 1 }
        for i in 0..<l {
            var r = 0, x = i
            for _ in 0..<bits { r = (r << 1) | (x & 1); x >>= 1 }
            bitrev[i] = Int32(r)
        }
        c1Re = .allocate(capacity: l); c1Im = .allocate(capacity: l)
        c2Re = .allocate(capacity: l); c2Im = .allocate(capacity: l)
        for k in 0..<l {
            let a1 = -2.0 * Double.pi * Double(k) / Double(n)
            let a2 = 2.0 * a1
            c1Re[k] = Float(cos(a1)); c1Im[k] = Float(sin(a1))
            c2Re[k] = Float(cos(a2)); c2Im[k] = Float(sin(a2))
        }
        sRe = .allocate(capacity: n); sIm = .allocate(capacity: n)
    }

    deinit {
        twRe.deallocate(); twIm.deallocate(); bitrev.deallocate()
        c1Re.deallocate(); c1Im.deallocate(); c2Re.deallocate(); c2Im.deallocate()
        sRe.deallocate(); sIm.deallocate()
    }

    private func radix2(_ re: UnsafeMutablePointer<Float>, _ im: UnsafeMutablePointer<Float>) {
        let L = l
        for i in 0..<L {
            let j = Int(bitrev[i])
            if j > i {
                let tr = re[i]; re[i] = re[j]; re[j] = tr
                let ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while size <= L {
            let half = size / 2
            let step = L / size
            var s = 0
            while s < L {
                for j in 0..<half {
                    let wr = twRe[j * step], wi = twIm[j * step]
                    let a = s + j, b = a + half
                    let tr = re[b] * wr - im[b] * wi
                    let ti = re[b] * wi + im[b] * wr
                    re[b] = re[a] - tr; im[b] = im[a] - ti
                    re[a] += tr; im[a] += ti
                }
                s += size
            }
            size <<= 1
        }
    }

    /// X[k] = Σ x[j]·e^(−2πi·jk/n), kết quả ghi đè lên (re, im).
    func forward(_ re: UnsafeMutablePointer<Float>, _ im: UnsafeMutablePointer<Float>) {
        if m == 1 { radix2(re, im); return }
        let L = l
        for k in 0..<L {
            for r in 0..<3 { sRe[r * L + k] = re[3 * k + r]; sIm[r * L + k] = im[3 * k + r] }
        }
        for r in 0..<3 { radix2(sRe + r * L, sIm + r * L) }
        let h: Float = 0.5
        let q: Float = Float(3.0.squareRoot() / 2.0)
        for k in 0..<L {
            let y0r = sRe[k], y0i = sIm[k]
            let y1r = sRe[L + k], y1i = sIm[L + k]
            let y2r = sRe[2 * L + k], y2i = sIm[2 * L + k]
            let t1r = y1r * c1Re[k] - y1i * c1Im[k], t1i = y1r * c1Im[k] + y1i * c1Re[k]
            let t2r = y2r * c2Re[k] - y2i * c2Im[k], t2i = y2r * c2Im[k] + y2i * c2Re[k]
            re[k] = y0r + t1r + t2r
            im[k] = y0i + t1i + t2i
            // W3 = −1/2 − i·√3/2 ; W3² = −1/2 + i·√3/2
            re[L + k] = y0r + (-h * t1r + q * t1i) + (-h * t2r - q * t2i)
            im[L + k] = y0i + (-h * t1i - q * t1r) + (-h * t2i + q * t2r)
            re[2 * L + k] = y0r + (-h * t1r - q * t1i) + (-h * t2r + q * t2i)
            im[2 * L + k] = y0i + (-h * t1i + q * t1r) + (-h * t2i - q * t2r)
        }
    }
}

// MARK: - STFT / iSTFT theo hợp đồng của model

/// Một bản dùng cho một luồng. Phổ lưu dạng [bin * dimT + frame].
final class MDXSpectral {
    static let nFFT = 6144, hop = 1024, dimF = 3072, dimT = 256
    static let chunk = hop * (dimT - 1)          // 261 120 mẫu mỗi lần chạy model
    static let trim = nFFT / 2                   // 3 072
    static let gen = chunk - 2 * trim            // 254 976 mẫu hữu dụng mỗi lần

    private let fft: MixedFFT
    private let window: [Float]
    private let re: UnsafeMutablePointer<Float>
    private let im: UnsafeMutablePointer<Float>
    private var padded: [Float]
    private var ola: [Float]
    private var wsq: [Float]

    init() {
        fft = MixedFFT(n: Self.nFFT)!
        window = (0..<Self.nFFT).map { Float(0.5 - 0.5 * cos(2.0 * Double.pi * Double($0) / Double(Self.nFFT))) }
        re = .allocate(capacity: Self.nFFT)
        im = .allocate(capacity: Self.nFFT)
        padded = [Float](repeating: 0, count: Self.chunk + Self.nFFT)
        let olaLen = (Self.dimT - 1) * Self.hop + Self.nFFT
        ola = [Float](repeating: 0, count: olaLen)
        wsq = [Float](repeating: 0, count: olaLen)
        // tổng bình phương cửa sổ không phụ thuộc dữ liệu → tính một lần
        for t in 0..<Self.dimT {
            let o = t * Self.hop
            for i in 0..<Self.nFFT { wsq[o + i] += window[i] * window[i] }
        }
    }

    deinit { re.deallocate(); im.deallocate() }

    /// x: đúng `chunk` mẫu. Trả về (phần thực, phần ảo), mỗi mảng dimF × dimT.
    func stft(_ x: [Float], outRe: inout [Float], outIm: inout [Float]) {
        let T = Self.trim, C = Self.chunk, N = Self.nFFT, F = Self.dimF, D = Self.dimT
        // reflect-pad hai đầu mỗi bên `trim` mẫu (không lặp mẫu biên, như torch.stft pad_mode="reflect")
        for i in 0..<T { padded[i] = x[T - i] }
        for i in 0..<C { padded[T + i] = x[i] }
        for i in 0..<T { padded[T + C + i] = x[C - 2 - i] }
        for t in 0..<D {
            let o = t * Self.hop
            for i in 0..<N { re[i] = padded[o + i] * window[i]; im[i] = 0 }
            fft.forward(re, im)
            for k in 0..<F { outRe[k * D + t] = re[k]; outIm[k * D + t] = im[k] }
        }
    }

    /// Phổ (dimF bin, bin Nyquist coi như 0) → `chunk` mẫu.
    func istft(_ specRe: [Float], _ specIm: [Float], into out: inout [Float]) {
        let T = Self.trim, C = Self.chunk, N = Self.nFFT, F = Self.dimF, D = Self.dimT
        for i in 0..<ola.count { ola[i] = 0 }
        let invN = 1 / Float(N)
        for t in 0..<D {
            for k in 0..<F { re[k] = specRe[k * D + t]; im[k] = specIm[k * D + t] }
            re[F] = 0; im[F] = 0
            if F + 1 < N { for k in (F + 1)..<N { re[k] = re[N - k]; im[k] = -im[N - k] } }
            // iFFT qua liên hợp: x = conj(FFT(conj X)) / N, chỉ cần phần thực
            for k in 0..<N { im[k] = -im[k] }
            fft.forward(re, im)
            let o = t * Self.hop
            for i in 0..<N { ola[o + i] += re[i] * invN * window[i] }
        }
        for i in 0..<C {
            let w = wsq[T + i]
            out[i] = w > 1e-8 ? ola[T + i] / w : 0
        }
    }
}

// MARK: - Cờ huỷ cho việc chạy ngoài luồng

final class CancelFlag: @unchecked Sendable {
    private let lock = NSLock()
    private var flag = false
    func cancel() { lock.lock(); flag = true; lock.unlock() }
    var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return flag }
}

// MARK: - Quy trình tách nhạc

enum StemSeparator {
    static let sampleRate = 44_100

    /// Tách `video` → WAV 16-bit stereo 44,1 kHz chứa nhạc nền (không còn lời). Xử lý theo đoạn nên ít tốn RAM.
    /// `progress` nhận 0…1.
    static func instrumental(from video: URL, compiledModel: URL,
                             progress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        let flag = CancelFlag()
        return try await withTaskCancellationHandler {
            try await Task.detached(priority: .userInitiated) {
                try await run(video: video, compiledModel: compiledModel, flag: flag, progress: progress)
            }.value
        } onCancel: { flag.cancel() }
    }

    private static func run(video: URL, compiledModel: URL, flag: CancelFlag,
                            progress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        #if canImport(CoreML) && arch(arm64)
        let fm = FileManager.default
        let tmp = fm.temporaryDirectory
        let rawURL = tmp.appendingPathComponent("stem-in-\(UUID().uuidString).raw")
        let outURL = tmp.appendingPathComponent("stem-bg-\(UUID().uuidString).wav")
        defer { try? fm.removeItem(at: rawURL) }

        // 1) Giải mã âm thanh video → file thô Int16 stereo 44,1 kHz (ghi dần ra đĩa)
        let frames = try await decodeToRaw(video: video, rawURL: rawURL, flag: flag) { progress(0.06 * $0) }
        guard frames > 0 else { throw SubtitleGenError.noAudio }

        // 2) Nạp model
        let cfg = MLModelConfiguration()
        cfg.computeUnits = .all
        let model = try MLModel(contentsOf: compiledModel, configuration: cfg)

        // 3) Chạy từng đoạn
        let writer = try StreamWAVWriter(url: outURL, sampleRate: sampleRate, channels: 2)
        let reader = try FileHandle(forReadingFrom: rawURL)
        defer { try? reader.close() }
        let spec = MDXSpectral()
        let C = MDXSpectral.chunk, T = MDXSpectral.trim, G = MDXSpectral.gen
        let F = MDXSpectral.dimF, D = MDXSpectral.dimT
        let plane = F * D

        var inL = [Float](repeating: 0, count: C), inR = [Float](repeating: 0, count: C)
        var lRe = [Float](repeating: 0, count: plane), lIm = lRe, rRe = lRe, rIm = lRe
        var oLRe = lRe, oLIm = lRe, oRRe = lRe, oRIm = lRe
        var yL = [Float](repeating: 0, count: C), yR = yL
        let windows = (frames + G - 1) / G

        var pos = 0, w = 0
        while pos < frames {
            if flag.isCancelled { writer.abort(); throw CancellationError() }
            try readWindow(reader, start: pos - T, count: C, total: frames, left: &inL, right: &inR)
            spec.stft(inL, outRe: &lRe, outIm: &lIm)
            spec.stft(inR, outRe: &rRe, outIm: &rIm)

            try autoreleasepool {
                let input = try MLMultiArray(shape: [1, 4, NSNumber(value: F), NSNumber(value: D)], dataType: .float16)
                fill(input, planes: [lRe, lIm, rRe, rIm], dimF: F, dimT: D)
                let out = try model.prediction(from: MLDictionaryFeatureProvider(dictionary: ["input": input]))
                guard let arr = out.featureValue(for: "output")?.multiArrayValue else {
                    throw StemError.badOutput("không có \"output\"")
                }
                try extract(arr, dimF: F, dimT: D, into: &oLRe, &oLIm, &oRRe, &oRIm)
            }
            spec.istft(oLRe, oLIm, into: &yL)
            spec.istft(oRRe, oRIm, into: &yR)

            let n = min(G, frames - pos)
            try writer.append(left: yL, right: yR, from: T, count: n)
            pos += G; w += 1
            progress(0.06 + 0.94 * Double(w) / Double(windows))
        }
        try writer.finish()
        progress(1)
        return outURL
        #else
        throw StemError.unsupportedDevice
        #endif
    }

    // MARK: - Giải mã

    /// Trả về số mẫu (frame) stereo đã ghi.
    private static func decodeToRaw(video: URL, rawURL: URL, flag: CancelFlag,
                                    progress: (Double) -> Void) async throws -> Int {
        let asset = AVURLAsset(url: video)
        guard let track = try await asset.loadTracks(withMediaType: .audio).first else { throw SubtitleGenError.noAudio }
        let dur = (try? await asset.load(.duration).seconds) ?? 0

        let reader = try AVAssetReader(asset: asset)
        var layout = AudioChannelLayout()
        layout.mChannelLayoutTag = kAudioChannelLayoutTag_Stereo
        let settings: [String: Any] = [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVSampleRateKey: sampleRate,
            AVNumberOfChannelsKey: 2,
            AVChannelLayoutKey: Data(bytes: &layout, count: MemoryLayout<AudioChannelLayout>.size),
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: false,
            AVLinearPCMIsNonInterleaved: false,
        ]
        let out = AVAssetReaderAudioMixOutput(audioTracks: [track], audioSettings: settings)
        guard reader.canAdd(out) else { throw SubtitleGenError.extract("không đọc được track âm thanh") }
        reader.add(out)
        guard reader.startReading() else {
            throw SubtitleGenError.extract(reader.error?.localizedDescription ?? "không đọc được")
        }
        FileManager.default.createFile(atPath: rawURL.path, contents: nil)
        let h = try FileHandle(forWritingTo: rawURL)
        defer { try? h.close() }
        var bytes = 0
        while let sb = out.copyNextSampleBuffer() {
            if flag.isCancelled { reader.cancelReading(); throw CancellationError() }
            guard let block = CMSampleBufferGetDataBuffer(sb) else { continue }
            let len = CMBlockBufferGetDataLength(block)
            guard len > 0 else { continue }
            var data = Data(count: len)
            let st = data.withUnsafeMutableBytes { buf -> OSStatus in
                guard let base = buf.baseAddress else { return -1 }
                return CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: len, destination: base)
            }
            if st == kCMBlockBufferNoErr {
                try h.write(contentsOf: data)
                bytes += len
                if dur > 0 { progress(min(1, Double(bytes) / 4 / (dur * Double(sampleRate)))) }
            }
        }
        if reader.status == .failed {
            throw SubtitleGenError.extract(reader.error?.localizedDescription ?? "lỗi đọc")
        }
        return bytes / 4
    }

    /// Đọc `count` mẫu stereo bắt đầu từ chỉ số `start` (có thể âm / vượt cuối → điền 0).
    private static func readWindow(_ h: FileHandle, start: Int, count: Int, total: Int,
                                   left: inout [Float], right: inout [Float]) throws {
        for i in 0..<count { left[i] = 0; right[i] = 0 }
        let lo = max(0, start), hi = min(total, start + count)
        guard hi > lo else { return }
        try h.seek(toOffset: UInt64(lo) * 4)
        guard let data = try h.read(upToCount: (hi - lo) * 4), data.count >= 4 else { return }
        let n = data.count / 4
        data.withUnsafeBytes { raw in
            let p = raw.bindMemory(to: Int16.self)
            let off = lo - start
            for i in 0..<n {
                left[off + i] = Float(Int16(littleEndian: p[2 * i])) / 32768
                right[off + i] = Float(Int16(littleEndian: p[2 * i + 1])) / 32768
            }
        }
    }

    // MARK: - Chuyển đổi MLMultiArray (có tính đến strides)

    #if canImport(CoreML) && arch(arm64)
    private static func fill(_ a: MLMultiArray, planes: [[Float]], dimF: Int, dimT: Int) {
        let s = a.strides.map { $0.intValue }          // [n, c, f, t]
        let p = a.dataPointer.bindMemory(to: Float16.self, capacity: a.count)
        for c in 0..<4 {
            let src = planes[c]
            for f in 0..<dimF {
                let base = c * s[1] + f * s[2]
                for t in 0..<dimT { p[base + t * s[3]] = Float16(src[f * dimT + t]) }
            }
        }
    }

    private static func extract(_ a: MLMultiArray, dimF: Int, dimT: Int,
                                into lRe: inout [Float], _ lIm: inout [Float],
                                _ rRe: inout [Float], _ rIm: inout [Float]) throws {
        guard a.shape.count == 4, a.shape[1].intValue == 4,
              a.shape[2].intValue == dimF, a.shape[3].intValue == dimT else {
            throw StemError.badOutput("kích thước \(a.shape)")
        }
        let s = a.strides.map { $0.intValue }
        func read(_ get: (Int) -> Float) {
            for f in 0..<dimF {
                for t in 0..<dimT {
                    let o = f * s[2] + t * s[3]
                    lRe[f * dimT + t] = get(0 * s[1] + o)
                    lIm[f * dimT + t] = get(1 * s[1] + o)
                    rRe[f * dimT + t] = get(2 * s[1] + o)
                    rIm[f * dimT + t] = get(3 * s[1] + o)
                }
            }
        }
        switch a.dataType {
        case .float16:
            let p = a.dataPointer.bindMemory(to: Float16.self, capacity: a.count)
            read { Float(p[$0]) }
        case .float32:
            let p = a.dataPointer.bindMemory(to: Float.self, capacity: a.count)
            read { p[$0] }
        default:
            throw StemError.badOutput("kiểu dữ liệu \(a.dataType.rawValue)")
        }
    }
    #endif
}

// MARK: - Ghi WAV 16-bit theo dòng

final class StreamWAVWriter {
    private let url: URL
    private let handle: FileHandle
    private let channels: Int
    private let sampleRate: Int
    private var dataBytes: UInt64 = 0

    init(url: URL, sampleRate: Int, channels: Int) throws {
        self.url = url
        self.channels = channels
        self.sampleRate = sampleRate
        guard FileManager.default.createFile(atPath: url.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
        handle = try FileHandle(forWritingTo: url)
        try handle.write(contentsOf: Self.header(sampleRate: sampleRate, channels: channels, dataBytes: 0))
    }

    private static func header(sampleRate: Int, channels: Int, dataBytes: UInt64) -> Data {
        var d = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 4)) }
        func u16(_ v: UInt16) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 2)) }
        let size = UInt32(min(dataBytes, UInt64(UInt32.max - 36)))
        d.append("RIFF".data(using: .ascii)!); u32(36 + size)
        d.append("WAVE".data(using: .ascii)!)
        d.append("fmt ".data(using: .ascii)!); u32(16); u16(1); u16(UInt16(channels))
        u32(UInt32(sampleRate)); u32(UInt32(sampleRate * channels * 2)); u16(UInt16(channels * 2)); u16(16)
        d.append("data".data(using: .ascii)!); u32(size)
        return d
    }

    /// Ghi `count` mẫu từ chỉ số `from` của hai kênh, xen kẽ L R.
    func append(left: [Float], right: [Float], from: Int, count: Int) throws {
        var pcm = [Int16](repeating: 0, count: count * 2)
        for i in 0..<count {
            pcm[2 * i] = Int16(max(-1, min(1, left[from + i])) * 32767)
            pcm[2 * i + 1] = Int16(max(-1, min(1, right[from + i])) * 32767)
        }
        try pcm.withUnsafeBufferPointer { try handle.write(contentsOf: Data(buffer: $0)) }
        dataBytes += UInt64(count * 2 * 2)
    }

    func finish() throws {
        // sửa lại kích thước trong phần đầu
        try handle.seek(toOffset: 0)
        try handle.write(contentsOf: Self.header(sampleRate: sampleRate, channels: channels, dataBytes: dataBytes))
        try handle.close()
    }

    func abort() {
        try? handle.close()
        try? FileManager.default.removeItem(at: url)
    }
}
