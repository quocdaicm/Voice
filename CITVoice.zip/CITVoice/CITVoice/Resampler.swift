import Foundation

/// Đổi tần số lấy mẫu bằng sinc có cửa sổ Hann, dạng đa pha (polyphase).
/// Dùng cho giọng mẫu nhân bản: bản gốc (44.1/48 kHz…) → 16 kHz (x-vector) và 24 kHz (codec encoder).
/// Độ lệch so với sóng chuẩn khi thử trên Python: < 1e-4 (xem README mục "Kiểm tra").
enum Resampler {
    static func resample(_ x: [Float], from: Int, to: Int) -> [Float] {
        if from == to || x.isEmpty || from <= 0 || to <= 0 { return x }
        let ratio = Double(to) / Double(from)
        let outCount = Int(Double(x.count) * ratio)
        if outCount <= 0 { return [] }

        let cutoff = min(1.0, ratio) * 0.97          // tỉ lệ so với Nyquist của tín hiệu vào
        let hw = 16.0 / cutoff                       // nửa độ rộng nhân (đơn vị: mẫu vào)
        let L = Int(hw.rounded(.up))
        let g = gcd(from, to)
        let inStep = from / g
        let outPer = to / g

        // Mỗi pha (vị trí lẻ) có một bộ hệ số riêng, chuẩn hoá để độ lợi DC = 1.
        var kernels: [[Float]] = []
        kernels.reserveCapacity(outPer)
        for p in 0..<outPer {
            let frac = Double((p * inStep) % outPer) / Double(outPer)
            var ks = [Double](repeating: 0, count: 2 * L)
            var sum = 0.0
            for k in 0..<(2 * L) {
                let t = Double(-L + 1 + k) - frac
                if abs(t) >= hw { continue }
                let a = cutoff * t
                let s = abs(a) < 1e-12 ? 1.0 : sin(Double.pi * a) / (Double.pi * a)
                let w = 0.5 + 0.5 * cos(Double.pi * t / hw)
                let v = cutoff * s * w
                ks[k] = v
                sum += v
            }
            if sum == 0 { sum = 1 }
            kernels.append(ks.map { Float($0 / sum) })
        }

        var y = [Float](repeating: 0, count: outCount)
        x.withUnsafeBufferPointer { xp in
            for n in 0..<outCount {
                let p = n % outPer
                let fl = (n / outPer) * inStep + (p * inStep) / outPer
                let start = fl - L + 1
                let kern = kernels[p]
                var acc: Float = 0
                if start >= 0 && start + 2 * L <= xp.count {
                    for k in 0..<(2 * L) { acc += xp[start + k] * kern[k] }
                } else {
                    for k in 0..<(2 * L) {
                        let i = start + k
                        if i >= 0 && i < xp.count { acc += xp[i] * kern[k] }
                    }
                }
                y[n] = acc
            }
        }
        return y
    }

    private static func gcd(_ a: Int, _ b: Int) -> Int { b == 0 ? a : gcd(b, a % b) }
}
