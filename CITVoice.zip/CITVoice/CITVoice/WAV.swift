import Foundation

enum WAV {
    /// Float [-1, 1] mono -> WAV 16-bit PCM.
    static func encode(samples: [Float], sampleRate: Int) -> Data {
        let dataBytes = samples.count * 2
        var d = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 4)) }
        func u16(_ v: UInt16) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 2)) }
        d.append("RIFF".data(using: .ascii)!); u32(UInt32(36 + dataBytes))
        d.append("WAVE".data(using: .ascii)!)
        d.append("fmt ".data(using: .ascii)!); u32(16); u16(1); u16(1)
        u32(UInt32(sampleRate)); u32(UInt32(sampleRate * 2)); u16(2); u16(16)
        d.append("data".data(using: .ascii)!); u32(UInt32(dataBytes))
        var pcm = [Int16](repeating: 0, count: samples.count)
        for i in 0..<samples.count {
            let v = max(-1, min(1, samples[i]))
            pcm[i] = Int16(v * 32767)
        }
        pcm.withUnsafeBufferPointer { d.append(Data(buffer: $0)) }   // iOS = little-endian
        return d
    }

    /// Ghi WAV 16-bit theo từng khối để không phải giữ thêm bản sao lớn trong RAM.
    static func write(samples: [Float], sampleRate: Int, to url: URL) throws {
        let dataBytes = samples.count * 2
        var head = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; head.append(Data(bytes: &x, count: 4)) }
        func u16(_ v: UInt16) { var x = v.littleEndian; head.append(Data(bytes: &x, count: 2)) }
        head.append("RIFF".data(using: .ascii)!); u32(UInt32(36 + dataBytes))
        head.append("WAVE".data(using: .ascii)!)
        head.append("fmt ".data(using: .ascii)!); u32(16); u16(1); u16(1)
        u32(UInt32(sampleRate)); u32(UInt32(sampleRate * 2)); u16(2); u16(16)
        head.append("data".data(using: .ascii)!); u32(UInt32(dataBytes))

        try? FileManager.default.removeItem(at: url)
        guard FileManager.default.createFile(atPath: url.path, contents: head) else {
            throw CocoaError(.fileWriteUnknown)
        }
        let h = try FileHandle(forWritingTo: url)
        defer { try? h.close() }
        try h.seekToEnd()
        let block = 1 << 20
        var i = 0
        while i < samples.count {
            let n = min(block, samples.count - i)
            var pcm = [Int16](repeating: 0, count: n)
            for k in 0..<n { pcm[k] = Int16(max(-1, min(1, samples[i + k])) * 32767) }
            pcm.withUnsafeBufferPointer { h.write(Data(buffer: $0)) }
            i += n
        }
    }
}
