import SwiftUI

// MARK: - Lịch sử các bản đã tạo

struct HistoryItem: Codable, Identifiable, Equatable {
    var id: UUID
    var date: Date
    var text: String
    var voice: String
    var speed: Double
    var seconds: Double
    var partial: Bool          // true: người dùng huỷ giữa chừng, chỉ có phần đã tạo
    var fileName: String
}

/// Lưu WAV + chỉ mục JSON trong Application Support/History (không sao lưu iCloud). Giữ tối đa `maxItems` bản mới nhất.
@MainActor
final class HistoryStore: ObservableObject {
    static let maxItems = 30
    @Published private(set) var items: [HistoryItem] = []

    private let dir: URL
    private var indexURL: URL { dir.appendingPathComponent("index.json") }

    init() {
        var d = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("History", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? d.setResourceValues(values)
        dir = d
        if let data = try? Data(contentsOf: d.appendingPathComponent("index.json")),
           let list = try? JSONDecoder().decode([HistoryItem].self, from: data) {
            items = list.filter { FileManager.default.fileExists(atPath: d.appendingPathComponent($0.fileName).path) }
        }
    }

    func url(for item: HistoryItem) -> URL { dir.appendingPathComponent(item.fileName) }

    var totalBytes: Int {
        items.reduce(0) { sum, it in
            let size = (try? FileManager.default.attributesOfItem(atPath: url(for: it).path)[.size] as? Int) ?? 0
            return sum + (size ?? 0)
        }
    }

    /// Chép WAV vào lịch sử (file gốc ở thư mục tạm vẫn giữ nguyên để phát).
    func add(wav: URL, text: String, voice: String, speed: Double, seconds: Double, partial: Bool) {
        let id = UUID()
        let name = "\(id.uuidString).wav"
        do {
            try FileManager.default.copyItem(at: wav, to: dir.appendingPathComponent(name))
        } catch { return }
        items.insert(HistoryItem(id: id, date: Date(), text: text, voice: voice, speed: speed,
                                 seconds: seconds, partial: partial, fileName: name), at: 0)
        while items.count > Self.maxItems, let old = items.last {
            try? FileManager.default.removeItem(at: url(for: old))
            items.removeLast()
        }
        save()
    }

    func remove(_ item: HistoryItem) {
        try? FileManager.default.removeItem(at: url(for: item))
        items.removeAll { $0.id == item.id }
        save()
    }

    func removeAll() {
        for it in items { try? FileManager.default.removeItem(at: url(for: it)) }
        items = []
        save()
    }

    private func save() {
        try? JSONEncoder().encode(items).write(to: indexURL, options: .atomic)
    }
}

struct HistoryView: View {
    @ObservedObject var history: HistoryStore
    @ObservedObject var player: AudioPlayer
    @ObservedObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var message: String?
    @State private var confirmClear = false

    private static let dateFormat: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "vi_VN")
        f.dateStyle = .short
        f.timeStyle = .short
        return f
    }()

    var body: some View {
        List {
            if history.items.isEmpty {
                Text("Chưa có bản nào. Mỗi lần bấm \"Tạo giọng nói\", kết quả được lưu ở đây (tối đa \(HistoryStore.maxItems) bản mới nhất).")
                    .font(.footnote).foregroundStyle(.secondary)
            } else {
                Section {
                    ForEach(history.items) { item in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(item.text).font(.subheadline).lineLimit(2)
                            Text("\(Self.dateFormat.string(from: item.date)) · \(item.voice) · \(String(format: "%.0f", item.seconds)) giây · \(String(format: "%.2fx", item.speed))\(item.partial ? " · một phần" : "")")
                                .font(.caption).foregroundStyle(.secondary)
                            WaveformPlayer(url: history.url(for: item), player: player) { message = $0 }
                            Button {
                                model.text = item.text
                                if model.voices.contains(where: { $0.id == item.voice }) { model.selectedVoiceID = item.voice }
                                model.speed = item.speed
                                Haptics.tap()
                                dismiss()
                            } label: {
                                Label("Dùng lại văn bản này", systemImage: "arrow.uturn.backward")
                                    .font(.footnote.weight(.semibold))
                            }
                            .buttonStyle(.borderless)
                        }
                        .padding(.vertical, 4)
                        .swipeActions {
                            Button(role: .destructive) {
                                if player.loadedURL == history.url(for: item) { player.unload() }
                                history.remove(item)
                            } label: { Label("Xoá", systemImage: "trash") }
                        }
                    }
                } footer: {
                    Text("Đang dùng \(ByteCountFormatter.string(fromByteCount: Int64(history.totalBytes), countStyle: .file)). Vuốt sang trái để xoá một bản.")
                }
                if let message { Text(message).font(.footnote).foregroundStyle(.red) }
            }
        }
        .navigationTitle("Lịch sử")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if !history.items.isEmpty {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xoá hết", role: .destructive) { confirmClear = true }
                }
            }
        }
        .confirmationDialog("Xoá toàn bộ lịch sử?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xoá hết", role: .destructive) { player.unload(); history.removeAll() }
            Button("Giữ lại", role: .cancel) {}
        }
    }
}

// MARK: - Nút chia sẻ / xuất (WAV hoặc M4A)

struct ExportMenu: View {
    let url: URL
    var onError: (String) -> Void = { _ in }
    @State private var busy = false

    var body: some View {
        Menu {
            ShareLink(item: url) { Label("Chia sẻ WAV (không nén)", systemImage: "waveform") }
            Button {
                busy = true
                Task {
                    defer { busy = false }
                    do {
                        let out = try await AudioExporter.m4a(from: url)
                        SharePresenter.share(out)
                    } catch {
                        onError("Không xuất được M4A: \(error.localizedDescription)")
                    }
                }
            } label: { Label("Chia sẻ M4A (AAC, nhẹ hơn)", systemImage: "music.note") }
        } label: {
            Group {
                if busy { ProgressView() } else { SVGIcon("IcShare", size: 20).foregroundStyle(Brand.indigo) }
            }
            .frame(width: 40, height: 40)
            .background(Brand.indigo.opacity(0.12), in: Circle())
        }
        .disabled(busy)
        .accessibilityLabel("Lưu hoặc chia sẻ file âm thanh")
    }
}
