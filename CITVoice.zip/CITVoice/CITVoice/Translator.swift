import SwiftUI
#if canImport(Translation)
import Translation
#endif

enum TranslationAvailabilityState { case ready, needsDownload, unsupported }

/// Cầu nối dịch bằng Apple Translation (iOS 18+, chạy trên máy). Framework này chỉ cho dịch qua một "session"
/// lấy từ SwiftUI (`.translationTask`), nên bridge giữ một việc cần dịch và view `translationHost` sẽ xử lý.
@MainActor
final class TranslationBridge: ObservableObject {
    struct Job: Identifiable {
        let id = UUID()
        let source: String
        let target: String
        let texts: [String]
        let continuation: CheckedContinuation<[String], Error>
    }

    @Published var job: Job?

    func translate(source: String, target: String = "vi", texts: [String]) async throws -> [String] {
        try await withCheckedThrowingContinuation { c in
            job = Job(source: source, target: target, texts: texts, continuation: c)
        }
    }

    func finish(_ result: Result<[String], Error>) {
        guard let j = job else { return }
        job = nil
        j.continuation.resume(with: result)
    }

    func cancel() { finish(.failure(CancellationError())) }

    /// Mã ngôn ngữ Whisper → mã Locale.Language.
    nonisolated static func languageCode(_ whisper: String) -> String {
        switch whisper {
        case "zh": return "zh-Hans"
        default: return whisper
        }
    }

    /// Cặp ngôn ngữ nguồn → tiếng Việt có dịch được trên máy không.
    static func availability(source: String, target: String = "vi") async -> TranslationAvailabilityState {
        #if canImport(Translation)
        if #available(iOS 18.0, *) {
            let status = await LanguageAvailability().status(
                from: Locale.Language(identifier: languageCode(source)),
                to: Locale.Language(identifier: languageCode(target)))
            switch status {
            case .installed: return .ready
            case .supported: return .needsDownload
            default: return .unsupported
            }
        }
        #endif
        return .unsupported
    }
}

#if canImport(Translation)
@available(iOS 18.0, *)
private struct TranslationHost: ViewModifier {
    @ObservedObject var bridge: TranslationBridge
    @State private var config: TranslationSession.Configuration?

    func body(content: Content) -> some View {
        let bridge = self.bridge
        return content
            .onChange(of: bridge.job?.id) { _ in
                guard let job = bridge.job else { return }
                let new = TranslationSession.Configuration(
                    source: Locale.Language(identifier: TranslationBridge.languageCode(job.source)),
                    target: Locale.Language(identifier: TranslationBridge.languageCode(job.target)))
                if config == new { config?.invalidate() } else { config = new }
            }
            .translationTask(config) { session in
                guard let job = await bridge.job else { return }
                do {
                    let reqs = job.texts.enumerated().map {
                        TranslationSession.Request(sourceText: $0.element, clientIdentifier: String($0.offset))
                    }
                    let responses = try await session.translations(from: reqs)
                    var out = job.texts
                    for r in responses {
                        if let id = r.clientIdentifier, let i = Int(id), out.indices.contains(i) {
                            out[i] = r.targetText
                        }
                    }
                    await bridge.finish(.success(out))
                } catch {
                    await bridge.finish(.failure(error))
                }
            }
    }
}
#endif

extension View {
    /// Gắn vào view đang hiển thị (kể cả nội dung sheet) để dịch có thể chạy và hiện hộp tải ngôn ngữ.
    @ViewBuilder
    func translationHost(_ bridge: TranslationBridge) -> some View {
        #if canImport(Translation)
        if #available(iOS 18.0, *) {
            self.modifier(TranslationHost(bridge: bridge))
        } else {
            self
        }
        #else
        self
        #endif
    }
}
