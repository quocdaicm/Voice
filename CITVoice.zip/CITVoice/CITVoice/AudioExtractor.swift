import AVFoundation

enum SubtitleGenError: LocalizedError {
    case noAudio
    case extract(String)
    case recognizerMissing
    case nothingRecognized

    var errorDescription: String? {
        switch self {
        case .noAudio: return "Video không có âm thanh để nhận dạng."
        case .extract(let m): return "Không trích được âm thanh: \(m)"
        case .recognizerMissing: return "Bản build này chưa có WhisperKit (nhận dạng giọng nói)."
        case .nothingRecognized: return "Không nhận dạng được lời nói nào trong video."
        }
    }
}

/// Trích âm thanh từ video ra WAV 16 kHz mono (định dạng Whisper cần).
enum AudioExtractor {
    static func wav16k(from video: URL) async throws -> URL {
        try await wav(from: video, sampleRate: 16000)
    }

    /// Trích âm thanh của bất kỳ file video/âm thanh nào ra WAV mono ở tần số cho trước.
    static func wav(from video: URL, sampleRate: Int, start: Double = 0, duration: Double? = nil) async throws -> URL {
        try await Task.detached(priority: .userInitiated) { () throws -> URL in
            let asset = AVURLAsset(url: video)
            guard let track = try await asset.loadTracks(withMediaType: .audio).first else { throw SubtitleGenError.noAudio }
            let reader = try AVAssetReader(asset: asset)
            let settings: [String: Any] = [
                AVFormatIDKey: kAudioFormatLinearPCM,
                AVSampleRateKey: sampleRate,
                AVNumberOfChannelsKey: 1,
                AVLinearPCMBitDepthKey: 32,
                AVLinearPCMIsFloatKey: true,
                AVLinearPCMIsBigEndianKey: false,
                AVLinearPCMIsNonInterleaved: false
            ]
            let out = AVAssetReaderAudioMixOutput(audioTracks: [track], audioSettings: settings)
            guard reader.canAdd(out) else { throw SubtitleGenError.extract("không đọc được track âm thanh") }
            if start > 0 || duration != nil {
                let d = duration.map { CMTime(seconds: $0, preferredTimescale: 600) } ?? .positiveInfinity
                reader.timeRange = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600), duration: d)
            }
            reader.add(out)
            guard reader.startReading() else {
                throw SubtitleGenError.extract(reader.error?.localizedDescription ?? "không đọc được")
            }
            var samples: [Float] = []
            while let sb = out.copyNextSampleBuffer() {
                try Task.checkCancellation()
                guard let block = CMSampleBufferGetDataBuffer(sb) else { continue }
                let len = CMBlockBufferGetDataLength(block)
                guard len >= 4 else { continue }
                let n = len / 4
                var chunk = [Float](repeating: 0, count: n)
                let status = chunk.withUnsafeMutableBytes { buf -> OSStatus in
                    guard let base = buf.baseAddress else { return -1 }
                    return CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: n * 4, destination: base)
                }
                if status == kCMBlockBufferNoErr { samples.append(contentsOf: chunk) }
            }
            if reader.status == .failed {
                throw SubtitleGenError.extract(reader.error?.localizedDescription ?? "lỗi đọc")
            }
            guard !samples.isEmpty else { throw SubtitleGenError.noAudio }
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("asr-\(UUID().uuidString).wav")
            try WAV.encode(samples: samples, sampleRate: sampleRate).write(to: url)
            return url
        }.value
    }
}
