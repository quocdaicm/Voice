import Foundation
import AVFoundation

/// Tách riêng tiếng nói khỏi nhạc nền cho giọng mẫu nhân bản.
/// Model UVR chỉ trả về phần nhạc nền (instrumental), nên: tiếng nói = bản gốc − nhạc nền.
enum VocalIsolator {
    static let sampleRate = 44_100

    /// Trả về WAV mono 44,1 kHz chỉ còn tiếng nói của `maxSeconds` giây đầu (đủ cho giọng mẫu, tách nhanh hơn).
    static func vocals(from source: URL, compiledModel: URL, maxSeconds: Double = 40,
                       progress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        let fm = FileManager.default
        let tmp = fm.temporaryDirectory

        // 1) Bản gốc → mono 44,1 kHz, cắt ≤ maxSeconds, ghi ra WAV tạm để đưa cho bộ tách.
        let fullURL = try await AudioExtractor.wav(from: source, sampleRate: sampleRate)
        defer { try? fm.removeItem(at: fullURL) }
        var orig = try ReferenceAudio.load(url: fullURL, maxSeconds: maxSeconds).samples
        guard orig.count > sampleRate else { throw TTSError.clone("File quá ngắn để tách tiếng nói.") }
        orig = Array(orig.prefix(Int(maxSeconds * Double(sampleRate))))
        let cutURL = tmp.appendingPathComponent("vocal-in-\(UUID().uuidString).wav")
        try WAV.write(samples: orig, sampleRate: sampleRate, to: cutURL)
        defer { try? fm.removeItem(at: cutURL) }

        // 2) Tách nhạc nền
        let instURL = try await StemSeparator.instrumental(from: cutURL, compiledModel: compiledModel, progress: progress)
        defer { try? fm.removeItem(at: instURL) }
        let inst = try ReferenceAudio.load(url: instURL, maxSeconds: maxSeconds + 5).samples   // stereo → mono (trung bình)

        // 3) Tiếng nói = gốc − nhạc nền
        let n = min(orig.count, inst.count)
        guard n > sampleRate else { throw TTSError.clone("Không tách được tiếng nói từ file này.") }
        var voc = [Float](repeating: 0, count: n)
        for i in 0..<n { voc[i] = orig[i] - inst[i] }

        // Nếu gần như im lặng (model không thấy tiếng nói) → báo lỗi để dùng file gốc.
        let peak = voc.reduce(Float(0)) { max($0, abs($1)) }
        guard peak > 0.003 else { throw TTSError.clone("Không thấy tiếng nói trong file này.") }

        let out = tmp.appendingPathComponent("vocal-out-\(UUID().uuidString).wav")
        try WAV.write(samples: voc, sampleRate: sampleRate, to: out)
        return out
    }

    /// Tách tiếng nói của cả video theo từng đoạn ~4 phút (ít tốn RAM) và trả về WAV mono 16 kHz — đúng định dạng Whisper cần.
    static func vocals16k(from video: URL, compiledModel: URL, duration: Double,
                          progress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        let fm = FileManager.default
        let chunk = 240.0
        let total = duration > 0 ? duration : 600
        let parts = max(1, Int((total / chunk).rounded(.up)))
        var out: [Float] = []
        for i in 0..<parts {
            try Task.checkCancellation()
            let start = Double(i) * chunk
            let len = min(chunk, total - start)
            if len < 0.5 { break }
            let part = try await AudioExtractor.wav(from: video, sampleRate: sampleRate, start: start, duration: len + 0.2)
            defer { try? fm.removeItem(at: part) }
            let orig = try ReferenceAudio.load(url: part, maxSeconds: chunk + 5).samples
            guard orig.count > sampleRate / 2 else { continue }
            let base = Double(i) / Double(parts), span = 1 / Double(parts)
            let instURL = try await StemSeparator.instrumental(from: part, compiledModel: compiledModel) { p in
                progress(base + span * p)
            }
            defer { try? fm.removeItem(at: instURL) }
            let inst = try ReferenceAudio.load(url: instURL, maxSeconds: chunk + 10).samples
            let n = min(orig.count, inst.count)
            var voc = [Float](repeating: 0, count: n)
            for k in 0..<n { voc[k] = orig[k] - inst[k] }
            out += Resampler.resample(voc, from: sampleRate, to: 16_000)
        }
        guard out.count > 16_000 else { throw SubtitleGenError.noAudio }
        // Cho Whisper nghe rõ hơn: chuẩn hoá âm lượng (tiếng nói tách ra thường nhỏ).
        out = AudioUtils.normalizeLoudness(out, targetRMSdB: -20, peakCeil: 0.97)
        let url = fm.temporaryDirectory.appendingPathComponent("asr-vocal-\(UUID().uuidString).wav")
        try WAV.write(samples: out, sampleRate: 16_000, to: url)
        progress(1)
        return url
    }
}
