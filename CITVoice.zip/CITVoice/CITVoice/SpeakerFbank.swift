import Foundation

/// Kaldi fbank 80 mel @16 kHz — đầu vào của `speaker_encoder.onnx` (x-vector 192 chiều).
/// Tham số mặc định của kaldi-native-fbank: khung 25 ms / bước 10 ms, cửa sổ Povey, bỏ DC, pre-emphasis 0.97,
/// FFT 512, mel 20 Hz → Nyquist, log(max(năng lượng, FLT_EPSILON)), snip_edges. Sau đó trừ trung bình theo thời gian (CMN).
/// CMN không đổi nếu model đã tự có CMN bên trong (trừ hai lần = trừ một lần).
/// Đã kiểm tra logic (FFT radix-2, bộ lọc mel, ghép khung) bằng bản Python tương đương, sai số ~1e-13 so với numpy.
enum SpeakerFbank {
    static let numBins = 80
    private static let frameLen = 400
    private static let frameShift = 160
    private static let nfft = 512
    private static let preemph = 0.97
    private static let epsilon = 1.1920929e-7      // FLT_EPSILON

    private static func mel(_ f: Double) -> Double { 1127.0 * log(1.0 + f / 700.0) }

    private static let window: [Double] = (0..<frameLen).map { i in
        pow(0.5 - 0.5 * cos(2.0 * Double.pi * Double(i) / Double(frameLen - 1)), 0.85)
    }

    private static let twRe: [Double] = (0..<(nfft / 2)).map { cos(-2.0 * Double.pi * Double($0) / Double(nfft)) }
    private static let twIm: [Double] = (0..<(nfft / 2)).map { sin(-2.0 * Double.pi * Double($0) / Double(nfft)) }

    private static let bitRev: [Int] = (0..<nfft).map { i in
        var r = 0, x = i
        for _ in 0..<9 { r = (r << 1) | (x & 1); x >>= 1 }
        return r
    }

    /// [80][256]: trọng số tam giác theo thang mel (bỏ bin Nyquist như Kaldi).
    private static let bank: [[Double]] = {
        let lo = mel(20.0), hi = mel(8000.0)
        let delta = (hi - lo) / Double(numBins + 1)
        let binWidth = 16000.0 / Double(nfft)
        var out = [[Double]](repeating: [Double](repeating: 0, count: nfft / 2), count: numBins)
        for b in 0..<numBins {
            let l = lo + Double(b) * delta
            let c = lo + Double(b + 1) * delta
            let r = lo + Double(b + 2) * delta
            for i in 0..<(nfft / 2) {
                let m = mel(binWidth * Double(i))
                if m > l && m < r { out[b][i] = m <= c ? (m - l) / (c - l) : (r - m) / (r - c) }
            }
        }
        return out
    }()

    private static func fft(_ re: inout [Double], _ im: inout [Double]) {
        var size = 2
        while size <= nfft {
            let half = size / 2
            let step = nfft / size
            var s = 0
            while s < nfft {
                for j in 0..<half {
                    let wr = twRe[j * step], wi = twIm[j * step]
                    let a = s + j, b = a + half
                    let tr = re[b] * wr - im[b] * wi
                    let ti = re[b] * wi + im[b] * wr
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                }
                s += size
            }
            size *= 2
        }
    }

    /// Trả về ma trận hàng-trước [frames][80] đã trừ trung bình; nil nếu ngắn hơn một khung (25 ms).
    static func compute(_ samples: [Float]) -> (frames: Int, data: [Float])? {
        guard samples.count >= frameLen else { return nil }
        let frames = 1 + (samples.count - frameLen) / frameShift
        var out = [Float](repeating: 0, count: frames * numBins)
        var re = [Double](repeating: 0, count: nfft)
        var im = [Double](repeating: 0, count: nfft)
        var frame = [Double](repeating: 0, count: frameLen)
        var power = [Double](repeating: 0, count: nfft / 2)

        for t in 0..<frames {
            let s = t * frameShift
            var mean = 0.0
            for i in 0..<frameLen {
                frame[i] = Double(samples[s + i]) * 32768.0
                mean += frame[i]
            }
            mean /= Double(frameLen)
            for i in 0..<frameLen { frame[i] -= mean }
            var i = frameLen - 1
            while i > 0 { frame[i] -= preemph * frame[i - 1]; i -= 1 }
            frame[0] -= preemph * frame[0]

            for k in 0..<nfft { re[k] = 0; im[k] = 0 }
            for k in 0..<frameLen { re[bitRev[k]] = frame[k] * window[k] }
            fft(&re, &im)
            for k in 0..<(nfft / 2) { power[k] = re[k] * re[k] + im[k] * im[k] }

            for b in 0..<numBins {
                var e = 0.0
                let w = bank[b]
                for k in 0..<(nfft / 2) { e += w[k] * power[k] }
                out[t * numBins + b] = Float(log(max(e, epsilon)))
            }
        }

        // CMN: trừ trung bình theo thời gian cho từng chiều mel.
        for b in 0..<numBins {
            var m: Float = 0
            for t in 0..<frames { m += out[t * numBins + b] }
            m /= Float(frames)
            for t in 0..<frames { out[t * numBins + b] -= m }
        }
        return (frames, out)
    }
}
