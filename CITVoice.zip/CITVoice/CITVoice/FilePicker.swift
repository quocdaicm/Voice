import SwiftUI
import UniformTypeIdentifiers
import UIKit

// Bộ chọn file riêng (UIDocumentPickerViewController), thay cho `.fileImporter` của SwiftUI.
// Lý do: nhiều `.fileImporter` nằm trong cùng cây màn hình (màn chính có Sao lưu = chỉ .json,
// màn Nhân bản giọng, màn Lồng tiếng) có thể mở nhầm bộ lọc, làm file âm thanh bị mờ không chọn được.
// Mỗi lần mở ở đây là một sheet độc lập nên luôn đúng bộ lọc của màn đang dùng.

// Mở UIDocumentPickerViewController trực tiếp từ UIKit (không đặt trong `.sheet` của SwiftUI).
// Lý do: bộ chọn nằm trong sheet SwiftUI có thể tự đóng khi chạm file mà không gọi lại app (không chọn được file
// dù không bị mờ). Với file (không phải thư mục) dùng `asCopy: true`: hệ thống chép sẵn file về thư mục tạm
// của app nên không cần quyền truy cập bảo mật hay tải iCloud thủ công.

private final class PickerDelegate: NSObject, UIDocumentPickerDelegate {
    let onPick: (Result<URL, Error>) -> Void
    init(onPick: @escaping (Result<URL, Error>) -> Void) { self.onPick = onPick }
    func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if let u = urls.first { onPick(.success(u)) }
    }
    func documentPickerWasCancelled(_ c: UIDocumentPickerViewController) {}
}

private var pickerDelegateKey: UInt8 = 0

@MainActor
private enum DocumentPresenter {
    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let window = scenes.flatMap { $0.windows }.first { $0.isKeyWindow } ?? scenes.flatMap { $0.windows }.first
        var top = window?.rootViewController
        while let next = top?.presentedViewController, !next.isBeingDismissed { top = next }
        return top
    }

    static func present(types: [UTType], onPick: @escaping (Result<URL, Error>) -> Void, attempt: Int = 0) {
        guard let top = topViewController() else { return }
        // Đang có màn khác đóng dở (vd. sheet thư mục CIT Voice) → đợi một chút rồi mở.
        if (top.isBeingDismissed || top.isBeingPresented) && attempt < 10 {
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 300_000_000)
                present(types: types, onPick: onPick, attempt: attempt + 1)
            }
            return
        }
        let isFolder = types.contains(.folder)
        let p = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: !isFolder)
        p.allowsMultipleSelection = false
        let d = PickerDelegate(onPick: onPick)
        p.delegate = d
        objc_setAssociatedObject(p, &pickerDelegateKey, d, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)   // giữ delegate sống cùng bộ chọn
        top.present(p, animated: true)
    }
}

private struct FilePickerModifier: ViewModifier {
    @Binding var isPresented: Bool
    let types: [UTType]
    let onPick: (Result<URL, Error>) -> Void

    func body(content: Content) -> some View {
        content.onChange(of: isPresented) { value in
            guard value else { return }
            isPresented = false
            DocumentPresenter.present(types: types, onPick: onPick)
        }
    }
}

extension View {
    /// Dùng giống `.fileImporter(isPresented:allowedContentTypes:onCompletion:)` nhưng mở bộ chọn file của UIKit.
    /// Chọn thư mục: truyền `[.folder]`.
    func filePicker(isPresented: Binding<Bool>,
                    types: [UTType],
                    onPick: @escaping (Result<URL, Error>) -> Void) -> some View {
        modifier(FilePickerModifier(isPresented: isPresented, types: types, onPick: onPick))
    }
}

// MARK: - Chọn từ thư mục "CIT Voice" (cách dự phòng khi bộ chọn file không cho chọn)
// Bước làm: mở app Tệp → Trên iPhone → CIT Voice → dán/chép file nhạc vào đó. Rồi mở danh sách này trong app.

struct AppFolderFile: Identifiable {
    let id: URL
    var url: URL { id }
    var name: String { id.lastPathComponent }
    let size: Int
}

enum AppFolder {
    static let exts: Set<String> = ["mp3", "m4a", "wav", "aac", "caf", "aif", "aiff", "flac", "mp4", "mov", "m4v", "3gp", "opus", "ogg"]

    static var directory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    /// Mọi file trong thư mục tài liệu của app (không lọc đuôi để file không có đuôi vẫn thấy được).
    static func list() -> [AppFolderFile] {
        let fm = FileManager.default
        guard let urls = try? fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.fileSizeKey, .isDirectoryKey],
                                                     options: [.skipsHiddenFiles]) else { return [] }
        return urls.compactMap { u in
            let v = try? u.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey])
            if v?.isDirectory == true { return nil }
            let size = v?.fileSize ?? 0
            // Bỏ file JSON/văn bản của chính app (giọng, phụ đề…).
            let e = u.pathExtension.lowercased()
            if ["json", "srt", "vtt", "txt", "plist"].contains(e) { return nil }
            return AppFolderFile(id: u, size: size)
        }
        .sorted { $0.name.localizedCompare($1.name) == .orderedAscending }
    }
}

struct AppFolderSheet: View {
    var onPick: (URL) -> Void
    var onOther: (() -> Void)? = nil
    @Environment(\.dismiss) private var dismiss
    @State private var files: [AppFolderFile] = []

    var body: some View {
        NavigationStack {
            List {
                if files.isEmpty {
                    Section {
                        Text("Thư mục đang trống.\n\nMở app Tệp → Trên iPhone → thư mục CIT Voice, rồi chép hoặc dán file âm thanh/video vào đó. Quay lại đây và bấm làm mới. Hoặc bấm nút bên dưới để chọn ở nơi khác.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                } else {
                    Section("File trong thư mục CIT Voice") {
                        ForEach(files) { f in
                            Button {
                                dismiss()
                                onPick(f.url)
                            } label: {
                                HStack {
                                    Image(systemName: "waveform").foregroundStyle(.tint)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(f.name).foregroundStyle(.primary).lineLimit(2)
                                        Text(ByteCountFormatter.string(fromByteCount: Int64(f.size), countStyle: .file))
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                if let onOther {
                    Button {
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { onOther() }
                    } label: {
                        Label("Chọn file ở nơi khác (app Tệp)", systemImage: "folder")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(.bar)
                }
            }
            .navigationTitle("Thư mục CIT Voice")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Đóng") { dismiss() } }
                ToolbarItem(placement: .primaryAction) { Button { files = AppFolder.list() } label: { Image(systemName: "arrow.clockwise") } }
            }
            .onAppear { files = AppFolder.list() }
        }
    }
}
