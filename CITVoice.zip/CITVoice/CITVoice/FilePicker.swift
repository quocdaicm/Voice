import SwiftUI
import UniformTypeIdentifiers
import UIKit

// Bộ chọn file riêng (UIDocumentPickerViewController), thay cho `.fileImporter` của SwiftUI.
// Lý do: nhiều `.fileImporter` nằm trong cùng cây màn hình (màn chính có Sao lưu = chỉ .json,
// màn Nhân bản giọng, màn Lồng tiếng) có thể mở nhầm bộ lọc, làm file âm thanh bị mờ không chọn được.
// Mỗi lần mở ở đây là một sheet độc lập nên luôn đúng bộ lọc của màn đang dùng.

private struct FilePickerSheet: UIViewControllerRepresentable {
    let types: [UTType]
    let onPick: (Result<URL, Error>) -> Void
    let onDismiss: () -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let p = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        p.allowsMultipleSelection = false
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick, onDismiss: onDismiss) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (Result<URL, Error>) -> Void
        let onDismiss: () -> Void
        init(onPick: @escaping (Result<URL, Error>) -> Void, onDismiss: @escaping () -> Void) {
            self.onPick = onPick; self.onDismiss = onDismiss
        }
        func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onDismiss()
            if let u = urls.first { onPick(.success(u)) }
        }
        func documentPickerWasCancelled(_ c: UIDocumentPickerViewController) { onDismiss() }
    }
}

extension View {
    /// Dùng giống `.fileImporter(isPresented:allowedContentTypes:onCompletion:)` nhưng mở bộ chọn file riêng.
    func filePicker(isPresented: Binding<Bool>,
                    types: [UTType],
                    onPick: @escaping (Result<URL, Error>) -> Void) -> some View {
        sheet(isPresented: isPresented) {
            FilePickerSheet(types: types, onPick: onPick, onDismiss: { isPresented.wrappedValue = false })
                .ignoresSafeArea()
        }
    }
}
