import SwiftUI
import UniformTypeIdentifiers
import UIKit

// Bộ chọn file riêng (UIDocumentPickerViewController), thay cho `.fileImporter` của SwiftUI.
// Lý do: nhiều `.fileImporter` nằm trong cùng cây màn hình (màn chính có Sao lưu = chỉ .json,
// màn Nhân bản giọng, màn Lồng tiếng) có thể mở nhầm bộ lọc, làm file âm thanh bị mờ không chọn được.
// Mỗi lần mở ở đây là một sheet độc lập nên luôn đúng bộ lọc của màn đang dùng.

private struct FilePickerSheet: UIViewControllerRepresentable {
    let types: [UTType]
    let onPick: (Result<URL, Error>) -> Void
    let onDismiss: () -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let p = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        p.allowsMultipleSelection = false
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick, onDismiss: onDismiss) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (Result<URL, Error>) -> Void
        let onDismiss: () -> Void
        init(onPick: @escaping (Result<URL, Error>) -> Void, onDismiss: @escaping () -> Void) {
            self.onPick = onPick; self.onDismiss = onDismiss
        }
        func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onDismiss()
            if let u = urls.first { onPick(.success(u)) }
        }
        func documentPickerWasCancelled(_ c: UIDocumentPickerViewController) { onDismiss() }
    }
}

extension View {
    /// Dùng giống `.fileImporter(isPresented:allowedContentTypes:onCompletion:)` nhưng mở bộ chọn file riêng.
    func filePicker(isPresented: Binding<Bool>,
                    types: [UTType],
                    onPick: @escaping (Result<URL, Error>) -> Void) -> some View {
        sheet(isPresented: isPresented) {
            FilePickerSheet(types: types, onPick: onPick, onDismiss: { isPresented.wrappedValue = false })
                .ignoresSafeArea()
        }
    }
}

// MARK: - Chọn từ thư mục "CIT Voice" (cách dự phòng khi bộ chọn file không cho chọn)
// Bước làm: mở app Tệp → Trên iPhone → CIT Voice → dán/chép file nhạc vào đó. Rồi mở danh sách này trong app.

struct AppFolderFile: Identifiable {
    let id: URL
    var url: URL { id }
    var name: String { id.lastPathComponent }
    let size: Int
}

enum AppFolder {
    static let exts: Set<String> = ["mp3", "m4a", "wav", "aac", "caf", "aif", "aiff", "flac", "mp4", "mov", "m4v", "3gp", "opus", "ogg"]

    static var directory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    /// Mọi file trong thư mục tài liệu của app (không lọc đuôi để file không có đuôi vẫn thấy được).
    static func list() -> [AppFolderFile] {
        let fm = FileManager.default
        guard let urls = try? fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.fileSizeKey, .isDirectoryKey],
                                                     options: [.skipsHiddenFiles]) else { return [] }
        return urls.compactMap { u in
            let v = try? u.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey])
            if v?.isDirectory == true { return nil }
            let size = v?.fileSize ?? 0
            // Bỏ file JSON/văn bản của chính app (giọng, phụ đề…).
            let e = u.pathExtension.lowercased()
            if ["json", "srt", "vtt", "txt", "plist"].contains(e) { return nil }
            return AppFolderFile(id: u, size: size)
        }
        .sorted { $0.name.localizedCompare($1.name) == .orderedAscending }
    }
}

struct AppFolderSheet: View {
    var onPick: (URL) -> Void
    var onOther: (() -> Void)? = nil
    @Environment(\.dismiss) private var dismiss
    @State private var files: [AppFolderFile] = []

    var body: some View {
        NavigationStack {
            List {
                if files.isEmpty {
                    Section {
                        Text("Thư mục đang trống.\n\nMở app Tệp → Trên iPhone → thư mục CIT Voice, rồi chép hoặc dán file âm thanh/video vào đó. Quay lại đây và bấm làm mới. Hoặc bấm nút bên dưới để chọn ở nơi khác.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                } else {
                    Section("File trong thư mục CIT Voice") {
                        ForEach(files) { f in
                            Button {
                                dismiss()
                                onPick(f.url)
                            } label: {
                                HStack {
                                    Image(systemName: "waveform").foregroundStyle(.tint)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(f.name).foregroundStyle(.primary).lineLimit(2)
                                        Text(ByteCountFormatter.string(fromByteCount: Int64(f.size), countStyle: .file))
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                if let onOther {
                    Button {
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { onOther() }
                    } label: {
                        Label("Chọn file ở nơi khác (app Tệp)", systemImage: "folder")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(.bar)
                }
            }
            .navigationTitle("Thư mục CIT Voice")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Đóng") { dismiss() } }
                ToolbarItem(placement: .primaryAction) { Button { files = AppFolder.list() } label: { Image(systemName: "arrow.clockwise") } }
            }
            .onAppear { files = AppFolder.list() }
        }
    }
}
