import Foundation

@MainActor
final class AppModel: ObservableObject {
    @Published var text = "Xin chào, đây là bản thử của CIT Voice Studio trên iPhone."
    @Published var selectedVoiceID: String
    @Published var speed: Double = 1.0
    enum Quality: Int, CaseIterable, Identifiable {
        case fast, standard, high, ultra
        var id: Int { rawValue }
        var title: String {
            switch self {
            case .fast: return "Nhanh"
            case .standard: return "Chuẩn"
            case .high: return "Cao"
            case .ultra: return "Rất cao"
            }
        }
        var steps: Int {
            switch self { case .fast: return 8; case .standard: return 16; case .high: return 32; case .ultra: return 48 }
        }
        var sway: Float { self == .fast ? -1 : 0 }
    }
    /// Số bước càng nhiều thì giọng càng mượt, ít "dập"/đứt tiếng nhưng tạo lâu hơn.
    @Published var quality: Quality = .standard
    /// Độ bám theo giọng mẫu/văn bản (classifier-free guidance). Cao quá dễ méo tiếng; thấp quá giọng kém giống.
    @Published var cfgScale: Double = 3.0
    var fastMode: Bool { quality == .fast }
    func synthesisOptions(speed: Float? = nil) -> SynthesisOptions {
        SynthesisOptions(steps: quality.steps, cfg: Float(cfgScale), sway: quality.sway, speed: speed ?? Float(self.speed))
    }
    @Published var isGenerating = false
    @Published var progress: Double = 0
    @Published var usingRealEngine = false   // false: đang phát tiếng bíp thử giao diện
    @Published var errorMessage: String?
    @Published var outputURL: URL?

    @Published var voices: [Voice]
    @Published var isEnrolling = false       // đang mã hoá giọng mẫu (nhân bản giọng)
    private let customStore = CustomVoiceStore()
    private var nano: NanoEngine?
    private var task: Task<Void, Never>?

    init() {
        let lib = VoiceLibrary.load()
        let customs = CustomVoiceStore().load()
        voices = Self.sorted(lib.voices + customs)
        selectedVoiceID = lib.defaultID.isEmpty ? (lib.voices.first?.id ?? "") : lib.defaultID
    }

    private static func sorted(_ list: [Voice]) -> [Voice] {
        list.sorted { $0.id.localizedCompare($1.id) == .orderedAscending }
    }

    // MARK: - Nhân bản giọng

    /// Mã hoá giọng mẫu → thêm một giọng mới (lưu bền) và chọn luôn giọng đó. `completion(true)` nếu thành công.
    func enrollVoice(from url: URL, name: String, store: ModelStore, denoise: Bool = false, completion: @escaping (Bool) -> Void) {
        guard !isEnrolling else { return }
        isEnrolling = true
        Task {
            defer { isEnrolling = false }
            do {
                let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !clean.isEmpty else { throw TTSError.clone("Hãy đặt tên cho giọng.") }
                guard !voices.contains(where: { $0.id == clean }) else {
                    throw TTSError.clone("Đã có giọng tên \"\(clean)\". Hãy chọn tên khác.")
                }
                guard store.state == .ready else { throw TTSError.clone("Cần tải model v3 Nano trước.") }
                guard store.cloneState == .ready else { throw TTSError.clone("Cần tải model nhân bản giọng trước.") }
                try await store.ensureClonePatched()
                let dir = store.directory
                let result = try await Task.detached(priority: .userInitiated) { () throws -> (spk: [Float], style: [[Float]]) in
                    let clip = try ReferenceAudio.load(url: url)
                    let cloner = try VoiceCloner(directory: dir)
                    return try cloner.enroll(clip: clip, denoise: denoise)
                }.value
                let voice = Voice(id: clean, description: "Giọng nhân bản", gender: "",
                                  speakerEmb: result.spk, style: result.style, isCustom: true)
                try customStore.add(voice)
                voices = Self.sorted(voices + [voice])
                selectedVoiceID = clean
                completion(true)
            } catch {
                errorMessage = error.localizedDescription
                completion(false)
            }
        }
    }

    func removeCustomVoice(_ voice: Voice) {
        guard voice.isCustom else { return }
        do {
            try customStore.remove(id: voice.id)
            voices.removeAll { $0.id == voice.id }
            if selectedVoiceID == voice.id { selectedVoiceID = voices.first?.id ?? "" }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    /// Engine dùng chung (giọng thật nếu đã cài model + g2p, ngược lại tiếng bíp thử giao diện).
    func makeEngine(store: ModelStore) async throws -> (engine: any SpeechEngine, real: Bool) {
        if store.state == .ready && G2PFactory.isAvailable {
            try await store.ensurePatched()
            if nano == nil { nano = try NanoEngine(directory: store.directory, g2p: try G2PFactory.make()) }
            return (nano!, true)
        }
        return (PlaceholderEngine(), false)
    }

    /// Bỏ engine đang giữ trong bộ nhớ (sau khi khôi phục model từ bản sao lưu).
    func resetEngine() { nano = nil }

    // MARK: - Nhập / xuất giọng

    /// Ghi các giọng đã nhân bản ra file JSON (cùng định dạng voices_v3_nano.json). nil nếu chưa có giọng nào.
    func exportCustomVoicesFile() throws -> URL? {
        let custom = voices.filter { $0.isCustom }
        guard !custom.isEmpty else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("CIT-Voice-giong-noi.json")
        try VoiceFileIO.encode(custom).write(to: url, options: .atomic)
        return url
    }

    /// Nhập giọng từ file JSON. Trả về số giọng đã thêm; tên trùng sẽ được thêm hậu tố.
    func importVoices(from url: URL) throws -> Int {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let incoming = try VoiceFileIO.decode(try Data(contentsOf: url))
        var added: [Voice] = []
        for v in incoming {
            var name = v.id
            var n = 2
            while voices.contains(where: { $0.id == name }) || added.contains(where: { $0.id == name }) {
                name = "\(v.id) (\(n))"; n += 1
            }
            let voice = Voice(id: name, description: "Giọng nhập từ file", gender: v.gender,
                              speakerEmb: v.speakerEmb, style: v.style, isCustom: true)
            try customStore.add(voice)
            added.append(voice)
        }
        voices = Self.sorted(voices + added)
        if let first = added.first { selectedVoiceID = first.id }
        return added.count
    }

    func cancel() { task?.cancel() }

    func generate(player: AudioPlayer, store: ModelStore) {
        guard !isGenerating else { return }
        isGenerating = true
        progress = 0
        task = Task {
            defer { isGenerating = false; task = nil }
            do {
                let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !trimmed.isEmpty else { throw TTSError.emptyText }
                guard let voice = voices.first(where: { $0.id == selectedVoiceID }) else { throw TTSError.voiceMissing }
                let opts = synthesisOptions()

                let engine: any SpeechEngine
                if store.state == .ready && G2PFactory.isAvailable {
                    try await store.ensurePatched()
                    if nano == nil { nano = try NanoEngine(directory: store.directory, g2p: try G2PFactory.make()) }
                    engine = nano!
                    usingRealEngine = true
                } else {
                    engine = PlaceholderEngine()
                    usingRealEngine = false
                }

                let samples = try await engine.synthesize(text: trimmed, voice: voice, options: opts) { [weak self] p in
                    Task { @MainActor in self?.progress = p }
                }
                let data = WAV.encode(samples: samples, sampleRate: engine.sampleRate)
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("cit-voice-\(Int(Date().timeIntervalSince1970)).wav")
                try data.write(to: url)
                outputURL = url
                try player.play(url: url)
            } catch is CancellationError {
                // người dùng bấm Huỷ
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
