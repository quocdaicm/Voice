import Foundation

@MainActor
final class AppModel: ObservableObject {
    @Published var text = "Xin chào, đây là bản thử của CIT Voice Studio trên iPhone."
    @Published var selectedVoiceID: String
    @Published var speed: Double = 1.0 { didSet { UserDefaults.standard.set(speed, forKey: "pacing.speed") } }
    /// Khoảng nghỉ giữa đoạn / câu / dấu phẩy (giây). Thuyết minh nên đặt dài và đều hơn mặc định.
    @Published var pauses: PauseProfile = .standard {
        didSet { if let d = try? JSONEncoder().encode(pauses) { UserDefaults.standard.set(d, forKey: "pacing.pauses") } }
    }
    @Published var pacingPreset: PacingPreset = .standard {
        didSet { UserDefaults.standard.set(pacingPreset.rawValue, forKey: "pacing.preset") }
    }
    /// Chọn bộ cài sẵn: đặt cả tốc độ và ngắt nghỉ (sau đó vẫn chỉnh tiếp được).
    func applyPreset(_ p: PacingPreset) {
        pacingPreset = p
        speed = p.speed
        pauses = p.pauses
    }
    @Published var statusText = ""            // vd. "Đoạn 2/5" khi đọc nhiều đoạn
    let history = HistoryStore()
    enum Quality: Int, CaseIterable, Identifiable {
        case fast, standard, high, ultra
        var id: Int { rawValue }
        var title: String {
            switch self {
            case .fast: return "Nhanh"
            case .standard: return "Chuẩn"
            case .high: return "Cao"
            case .ultra: return "Rất cao"
            }
        }
        var steps: Int {
            switch self { case .fast: return 8; case .standard: return 16; case .high: return 32; case .ultra: return 48 }
        }
        var sway: Float { self == .fast ? -1 : 0 }
    }
    /// Số bước càng nhiều thì giọng càng mượt, ít "dập"/đứt tiếng nhưng tạo lâu hơn.
    @Published var quality: Quality = .standard
    /// Độ bám theo giọng mẫu/văn bản (classifier-free guidance). Cao quá dễ méo tiếng; thấp quá giọng kém giống.
    @Published var cfgScale: Double = 3.0
    var fastMode: Bool { quality == .fast }
    func synthesisOptions(speed: Float? = nil) -> SynthesisOptions {
        SynthesisOptions(steps: quality.steps, cfg: Float(cfgScale), sway: quality.sway, speed: speed ?? Float(self.speed),
                         pauses: pauses)
    }
    @Published var isGenerating = false
    @Published var progress: Double = 0
    @Published var usingRealEngine = false   // false: đang phát tiếng bíp thử giao diện
    @Published var errorMessage: String?
    @Published var outputURL: URL?
    @Published var lastTimings: [SpeechTiming] = []   // mốc từng đoạn của bản vừa tạo (dùng cho video karaoke)

    @Published var voices: [Voice]
    @Published var isEnrolling = false       // đang mã hoá giọng mẫu (nhân bản giọng)
    private let customStore = CustomVoiceStore()
    private var nano: NanoEngine?
    private var stEngine: SupertonicEngine?
    let supertonic = SupertonicStore()
    private var task: Task<Void, Never>?

    init() {
        let lib = VoiceLibrary.load()
        let customs = CustomVoiceStore().load()
        voices = Self.sorted(lib.voices + customs)
        selectedVoiceID = lib.defaultID.isEmpty ? (lib.voices.first?.id ?? "") : lib.defaultID
        // khôi phục tốc độ / ngắt nghỉ đã chỉnh lần trước
        let ud = UserDefaults.standard
        if ud.object(forKey: "pacing.speed") != nil { speed = min(1.5, max(0.5, ud.double(forKey: "pacing.speed"))) }
        if let d = ud.data(forKey: "pacing.pauses"), let p = try? JSONDecoder().decode(PauseProfile.self, from: d) { pauses = p }
        if ud.object(forKey: "pacing.preset") != nil, let p = PacingPreset(rawValue: ud.integer(forKey: "pacing.preset")) { pacingPreset = p }
        supertonic.onChange = { [weak self] in self?.syncSupertonicVoices() }
        syncSupertonicVoices()
    }

    /// Thêm / bớt các giọng Supertonic-3 theo việc model đã cài hay chưa.
    func syncSupertonicVoices() {
        let base = voices.filter { $0.engine != "supertonic" }
        voices = Self.sorted(base + supertonic.availableVoices)
        if !voices.contains(where: { $0.id == selectedVoiceID }) { selectedVoiceID = voices.first?.id ?? "" }
        if supertonic.state != .ready { stEngine = nil }
    }

    // MARK: - Văn bản dài

    /// Tách thành các đoạn theo dòng (bỏ dòng trống). Mỗi đoạn được tạo riêng nên hiện được tiến độ và huỷ giữa chừng vẫn giữ phần đã xong.
    nonisolated static func paragraphs(of text: String) -> [String] {
        text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    static let maxImportedChars = 200_000

    /// Mở file .txt (UTF-8, hoặc UTF-16 nếu có BOM) vào ô văn bản.
    func importText(from url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url),
              var s = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .utf16) else {
            errorMessage = "Không đọc được file văn bản này (cần .txt mã hoá UTF-8)."
            return
        }
        if s.hasPrefix("\u{FEFF}") { s.removeFirst() }
        if s.count > Self.maxImportedChars {
            s = String(s.prefix(Self.maxImportedChars))
            errorMessage = "File dài quá nên chỉ lấy \(Self.maxImportedChars) ký tự đầu. Hãy tách thành nhiều file."
        }
        text = s
    }

    private static func sorted(_ list: [Voice]) -> [Voice] {
        list.sorted { $0.id.localizedCompare($1.id) == .orderedAscending }
    }

    // MARK: - Nhân bản giọng

    /// Mã hoá giọng mẫu → thêm một giọng mới (lưu bền) và chọn luôn giọng đó. `completion(true)` nếu thành công.
    func enrollVoice(from url: URL, name: String, store: ModelStore, denoise: Bool = false, completion: @escaping (Bool) -> Void) {
        guard !isEnrolling else { return }
        isEnrolling = true
        Task {
            defer { isEnrolling = false }
            do {
                let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !clean.isEmpty else { throw TTSError.clone("Hãy đặt tên cho giọng.") }
                guard !voices.contains(where: { $0.id == clean }) else {
                    throw TTSError.clone("Đã có giọng tên \"\(clean)\". Hãy chọn tên khác.")
                }
                guard store.state == .ready else { throw TTSError.clone("Cần tải model v3 Nano trước.") }
                guard store.cloneState == .ready else { throw TTSError.clone("Cần tải model nhân bản giọng trước.") }
                try await store.ensureClonePatched()
                let dir = store.directory
                let result = try await Task.detached(priority: .userInitiated) { () throws -> (spk: [Float], style: [[Float]]) in
                    let clip = try ReferenceAudio.load(url: url)
                    let cloner = try VoiceCloner(directory: dir)
                    return try cloner.enroll(clip: clip, denoise: denoise)
                }.value
                let voice = Voice(id: clean, description: "Giọng nhân bản", gender: "",
                                  speakerEmb: result.spk, style: result.style, isCustom: true)
                try customStore.add(voice)
                voices = Self.sorted(voices + [voice])
                selectedVoiceID = clean
                completion(true)
            } catch {
                errorMessage = error.localizedDescription
                completion(false)
            }
        }
    }

    func removeCustomVoice(_ voice: Voice) {
        guard voice.isCustom else { return }
        do {
            try customStore.remove(id: voice.id)
            voices.removeAll { $0.id == voice.id }
            if selectedVoiceID == voice.id { selectedVoiceID = voices.first?.id ?? "" }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    /// Engine dùng chung: tự chọn VieNeu hoặc Supertonic-3 theo giọng đang chọn (ngoài ra: tiếng bíp thử giao diện).
    func makeEngine(store: ModelStore) async throws -> (engine: any SpeechEngine, real: Bool) {
        var nanoEngine: (any SpeechEngine)?
        if store.state == .ready && G2PFactory.isAvailable {
            try await store.ensurePatched()
            if nano == nil { nano = try NanoEngine(directory: store.directory, g2p: try G2PFactory.make()) }
            nanoEngine = nano
        }
        let wantsSupertonic = voices.first(where: { $0.id == selectedVoiceID })?.engine == "supertonic"
        var stSpeech: (any SpeechEngine)?
        if wantsSupertonic && supertonic.state == .ready {
            if stEngine == nil { stEngine = try SupertonicEngine(directory: supertonic.directory) }
            stSpeech = stEngine
        }
        if nanoEngine == nil && stSpeech == nil { return (PlaceholderEngine(), false) }
        let router = RouterEngine(nano: nanoEngine ?? PlaceholderEngine(), supertonic: stSpeech)
        return (router, wantsSupertonic ? stSpeech != nil : nanoEngine != nil)
    }

    /// Bỏ engine đang giữ trong bộ nhớ (sau khi khôi phục model từ bản sao lưu).
    func resetEngine() { nano = nil; stEngine = nil }

    // MARK: - Nhập / xuất giọng

    /// Ghi các giọng đã nhân bản ra file JSON (cùng định dạng voices_v3_nano.json). nil nếu chưa có giọng nào.
    func exportCustomVoicesFile() throws -> URL? {
        let custom = voices.filter { $0.isCustom }
        guard !custom.isEmpty else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("CIT-Voice-giong-noi.json")
        try VoiceFileIO.encode(custom).write(to: url, options: .atomic)
        return url
    }

    /// Nhập giọng từ file JSON. Trả về số giọng đã thêm; tên trùng sẽ được thêm hậu tố.
    func importVoices(from url: URL) throws -> Int {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let incoming = try VoiceFileIO.decode(try Data(contentsOf: url))
        var added: [Voice] = []
        for v in incoming {
            var name = v.id
            var n = 2
            while voices.contains(where: { $0.id == name }) || added.contains(where: { $0.id == name }) {
                name = "\(v.id) (\(n))"; n += 1
            }
            let voice = Voice(id: name, description: "Giọng nhập từ file", gender: v.gender,
                              speakerEmb: v.speakerEmb, style: v.style, isCustom: true)
            try customStore.add(voice)
            added.append(voice)
        }
        voices = Self.sorted(voices + added)
        if let first = added.first { selectedVoiceID = first.id }
        return added.count
    }

    func cancel() { task?.cancel() }

    func generate(player: AudioPlayer, store: ModelStore) {
        guard !isGenerating else { return }
        isGenerating = true
        progress = 0
        statusText = ""
        lastTimings = []
        task = Task {
            defer { isGenerating = false; task = nil; statusText = "" }
            do {
                let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !trimmed.isEmpty else { throw TTSError.emptyText }
                guard let voice = voices.first(where: { $0.id == selectedVoiceID }) else { throw TTSError.voiceMissing }
                var opts = synthesisOptions()
                opts.normalize = false            // chuẩn hoá âm lượng một lần cho cả bản, không theo từng đoạn
                let usedSpeed = speed
                let gapSeconds = pauses.paragraph

                let (engine, real) = try await makeEngine(store: store)
                usingRealEngine = real

                let paragraphs = Self.paragraphs(of: trimmed)
                let n = max(1, paragraphs.count)
                var out: [Float] = []
                var timings: [SpeechTiming] = []
                var cancelled = false
                for (i, para) in paragraphs.enumerated() {
                    if Task.isCancelled { cancelled = true; break }
                    statusText = n > 1 ? "Đoạn \(i + 1)/\(n)" : ""
                    do {
                        let samples = try await engine.synthesize(text: para, voice: voice, options: opts) { [weak self] p in
                            Task { @MainActor in self?.progress = (Double(i) + p) / Double(n) }
                        }
                        if samples.isEmpty { continue }
                        if !out.isEmpty { out += [Float](repeating: 0, count: Int(gapSeconds * Double(engine.sampleRate))) }
                        let rate = Double(engine.sampleRate)
                        timings.append(SpeechTiming(text: para, start: Double(out.count) / rate,
                                                    end: Double(out.count + samples.count) / rate))
                        out += samples
                    } catch is CancellationError {
                        cancelled = true
                        break
                    }
                }
                guard !out.isEmpty else {
                    if cancelled { return }          // huỷ khi chưa có gì
                    throw TTSError.emptyText
                }
                if usingRealEngine { out = AudioUtils.normalizeLoudness(out) }

                let data = WAV.encode(samples: out, sampleRate: engine.sampleRate)
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("cit-voice-\(Int(Date().timeIntervalSince1970)).wav")
                try data.write(to: url)
                outputURL = url
                lastTimings = timings
                history.add(wav: url, text: trimmed, voice: voice.id, speed: usedSpeed,
                            seconds: Double(out.count) / Double(engine.sampleRate), partial: cancelled)
                try player.play(url: url)
            } catch is CancellationError {
                // người dùng bấm Huỷ
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
