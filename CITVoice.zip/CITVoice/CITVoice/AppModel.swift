import Foundation

@MainActor
final class AppModel: ObservableObject {
    @Published var text = "Xin chào, đây là bản thử của CIT Voice Studio trên iPhone."
    @Published var selectedVoiceID: String
    @Published var speed: Double = 1.0
    @Published var fastMode = false          // true: steps=8, sway=-1 (nhanh hơn, giọng kém hơn một chút)
    @Published var isGenerating = false
    @Published var progress: Double = 0
    @Published var usingRealEngine = false   // false: đang phát tiếng bíp thử giao diện
    @Published var errorMessage: String?
    @Published var outputURL: URL?

    let voices: [Voice]
    private var nano: NanoEngine?
    private var task: Task<Void, Never>?

    init() {
        let lib = VoiceLibrary.load()
        voices = lib.voices
        selectedVoiceID = lib.defaultID.isEmpty ? (lib.voices.first?.id ?? "") : lib.defaultID
    }

    func cancel() { task?.cancel() }

    func generate(player: AudioPlayer, store: ModelStore) {
        guard !isGenerating else { return }
        isGenerating = true
        progress = 0
        task = Task {
            defer { isGenerating = false; task = nil }
            do {
                let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !trimmed.isEmpty else { throw TTSError.emptyText }
                guard let voice = voices.first(where: { $0.id == selectedVoiceID }) else { throw TTSError.voiceMissing }
                let opts = SynthesisOptions(steps: fastMode ? 8 : 16, cfg: 3.0,
                                            sway: fastMode ? -1 : 0, speed: Float(speed))

                let engine: any SpeechEngine
                if store.state == .ready && G2PFactory.isAvailable {
                    try await store.ensurePatched()
                    if nano == nil { nano = try NanoEngine(directory: store.directory, g2p: try G2PFactory.make()) }
                    engine = nano!
                    usingRealEngine = true
                } else {
                    engine = PlaceholderEngine()
                    usingRealEngine = false
                }

                let samples = try await engine.synthesize(text: trimmed, voice: voice, options: opts) { [weak self] p in
                    Task { @MainActor in self?.progress = p }
                }
                let data = WAV.encode(samples: samples, sampleRate: engine.sampleRate)
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("cit-voice-\(Int(Date().timeIntervalSince1970)).wav")
                try data.write(to: url)
                outputURL = url
                try player.play(url: url)
            } catch is CancellationError {
                // người dùng bấm Huỷ
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
