import Foundation

@MainActor
final class AppModel: ObservableObject {
    @Published var text = "Xin chào, đây là bản thử của CIT Voice Studio trên iPhone."
    @Published var selectedVoiceID: String
    @Published var speed: Double = 1.0
    @Published var fastMode = false          // true: steps=8, sway=-1 (nhanh hơn, giọng kém hơn một chút)
    @Published var isGenerating = false
    @Published var progress: Double = 0
    @Published var usingRealEngine = false   // false: đang phát tiếng bíp thử giao diện
    @Published var errorMessage: String?
    @Published var outputURL: URL?

    @Published var voices: [Voice]
    @Published var isEnrolling = false       // đang mã hoá giọng mẫu (nhân bản giọng)
    private let customStore = CustomVoiceStore()
    private var nano: NanoEngine?
    private var task: Task<Void, Never>?

    init() {
        let lib = VoiceLibrary.load()
        let customs = CustomVoiceStore().load()
        voices = Self.sorted(lib.voices + customs)
        selectedVoiceID = lib.defaultID.isEmpty ? (lib.voices.first?.id ?? "") : lib.defaultID
    }

    private static func sorted(_ list: [Voice]) -> [Voice] {
        list.sorted { $0.id.localizedCompare($1.id) == .orderedAscending }
    }

    // MARK: - Nhân bản giọng

    /// Mã hoá giọng mẫu → thêm một giọng mới (lưu bền) và chọn luôn giọng đó. `completion(true)` nếu thành công.
    func enrollVoice(from url: URL, name: String, store: ModelStore, completion: @escaping (Bool) -> Void) {
        guard !isEnrolling else { return }
        isEnrolling = true
        Task {
            defer { isEnrolling = false }
            do {
                let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !clean.isEmpty else { throw TTSError.clone("Hãy đặt tên cho giọng.") }
                guard !voices.contains(where: { $0.id == clean }) else {
                    throw TTSError.clone("Đã có giọng tên \"\(clean)\". Hãy chọn tên khác.")
                }
                guard store.state == .ready else { throw TTSError.clone("Cần tải model v3 Nano trước.") }
                guard store.cloneState == .ready else { throw TTSError.clone("Cần tải model nhân bản giọng trước.") }
                try await store.ensureClonePatched()
                let dir = store.directory
                let result = try await Task.detached(priority: .userInitiated) { () throws -> (spk: [Float], style: [[Float]]) in
                    let clip = try ReferenceAudio.load(url: url)
                    let cloner = try VoiceCloner(directory: dir)
                    return try cloner.enroll(clip: clip)
                }.value
                let voice = Voice(id: clean, description: "Giọng nhân bản", gender: "",
                                  speakerEmb: result.spk, style: result.style, isCustom: true)
                try customStore.add(voice)
                voices = Self.sorted(voices + [voice])
                selectedVoiceID = clean
                completion(true)
            } catch {
                errorMessage = error.localizedDescription
                completion(false)
            }
        }
    }

    func removeCustomVoice(_ voice: Voice) {
        guard voice.isCustom else { return }
        do {
            try customStore.remove(id: voice.id)
            voices.removeAll { $0.id == voice.id }
            if selectedVoiceID == voice.id { selectedVoiceID = voices.first?.id ?? "" }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    /// Engine dùng chung (giọng thật nếu đã cài model + g2p, ngược lại tiếng bíp thử giao diện).
    func makeEngine(store: ModelStore) async throws -> (engine: any SpeechEngine, real: Bool) {
        if store.state == .ready && G2PFactory.isAvailable {
            try await store.ensurePatched()
            if nano == nil { nano = try NanoEngine(directory: store.directory, g2p: try G2PFactory.make()) }
            return (nano!, true)
        }
        return (PlaceholderEngine(), false)
    }

    func cancel() { task?.cancel() }

    func generate(player: AudioPlayer, store: ModelStore) {
        guard !isGenerating else { return }
        isGenerating = true
        progress = 0
        task = Task {
            defer { isGenerating = false; task = nil }
            do {
                let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !trimmed.isEmpty else { throw TTSError.emptyText }
                guard let voice = voices.first(where: { $0.id == selectedVoiceID }) else { throw TTSError.voiceMissing }
                let opts = SynthesisOptions(steps: fastMode ? 8 : 16, cfg: 3.0,
                                            sway: fastMode ? -1 : 0, speed: Float(speed))

                let engine: any SpeechEngine
                if store.state == .ready && G2PFactory.isAvailable {
                    try await store.ensurePatched()
                    if nano == nil { nano = try NanoEngine(directory: store.directory, g2p: try G2PFactory.make()) }
                    engine = nano!
                    usingRealEngine = true
                } else {
                    engine = PlaceholderEngine()
                    usingRealEngine = false
                }

                let samples = try await engine.synthesize(text: trimmed, voice: voice, options: opts) { [weak self] p in
                    Task { @MainActor in self?.progress = p }
                }
                let data = WAV.encode(samples: samples, sampleRate: engine.sampleRate)
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("cit-voice-\(Int(Date().timeIntervalSince1970)).wav")
                try data.write(to: url)
                outputURL = url
                try player.play(url: url)
            } catch is CancellationError {
                // người dùng bấm Huỷ
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
