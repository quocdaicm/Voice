import Foundation
import Compression

/// Bộ đọc tối thiểu cho file .npz (zip chứa các .npy) của numpy: hỗ trợ stored/deflate, ZIP64, dtype f4/f8.
enum NPZ {
    struct Array32 { let shape: [Int]; let data: [Float] }
    enum NPZError: LocalizedError {
        case bad(String)
        var errorDescription: String? { if case .bad(let m) = self { return "Lỗi đọc constants.npz: \(m)" }; return nil }
    }

    static func load(url: URL) throws -> [String: Array32] {
        let d = try Data(contentsOf: url, options: .mappedIfSafe)
        func u16(_ o: Int) -> Int { Int(d[o]) | Int(d[o + 1]) << 8 }
        func u32(_ o: Int) -> Int { u16(o) | u16(o + 2) << 16 }
        func u64(_ o: Int) -> Int { u32(o) | u32(o + 4) << 32 }

        // Tìm End Of Central Directory (0x06054b50) từ cuối file.
        var eocd = -1
        var i = d.count - 22
        while i >= max(0, d.count - 70_000) {
            if u32(i) == 0x06054b50 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { throw NPZError.bad("không thấy EOCD") }
        let count = u16(eocd + 10)
        var p = u32(eocd + 16)
        var out: [String: Array32] = [:]

        for _ in 0..<count {
            guard u32(p) == 0x02014b50 else { throw NPZError.bad("central directory hỏng") }
            let method = u16(p + 10)
            var csize = u32(p + 20), usize = u32(p + 24)
            let nameLen = u16(p + 28), extraLen = u16(p + 30), commentLen = u16(p + 32)
            var localOff = u32(p + 42)
            let name = String(decoding: d[(p + 46)..<(p + 46 + nameLen)], as: UTF8.self)
            // ZIP64 extra (id 0x0001): lần lượt usize, csize, offset cho các trường = 0xFFFFFFFF
            var e = p + 46 + nameLen
            let eEnd = e + extraLen
            while e + 4 <= eEnd {
                let id = u16(e), sz = u16(e + 2)
                if id == 0x0001 {
                    var q = e + 4
                    if usize == 0xFFFFFFFF { usize = u64(q); q += 8 }
                    if csize == 0xFFFFFFFF { csize = u64(q); q += 8 }
                    if localOff == 0xFFFFFFFF { localOff = u64(q); q += 8 }
                }
                e += 4 + sz
            }
            p += 46 + nameLen + extraLen + commentLen

            guard u32(localOff) == 0x04034b50 else { throw NPZError.bad("local header hỏng") }
            let dataStart = localOff + 30 + u16(localOff + 26) + u16(localOff + 28)
            let raw = d.subdata(in: dataStart..<(dataStart + csize))
            let npy: Data
            switch method {
            case 0: npy = raw
            case 8: npy = try inflate(raw, expected: usize)
            default: throw NPZError.bad("kiểu nén \(method) chưa hỗ trợ")
            }
            let key = name.hasSuffix(".npy") ? String(name.dropLast(4)) : name
            out[key] = try parseNPY(npy)
        }
        return out
    }

    private static func inflate(_ raw: Data, expected: Int) throws -> Data {
        var dst = Data(count: max(expected, 1))
        let n = dst.withUnsafeMutableBytes { dp in
            raw.withUnsafeBytes { sp in
                compression_decode_buffer(dp.bindMemory(to: UInt8.self).baseAddress!, dp.count,
                                          sp.bindMemory(to: UInt8.self).baseAddress!, sp.count,
                                          nil, COMPRESSION_ZLIB)
            }
        }
        guard n == expected else { throw NPZError.bad("giải nén sai kích thước") }
        return dst
    }

    private static func parseNPY(_ d: Data) throws -> Array32 {
        guard d.count > 10, d[0] == 0x93, String(decoding: d[1..<6], as: UTF8.self) == "NUMPY" else {
            throw NPZError.bad("không phải .npy")
        }
        let major = Int(d[6])
        let hlen = major == 1 ? Int(d[8]) | Int(d[9]) << 8
                              : Int(d[8]) | Int(d[9]) << 8 | Int(d[10]) << 16 | Int(d[11]) << 24
        let hStart = major == 1 ? 10 : 12
        let header = String(decoding: d[hStart..<(hStart + hlen)], as: UTF8.self)
        let body = d.subdata(in: (hStart + hlen)..<d.count)

        let descr = firstMatch(#"'descr':\s*'([^']+)'"#, in: header) ?? ""
        let shapeStr = firstMatch(#"'shape':\s*\(([^)]*)\)"#, in: header) ?? ""
        let shape = shapeStr.split(separator: ",").compactMap { Int($0.trimmingCharacters(in: .whitespaces)) }
        if header.contains("'fortran_order': True") { throw NPZError.bad("fortran_order chưa hỗ trợ") }
        let total = shape.reduce(1, *)

        var values = [Float](repeating: 0, count: total)
        switch descr {
        case "<f4", "=f4":
            guard body.count >= total * 4 else { throw NPZError.bad("thiếu dữ liệu f4") }
            body.withUnsafeBytes { raw in
                for i in 0..<total { values[i] = Float(bitPattern: raw.loadUnaligned(fromByteOffset: i * 4, as: UInt32.self).littleEndian) }
            }
        case "<f8", "=f8":
            guard body.count >= total * 8 else { throw NPZError.bad("thiếu dữ liệu f8") }
            body.withUnsafeBytes { raw in
                for i in 0..<total { values[i] = Float(Double(bitPattern: raw.loadUnaligned(fromByteOffset: i * 8, as: UInt64.self).littleEndian)) }
            }
        default:
            throw NPZError.bad("dtype \(descr) chưa hỗ trợ")
        }
        return Array32(shape: shape, data: values)
    }

    private static func firstMatch(_ pattern: String, in s: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: pattern),
              let m = re.firstMatch(in: s, range: NSRange(location: 0, length: (s as NSString).length)),
              m.numberOfRanges > 1 else { return nil }
        return (s as NSString).substring(with: m.range(at: 1))
    }
}
