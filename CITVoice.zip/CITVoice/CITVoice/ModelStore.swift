import Foundation

/// Tải và quản lý file model v3 Nano trong Application Support.
/// Nguồn: https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Nano (danh sách file lấy từ `_GRAPH_FILES` trong v3nano.py).
/// Model nhân bản giọng (`_CLONE_FILES`, ~100 MB) tải riêng, chỉ khi người dùng cần.
@MainActor
final class ModelStore: ObservableObject {
    enum State: Equatable {
        case notInstalled
        case downloading
        case ready
        case failed(String)
    }

    static let repo = "pnnbao-ump/VieNeu-TTS-v3-Nano"
    static let files = [
        "config.json", "constants.npz",
        "text_encoder.onnx", "duration_predictor.onnx",
        "vector_estimator.onnx", "codec_decoder.onnx",
    ]
    /// Nhân bản giọng (giai đoạn 4). `denoiser.onnx` là tuỳ chọn, chưa dùng.
    static let cloneFiles = ["speaker_encoder.onnx", "codec_encoder.onnx", "reference_encoder.onnx"]

    @Published var state: State = .notInstalled
    @Published var fileProgress: Double = 0
    @Published var statusText = ""

    @Published var cloneState: State = .notInstalled
    @Published var cloneProgress: Double = 0
    @Published var cloneStatusText = ""

    let directory: URL

    init() {
        var dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Models/VieNeuNano", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var rv = URLResourceValues()
        rv.isExcludedFromBackup = true            // model lớn, không cần backup iCloud
        try? dir.setResourceValues(rv)
        directory = dir
        state = Self.allFilesPresent(Self.files, in: dir) ? .ready : .notInstalled
        cloneState = Self.allFilesPresent(Self.cloneFiles, in: dir) ? .ready : .notInstalled
    }

    static func allFilesPresent(_ names: [String], in dir: URL) -> Bool {
        names.allSatisfy { FileManager.default.fileExists(atPath: dir.appendingPathComponent($0).path) }
    }

    /// Tải lần lượt các file còn thiếu; `onStatus(văn bản, tiến độ file hiện tại)` được gọi trên luồng chính.
    private func fetch(_ names: [String], onStatus: @escaping @Sendable (String, Double) -> Void) async throws {
        for (i, name) in names.enumerated() {
            let dest = directory.appendingPathComponent(name)
            if FileManager.default.fileExists(atPath: dest.path) { continue }
            let count = names.count
            onStatus("(\(i + 1)/\(count)) \(name)", 0)
            let url = URL(string: "https://huggingface.co/\(Self.repo)/resolve/main/\(name)")!
            let dl = FileDownloader(destination: dest) { written, total in
                let mb = Double(written) / 1_048_576
                if total > 0 {
                    onStatus(String(format: "(%d/%d) %@ — %.0f / %.0f MB", i + 1, count, name, mb, Double(total) / 1_048_576),
                             Double(written) / Double(total))
                } else {
                    onStatus(String(format: "(%d/%d) %@ — %.0f MB", i + 1, count, name, mb), 0)
                }
            }
            try await dl.start(url: url)
        }
    }

    func download() async {
        guard state != .downloading else { return }
        state = .downloading
        do {
            try await fetch(Self.files) { [weak self] text, frac in
                Task { @MainActor in self?.statusText = text; self?.fileProgress = frac }
            }
            state = Self.allFilesPresent(Self.files, in: directory) ? .ready : .notInstalled
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func downloadClone() async {
        guard cloneState != .downloading else { return }
        cloneState = .downloading
        do {
            try await fetch(Self.cloneFiles) { [weak self] text, frac in
                Task { @MainActor in self?.cloneStatusText = text; self?.cloneProgress = frac }
            }
            cloneState = Self.allFilesPresent(Self.cloneFiles, in: directory) ? .ready : .notInstalled
        } catch {
            cloneState = .failed(error.localizedDescription)
        }
    }

    /// Vá `ctx_mask` (bool → uint8 + Cast) cho ONNX Runtime iOS. Chạy một lần sau khi tải; có file đánh dấu.
    func ensurePatched() async throws {
        let marker = directory.appendingPathComponent(".bool-patched")
        if FileManager.default.fileExists(atPath: marker.path) { return }
        let dir = directory
        try await Task.detached(priority: .userInitiated) {
            for f in ["duration_predictor.onnx", "vector_estimator.onnx"] {
                try OnnxBoolPatch.patchFile(at: dir.appendingPathComponent(f))
            }
            try Data().write(to: marker)
        }.value
    }

    /// Vá `ref_mask` (bool) của reference_encoder.onnx, cùng cách với `ctx_mask`.
    func ensureClonePatched() async throws {
        let marker = directory.appendingPathComponent(".clone-patched")
        if FileManager.default.fileExists(atPath: marker.path) { return }
        let dir = directory
        try await Task.detached(priority: .userInitiated) {
            try OnnxBoolPatch.patchFile(at: dir.appendingPathComponent("reference_encoder.onnx"), input: "ref_mask")
            try Data().write(to: marker)
        }.value
    }

    func deleteModel() {
        try? FileManager.default.removeItem(at: directory)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        state = .notInstalled
        cloneState = .notInstalled
    }
}

/// Tải một file qua URLSession delegate để có tiến độ; chỉ ghi vào `destination` khi tải xong.
final class FileDownloader: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    private let destination: URL
    private let onProgress: @Sendable (Int64, Int64) -> Void
    private var continuation: CheckedContinuation<Void, Error>?
    private var session: URLSession?

    init(destination: URL, onProgress: @escaping @Sendable (Int64, Int64) -> Void) {
        self.destination = destination
        self.onProgress = onProgress
    }

    func start(url: URL) async throws {
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            continuation = c
            let s = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
            session = s
            s.downloadTask(with: url).resume()
        }
    }

    private func finish(_ result: Result<Void, Error>) {
        guard let c = continuation else { return }
        continuation = nil
        session?.finishTasksAndInvalidate()
        c.resume(with: result)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        onProgress(totalBytesWritten, totalBytesExpectedToWrite)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        do {
            if let http = downloadTask.response as? HTTPURLResponse, http.statusCode != 200 {
                throw NSError(domain: "ModelDownload", code: http.statusCode,
                              userInfo: [NSLocalizedDescriptionKey: "Máy chủ trả về mã \(http.statusCode) khi tải \(destination.lastPathComponent)"])
            }
            try? FileManager.default.removeItem(at: destination)
            try FileManager.default.moveItem(at: location, to: destination)
            finish(.success(()))
        } catch {
            finish(.failure(error))
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error { finish(.failure(error)) }
    }
}
