import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var store = ModelStore()
    @StateObject private var player = AudioPlayer()
    @StateObject private var model = AppModel()
    @FocusState private var textFocused: Bool
    @State private var importingText = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    HeroBanner()
                    modelCard
                    SupertonicCard(store: model.supertonic)
                    textCard
                    voiceCard
                    optionsCard
                    KaraokeSceneCard(model: model)
                    BackupCard(store: store, model: model)
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 24)
            }
            .scrollDismissesKeyboard(.immediately)
            .dismissKeyboardOnTap()
            .keyboardDoneButton()
            .filePicker(isPresented: $importingText, types: [.plainText, .text, .item]) { result in
                switch result {
                case .success(let url): model.importText(from: url)
                case .failure(let e): model.errorMessage = e.localizedDescription
                }
            }
            .background(AuroraBackground())
            .navigationTitle("CIT Voice")
            .toolbar(.hidden, for: .navigationBar)
            .safeAreaInset(edge: .bottom, spacing: 0) { bottomBar }
            .alert("Lỗi", isPresented: Binding(
                get: { model.errorMessage != nil },
                set: { if !$0 { model.errorMessage = nil } }
            )) {
                Button("Đóng", role: .cancel) {}
            } message: {
                Text(model.errorMessage ?? "")
            }
            .onChange(of: model.errorMessage) { msg in
                if msg != nil { Haptics.error() }
            }
        }
    }

    // MARK: - Model

    @ViewBuilder
    private var modelCard: some View {
        Card {
            switch store.state {
            case .ready:
                HStack(spacing: 12) {
                    IconBadge(systemName: "checkmark.seal.fill", color: .green)
                    Text("Model v3 Nano · Đã cài").font(.body.weight(.semibold))
                    Spacer(minLength: 0)
                    Menu {
                        Button(role: .destructive) { store.deleteModel() } label: {
                            Label("Xoá model", systemImage: "trash")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .font(.title3)
                            .foregroundStyle(.secondary)
                    }
                }
            case .downloading:
                HStack(spacing: 12) {
                    IconBadge(systemName: "arrow.down.circle.fill")
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Đang tải model…").font(.body.weight(.semibold))
                        Text(store.statusText).font(.footnote).foregroundStyle(.secondary)
                    }
                }
                ProgressView(value: store.fileProgress).tint(Brand.indigo)
            case .notInstalled:
                HStack(spacing: 12) {
                    IconBadge(systemName: "icloud.and.arrow.down.fill")
                    Text("Cần tải model giọng nói").font(.body.weight(.semibold))
                }
                Button {
                    Haptics.tap()
                    Task { await store.download() }
                } label: {
                    SVGLabel("Tải model", icon: "IcDownload")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(SoftButtonStyle())
            case .failed(let msg):
                HStack(spacing: 12) {
                    IconBadge(systemName: "exclamationmark.triangle.fill", color: .red)
                    Text(msg).font(.footnote).foregroundStyle(.red)
                }
                Button {
                    Task { await store.download() }
                } label: {
                    Label("Thử lại", systemImage: "arrow.clockwise").frame(maxWidth: .infinity)
                }
                .buttonStyle(SoftButtonStyle())
            }
        }
    }

    // MARK: - Văn bản

    private var textCard: some View {
        Card("Văn bản", icon: "text.alignleft") {
            ZStack(alignment: .topLeading) {
                TextEditor(text: $model.text)
                    .focused($textFocused)
                    .scrollContentBackground(.hidden)
                    .frame(minHeight: 150)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 4)
                if model.text.isEmpty {
                    Text("Nhập hoặc dán văn bản tiếng Việt cần đọc…")
                        .foregroundStyle(.tertiary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 12)
                        .allowsHitTesting(false)
                }
            }
            .background(Color(.tertiarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            HStack(spacing: 8) {
                Button {
                    if let s = UIPasteboard.general.string { model.text = s; Haptics.tap() }
                } label: {
                    SVGLabel("Dán", icon: "IcPaste", size: 16)
                }
                .buttonStyle(SoftButtonStyle())

                Button {
                    importingText = true
                } label: {
                    SVGLabel("Mở .txt", icon: "IcFolder", size: 16)
                }
                .buttonStyle(SoftButtonStyle())

                if !model.text.isEmpty {
                    Button {
                        model.text = ""; Haptics.tap()
                    } label: {
                        SVGLabel("Xoá", icon: "IcClear", size: 16)
                    }
                    .buttonStyle(SoftButtonStyle(tint: .secondary))
                }
                if textFocused {
                    Button("Xong") { textFocused = false; hideKeyboard() }
                        .buttonStyle(SoftButtonStyle())
                }
                Spacer()
                Text("\(model.text.count) ký tự")
                    .font(.footnote.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            let paraCount = AppModel.paragraphs(of: model.text).count
            if paraCount > 1 {
                Text("\(paraCount) đoạn (mỗi dòng là một đoạn, nghỉ giữa các đoạn theo mục Nhịp đọc). Bấm Huỷ giữa chừng vẫn giữ phần đã tạo.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - Giọng đọc

    private var voiceCard: some View {
        Card("Giọng đọc", icon: "person.wave.2.fill") {
            ScrollViewReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 10) {
                        ForEach(model.voices) { v in
                            VoiceChip(voice: v, selected: v.id == model.selectedVoiceID)
                                .id(v.id)
                                .onTapGesture {
                                    Haptics.select()
                                    withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                                        model.selectedVoiceID = v.id
                                    }
                                }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 4)
                }
                .padding(.horizontal, -16)   // cho chip tràn sát mép thẻ
                .onAppear { proxy.scrollTo(model.selectedVoiceID, anchor: .center) }
            }
            if model.voices.isEmpty {
                Text("Chưa có giọng nào.").font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - Tuỳ chọn

    private var optionsCard: some View {
        Card("Tuỳ chỉnh", icon: "slider.horizontal.3") {
            VStack(alignment: .leading, spacing: 8) {
                Text("Nhịp đọc").font(.subheadline.weight(.semibold))
                Picker("Nhịp đọc", selection: Binding(get: { model.pacingPreset }, set: { model.applyPreset($0) })) {
                    ForEach(PacingPreset.allCases) { p in Text(p.title).tag(p) }
                }
                .pickerStyle(.segmented)
                Text("Kể chuyện và Tiên hiệp đọc chậm hơn và nghỉ lâu hơn giữa các câu. Chỉnh tiếp bên dưới cho hợp tai.")
                    .font(.caption).foregroundStyle(.secondary)

                HStack {
                    Text("Tốc độ đọc").font(.body)
                    Spacer()
                    Text(String(format: "%.2fx", model.speed))
                        .font(.body.monospacedDigit().weight(.semibold))
                        .foregroundStyle(Brand.indigo)
                }
                Slider(value: $model.speed, in: 0.5...1.5, step: 0.05) {
                    Text("Tốc độ")
                } minimumValueLabel: {
                    Image(systemName: "tortoise.fill").foregroundStyle(.secondary)
                } maximumValueLabel: {
                    Image(systemName: "hare.fill").foregroundStyle(.secondary)
                }
                .tint(Brand.indigo)

                DisclosureGroup("Ngắt nghỉ") {
                    VStack(alignment: .leading, spacing: 6) {
                        pauseSlider("Giữa các đoạn", value: $model.pauses.paragraph, range: 0.2...2.5)
                        pauseSlider("Giữa các câu", value: $model.pauses.sentence, range: 0.1...1.5)
                        pauseSlider("Sau dấu phẩy", value: $model.pauses.minor, range: 0.0...0.8)
                        Text("Muốn nghỉ riêng ở một chỗ: chèn thẻ [nghỉ 2s] hoặc [nghỉ 500ms] vào văn bản.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    .padding(.top, 4)
                }
                .font(.footnote)
            }

            Divider()

            VStack(alignment: .leading, spacing: 8) {
                Text("Chất lượng giọng").font(.subheadline.weight(.semibold))
                Picker("Chất lượng", selection: $model.quality) {
                    ForEach(AppModel.Quality.allCases) { q in Text(q.title).tag(q) }
                }
                .pickerStyle(.segmented)
                Text("Nếu giọng bị dập, đứt tiếng hoặc rè: chọn Cao hoặc Rất cao (tạo lâu hơn).")
                    .font(.caption).foregroundStyle(.secondary)
                DisclosureGroup("Nâng cao") {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(String(format: "Độ bám giọng mẫu (cfg): %.1f", model.cfgScale))
                            .font(.footnote.monospacedDigit())
                        Slider(value: $model.cfgScale, in: 1...4, step: 0.5).tint(Brand.indigo)
                        Text("Mặc định 3.0. Thử 2.0–2.5 nếu giọng nhân bản bị méo hoặc đứt.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    .padding(.top, 4)
                }
                .font(.footnote)
            }

            Divider()

            NavigationLink {
                HistoryView(history: model.history, player: player, model: model)
            } label: {
                HStack(spacing: 12) {
                    IconBadge(systemName: "clock.arrow.circlepath", color: .teal)
                    Text("Lịch sử (\(model.history.items.count))").foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Divider()

            NavigationLink {
                DubbingView(store: store, app: model)
            } label: {
                HStack(spacing: 12) {
                    IconBadge(systemName: "film.fill", color: .orange)
                    Text("Lồng tiếng video").foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Divider()

            NavigationLink {
                CloneView(store: store, model: model, player: player)
            } label: {
                HStack(spacing: 12) {
                    IconBadge(systemName: "mic.fill", color: .pink)
                    Text("Nhân bản giọng nói").foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Divider()

            NavigationLink {
                AboutView()
            } label: {
                HStack(spacing: 12) {
                    IconBadge(systemName: "person.crop.circle.fill", color: .indigo)
                    Text("Về ứng dụng & tác giả").foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Divider()

            NavigationLink {
                LicensesView()
            } label: {
                HStack(spacing: 12) {
                    IconBadge(systemName: "doc.text.fill", color: .gray)
                    Text("Giấy phép & ghi công").foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }

    private func pauseSlider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(title).font(.footnote)
                Spacer()
                Text(String(format: "%.2f s", value.wrappedValue))
                    .font(.footnote.monospacedDigit().weight(.semibold))
                    .foregroundStyle(Brand.indigo)
            }
            Slider(value: value, in: range, step: 0.05).tint(Brand.indigo)
        }
    }

    // MARK: - Thanh dưới (phát + nút tạo)

    private var bottomBar: some View {
        VStack(spacing: 12) {
            if let url = model.outputURL, !model.isGenerating {
                WaveformPlayer(url: url, player: player) { model.errorMessage = $0 }
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }

            HStack(spacing: 10) {
                Button {
                    textFocused = false
                    Haptics.tap()
                    model.generate(player: player, store: store)
                } label: {
                    HStack(spacing: 8) {
                        if model.isGenerating {
                            ProgressView().tint(.white)
                            Text(model.statusText.isEmpty
                                 ? "Đang tạo… \(Int(model.progress * 100))%"
                                 : "\(model.statusText) · \(Int(model.progress * 100))%")
                        } else {
                            SVGIcon("IcWave", size: 20)
                            Text("Tạo giọng nói")
                        }
                    }
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(model.isGenerating)

                if model.isGenerating {
                    Button {
                        model.cancel()
                    } label: {
                        SVGIcon("IcClear", size: 22)
                    }
                    .buttonStyle(CircleIconButtonStyle(danger: true, size: 54))
                    .accessibilityLabel("Huỷ")
                }
            }

            if model.isGenerating {
                ProgressView(value: model.progress).tint(Brand.indigo)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 8)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Divider() }
        .animation(.spring(response: 0.35, dampingFraction: 0.85), value: model.isGenerating)
        .animation(.spring(response: 0.35, dampingFraction: 0.85), value: model.outputURL)
    }
}

// MARK: - Chip giọng

private struct VoiceChip: View {
    let voice: Voice
    let selected: Bool

    private var initial: String {
        let word = voice.id.split(separator: " ").last ?? Substring(voice.id)
        return String(word.prefix(1)).uppercased()
    }

    private var avatarGradient: LinearGradient {
        let palette: [[Color]] = [
            [Color(red: 0.37, green: 0.36, blue: 0.90), Color(red: 0.75, green: 0.33, blue: 0.95)],
            [Color(red: 0.04, green: 0.52, blue: 1.00), Color(red: 0.39, green: 0.82, blue: 1.00)],
            [Color(red: 1.00, green: 0.27, blue: 0.23), Color(red: 1.00, green: 0.62, blue: 0.04)],
            [Color(red: 0.19, green: 0.82, blue: 0.35), Color(red: 0.19, green: 0.69, blue: 0.78)],
            [Color(red: 1.00, green: 0.18, blue: 0.33), Color(red: 0.75, green: 0.33, blue: 0.95)],
        ]
        let seed = voice.id.unicodeScalars.reduce(0) { $0 &+ Int($1.value) }
        let c = palette[seed % palette.count]
        return LinearGradient(colors: c, startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    var body: some View {
        VStack(spacing: 8) {
            ZStack(alignment: .bottomTrailing) {
                Circle()
                    .fill(avatarGradient)
                    .frame(width: 52, height: 52)
                    .overlay(
                        Text(initial)
                            .font(.system(size: 22, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                    )
                if voice.isCustom {
                    Image(systemName: "mic.fill")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 18, height: 18)
                        .background(Color.pink, in: Circle())
                        .overlay(Circle().stroke(Color(.secondarySystemGroupedBackground), lineWidth: 2))
                }
            }
            Text(voice.id)
                .font(.footnote.weight(.semibold))
                .lineLimit(1)
        }
        .frame(width: 92)
        .padding(.vertical, 12)
        .padding(.horizontal, 6)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(selected ? Brand.indigo.opacity(0.12) : Color(.tertiarySystemGroupedBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(selected ? Brand.indigo : .clear, lineWidth: 2)
        )
        .overlay(alignment: .topTrailing) {
            if selected {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(Brand.indigo, Color(.secondarySystemGroupedBackground))
                    .padding(6)
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(selected ? [.isButton, .isSelected] : .isButton)
    }
}
