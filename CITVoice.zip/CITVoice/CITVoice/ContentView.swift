import SwiftUI

struct ContentView: View {
    @StateObject private var store = ModelStore()
    @StateObject private var player = AudioPlayer()
    @StateObject private var model = AppModel()

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(G2PFactory.isAvailable
                         ? "Giọng thật: cần cài model v3 Nano bên dưới."
                         : "Chưa có bộ chuyển chữ → âm vị (giai đoạn 2), nên nút tạo giọng vẫn chỉ phát tiếng bíp thử giao diện.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                modelSection

                Section("Văn bản") {
                    TextEditor(text: $model.text)
                        .frame(minHeight: 140)
                }

                Section("Giọng đọc") {
                    Picker("Giọng", selection: $model.selectedVoiceID) {
                        ForEach(model.voices) { v in
                            Text("\(v.id) · \(v.description)").tag(v.id)
                        }
                    }
                    VStack(alignment: .leading) {
                        Text(String(format: "Tốc độ: %.1fx", model.speed))
                        Slider(value: $model.speed, in: 0.5...1.5, step: 0.1)
                    }
                    Toggle("Chế độ nhanh (ít bước hơn)", isOn: $model.fastMode)
                }

                Section {
                    Button {
                        model.generate(player: player, store: store)
                    } label: {
                        HStack {
                            if model.isGenerating { ProgressView() }
                            Text(model.isGenerating ? "Đang tạo… \(Int(model.progress * 100))%" : "Tạo giọng nói")
                        }
                    }
                    .disabled(model.isGenerating)

                    if model.isGenerating {
                        ProgressView(value: model.progress)
                        Button("Huỷ", role: .destructive) { model.cancel() }
                    }

                    if let url = model.outputURL {
                        Button(player.isPlaying ? "Dừng" : "Phát lại") {
                            if player.isPlaying {
                                player.stop()
                            } else {
                                do { try player.play(url: url) } catch { model.errorMessage = error.localizedDescription }
                            }
                        }
                        ShareLink(item: url) {
                            Label("Lưu / chia sẻ file WAV", systemImage: "square.and.arrow.up")
                        }
                    }
                }
            }
            .navigationTitle("CIT Voice")
            .alert("Lỗi", isPresented: Binding(
                get: { model.errorMessage != nil },
                set: { if !$0 { model.errorMessage = nil } }
            )) {
                Button("Đóng", role: .cancel) {}
            } message: {
                Text(model.errorMessage ?? "")
            }
        }
    }

    @ViewBuilder
    private var modelSection: some View {
        Section("Model v3 Nano") {
            switch store.state {
            case .ready:
                Label("Đã cài model", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                Button("Xoá model", role: .destructive) { store.deleteModel() }
            case .downloading:
                ProgressView(value: store.fileProgress)
                Text(store.statusText).font(.footnote).foregroundStyle(.secondary)
            case .notInstalled:
                Text("Model dung lượng lớn, nên tải bằng Wi-Fi.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button("Tải model") { Task { await store.download() } }
            case .failed(let msg):
                Text(msg).font(.footnote).foregroundStyle(.red)
                Button("Thử lại") { Task { await store.download() } }
            }
        }
    }
}
