import Foundation
import OnnxRuntimeBindings

// =============================================================================
//  SUPERTONIC-3 (v0.11) — engine giọng thứ hai, chạy trên máy bằng ONNX Runtime.
//
//  Quy trình (text → duration predictor → text encoder → vector estimator × N bước → vocoder) và bước chuẩn
//  hoá văn bản được PORT sang Swift từ mã mẫu của hãng (repo supertonic, py/helper.py, giấy phép MIT,
//  Copyright (c) 2026 Supertone Inc.). Model Supertonic-3 theo giấy phép OpenRAIL-M.
//  Nguồn & điều khoản: xem `Licenses.swift` và `THIRD_PARTY_NOTICES.md`.
//
//  Model gốc xuất 44,1 kHz; app hạ về 24 kHz để dùng chung với VieNeu (lồng tiếng, xuất file, DubFit…).
//  Chưa kiểm thử trên máy thật: nếu giọng lạ, báo lại để chỉnh (steps, tốc độ, chuẩn hoá văn bản).
// =============================================================================

/// Chọn engine theo giọng đang dùng: giọng Supertonic → SupertonicEngine, còn lại → VieNeu (hoặc tiếng bíp).
final class RouterEngine: SpeechEngine, @unchecked Sendable {
    let sampleRate = 24_000
    private let nano: any SpeechEngine
    private let supertonic: (any SpeechEngine)?

    init(nano: any SpeechEngine, supertonic: (any SpeechEngine)?) {
        self.nano = nano
        self.supertonic = supertonic
    }

    func synthesize(text: String, voice: Voice, options: SynthesisOptions,
                    progress: @escaping @Sendable (Double) -> Void) async throws -> [Float] {
        if voice.engine == "supertonic" {
            guard let st = supertonic else { throw TTSError.notImplemented("Cần tải model Supertonic-3 trước.") }
            return try await st.synthesize(text: text, voice: voice, options: options, progress: progress)
        }
        return try await nano.synthesize(text: text, voice: voice, options: options, progress: progress)
    }
}

final class SupertonicEngine: SpeechEngine, @unchecked Sendable {
    let sampleRate = 24_000
    private let nativeRate: Int
    private let baseChunk: Int
    private let compress: Int
    private let latentDimBase: Int
    private let indexer: [Int]
    private let dir: URL

    private let env: ORTEnv
    private let sDP: ORTSession, sText: ORTSession, sVE: ORTSession, sVoc: ORTSession
    private let oDP: String, oText: String, oVE: String, oVoc: String

    private struct Style { let ttl: ORTValue; let dp: ORTValue }
    private var styles: [String: Style] = [:]
    private let lock = NSLock()

    init(directory: URL, threads: Int = 3) throws {
        dir = directory
        let onnx = directory.appendingPathComponent("onnx", isDirectory: true)

        // tts.json
        let cfgData = try Data(contentsOf: onnx.appendingPathComponent("tts.json"))
        guard let cfg = try JSONSerialization.jsonObject(with: cfgData) as? [String: Any],
              let ae = cfg["ae"] as? [String: Any], let ttl = cfg["ttl"] as? [String: Any],
              let sr = (ae["sample_rate"] as? NSNumber)?.intValue,
              let bcs = (ae["base_chunk_size"] as? NSNumber)?.intValue,
              let ccf = (ttl["chunk_compress_factor"] as? NSNumber)?.intValue,
              let ld = (ttl["latent_dim"] as? NSNumber)?.intValue else {
            throw TTSError.notImplemented("tts.json của Supertonic thiếu trường cấu hình")
        }
        nativeRate = sr; baseChunk = bcs; compress = ccf; latentDimBase = ld

        // unicode_indexer.json: mã Unicode → id
        let idxData = try Data(contentsOf: onnx.appendingPathComponent("unicode_indexer.json"))
        let idxObj = try JSONSerialization.jsonObject(with: idxData)
        if let arr = idxObj as? [NSNumber] {
            indexer = arr.map { $0.intValue }
        } else if let dict = idxObj as? [String: Any] {
            var table = [Int](repeating: -1, count: 65_536)
            for (k, v) in dict { if let i = Int(k), i >= 0, i < table.count, let n = v as? NSNumber { table[i] = n.intValue } }
            indexer = table
        } else {
            throw TTSError.notImplemented("unicode_indexer.json có định dạng lạ")
        }

        let environment = try ORTEnv(loggingLevel: .warning)
        let opts = try ORTSessionOptions()
        try opts.setIntraOpNumThreads(Int32(threads))
        func open(_ f: String) throws -> ORTSession {
            try ORTSession(env: environment, modelPath: onnx.appendingPathComponent(f).path, sessionOptions: opts)
        }
        env = environment
        sDP = try open("duration_predictor.onnx")
        sText = try open("text_encoder.onnx")
        sVE = try open("vector_estimator.onnx")
        sVoc = try open("vocoder.onnx")
        oDP = try sDP.outputNames().first ?? "duration"
        oText = try sText.outputNames().first ?? "text_emb"
        oVE = try sVE.outputNames().first ?? "denoised_latent"
        oVoc = try sVoc.outputNames().first ?? "wav_tts"
    }

    // MARK: - Tensor helpers

    private static func tensor<T>(_ a: [T], _ shape: [Int], _ type: ORTTensorElementDataType) throws -> ORTValue {
        let data = a.withUnsafeBufferPointer { NSMutableData(bytes: $0.baseAddress, length: a.count * MemoryLayout<T>.stride) }
        return try ORTValue(tensorData: data, elementType: type, shape: shape.map { NSNumber(value: $0) })
    }

    private static func floats(_ v: ORTValue) throws -> [Float] {
        let d = try v.tensorData() as Data
        return d.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
    }

    private func run(_ s: ORTSession, _ out: String, _ inputs: [String: ORTValue]) throws -> ORTValue {
        guard let v = try s.run(withInputs: inputs, outputNames: [out], runOptions: nil)[out] else {
            throw TTSError.notImplemented("model Supertonic không trả về \(out)")
        }
        return v
    }

    private static func randn(_ n: Int) -> [Float] {
        var out = [Float](repeating: 0, count: n)
        var i = 0
        while i < n {
            let u1 = Float.random(in: Float.leastNormalMagnitude..<1), u2 = Float.random(in: 0..<1)
            let r = sqrtf(-2 * logf(u1))
            out[i] = r * cosf(2 * .pi * u2)
            if i + 1 < n { out[i + 1] = r * sinf(2 * .pi * u2) }
            i += 2
        }
        return out
    }

    // MARK: - Giọng mẫu (voice_styles/*.json)

    private func style(for preset: String) throws -> Style {
        lock.lock(); defer { lock.unlock() }
        if let s = styles[preset] { return s }
        let url = dir.appendingPathComponent("voice_styles/\(preset).json")
        guard let obj = try JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any] else {
            throw TTSError.notImplemented("Không đọc được giọng \(preset)")
        }
        func part(_ key: String) throws -> ORTValue {
            guard let p = obj[key] as? [String: Any], let data = p["data"],
                  let dims = (p["dims"] as? [NSNumber])?.map({ $0.intValue }), dims.count >= 3 else {
                throw TTSError.notImplemented("Giọng \(preset) thiếu \(key)")
            }
            var flat: [Float] = []
            Self.flatten(data, into: &flat)
            let shape = [1, dims[1], dims[2]]
            guard flat.count == shape.reduce(1, *) else {
                throw TTSError.notImplemented("Giọng \(preset): \(key) sai kích thước")
            }
            return try Self.tensor(flat, shape, .float)
        }
        let s = Style(ttl: try part("style_ttl"), dp: try part("style_dp"))
        styles[preset] = s
        return s
    }

    private static func flatten(_ x: Any, into out: inout [Float]) {
        if let arr = x as? [Any] { for e in arr { flatten(e, into: &out) } }
        else if let n = x as? NSNumber { out.append(n.floatValue) }
    }

    // MARK: - Chuẩn hoá văn bản (port của UnicodeProcessor._preprocess_text)

    private static func isEmoji(_ s: Unicode.Scalar) -> Bool {
        switch s.value {
        case 0x1F600...0x1F64F, 0x1F300...0x1F5FF, 0x1F680...0x1F6FF, 0x1F700...0x1F77F,
             0x1F780...0x1F7FF, 0x1F800...0x1F8FF, 0x1F900...0x1F9FF, 0x1FA00...0x1FA6F,
             0x1FA70...0x1FAFF, 0x2600...0x26FF, 0x2700...0x27BF, 0x1F1E6...0x1F1FF:
            return true
        default: return false
        }
    }

    static func preprocess(_ raw: String, lang: String) -> String {
        var t = raw.decomposedStringWithCompatibilityMapping          // NFKD, như bản gốc
        t = String(String.UnicodeScalarView(t.unicodeScalars.filter { !isEmoji($0) }))
        let replacements: [(String, String)] = [
            ("–", "-"), ("‑", "-"), ("—", "-"), ("_", " "),
            ("\u{201C}", "\""), ("\u{201D}", "\""), ("\u{2018}", "'"), ("\u{2019}", "'"),
            ("´", "'"), ("`", "'"), ("[", " "), ("]", " "), ("|", " "), ("/", " "), ("#", " "),
            ("→", " "), ("←", " "),
        ]
        for (k, v) in replacements { t = t.replacingOccurrences(of: k, with: v) }
        for c in ["♥", "☆", "♡", "©", "\\"] { t = t.replacingOccurrences(of: c, with: "") }
        t = t.replacingOccurrences(of: "@", with: " at ")
        t = t.replacingOccurrences(of: "e.g.,", with: "for example, ")
        t = t.replacingOccurrences(of: "i.e.,", with: "that is, ")
        for (a, b) in [(" ,", ","), (" .", "."), (" !", "!"), (" ?", "?"), (" ;", ";"), (" :", ":"), (" '", "'")] {
            t = t.replacingOccurrences(of: a, with: b)
        }
        while t.contains("\"\"") { t = t.replacingOccurrences(of: "\"\"", with: "\"") }
        while t.contains("''") { t = t.replacingOccurrences(of: "''", with: "'") }
        while t.contains("``") { t = t.replacingOccurrences(of: "``", with: "`") }
        t = t.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let enders = Set(".!?;:,'\")]}…。」』】〉》›»")
        if let last = t.last, !enders.contains(last) { t += "." } else if t.isEmpty { t = "." }
        return "<\(lang)>" + t + "</\(lang)>"
    }

    // MARK: - Tách đoạn dài (port của chunk_text, tối đa 300 ký tự)

    static func chunk(_ text: String, maxLen: Int = 300) -> [String] {
        let paragraphs = text.components(separatedBy: "\n\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        var chunks: [String] = []
        for para in paragraphs {
            var current = ""
            for s in sentences(of: para) {
                for piece in splitLong(s, maxLen: maxLen) {
                    if current.count + piece.count + 1 <= maxLen {
                        current += (current.isEmpty ? "" : " ") + piece
                    } else {
                        if !current.isEmpty { chunks.append(current) }
                        current = piece
                    }
                }
            }
            if !current.isEmpty { chunks.append(current) }
        }
        return chunks
    }

    /// Tách theo . ! ? rồi khoảng trắng.
    private static func sentences(of p: String) -> [String] {
        guard let re = try? NSRegularExpression(pattern: "(?<=[.!?])\\s+") else { return [p] }
        let ns = p as NSString
        var out: [String] = []
        var pos = 0
        for m in re.matches(in: p, range: NSRange(location: 0, length: ns.length)) {
            let s = ns.substring(with: NSRange(location: pos, length: m.range.location - pos))
            if !s.isEmpty { out.append(s) }
            pos = m.range.location + m.range.length
        }
        let tail = ns.substring(from: pos)
        if !tail.isEmpty { out.append(tail) }
        return out
    }

    /// Câu dài hơn `maxLen`: cắt theo từ.
    private static func splitLong(_ s: String, maxLen: Int) -> [String] {
        if s.count <= maxLen { return [s] }
        var out: [String] = []
        var cur = ""
        for w in s.split(separator: " ", omittingEmptySubsequences: true) {
            if cur.count + w.count + 1 > maxLen, !cur.isEmpty { out.append(cur); cur = String(w) }
            else { cur += (cur.isEmpty ? "" : " ") + w }
        }
        if !cur.isEmpty { out.append(cur) }
        return out
    }

    // MARK: - Một đoạn → âm thanh

    private func infer(_ chunk: String, style: Style, steps: Int, speed: Float) throws -> [Float] {
        let processed = Self.preprocess(chunk, lang: "vi")
        var ids: [Int64] = []
        for sc in processed.unicodeScalars {
            let v = Int(sc.value)
            if v < indexer.count, indexer[v] >= 0 { ids.append(Int64(indexer[v])) }
        }
        guard ids.count > 2 else { return [] }
        let L = ids.count
        let textIds = try Self.tensor(ids, [1, L], .int64)
        let textMask = try Self.tensor([Float](repeating: 1, count: L), [1, 1, L], .float)

        let durOut = try Self.floats(try run(sDP, oDP, ["text_ids": textIds, "style_dp": style.dp, "text_mask": textMask]))
        let dur = Double(durOut.first ?? 0) / Double(max(speed, 0.1))
        guard dur > 0.05, dur < 60 else { return [] }

        let textEmb = try run(sText, oText, ["text_ids": textIds, "style_ttl": style.ttl, "text_mask": textMask])

        let chunkSize = baseChunk * compress
        let wavLenMax = dur * Double(nativeRate)
        let wavLen = Int(wavLenMax)
        let latentLen = max(1, Int((wavLenMax + Double(chunkSize) - 1) / Double(chunkSize)))
        let latentDim = latentDimBase * compress
        let valid = min(latentLen, max(1, (wavLen + chunkSize - 1) / chunkSize))
        let maskArr: [Float] = (0..<latentLen).map { $0 < valid ? 1 : 0 }
        let latentMask = try Self.tensor(maskArr, [1, 1, latentLen], .float)

        var noisy = Self.randn(latentDim * latentLen)
        for d in 0..<latentDim { for t in 0..<latentLen where t >= valid { noisy[d * latentLen + t] = 0 } }
        var xt = try Self.tensor(noisy, [1, latentDim, latentLen], .float)

        let totalStep = try Self.tensor([Float(steps)], [1], .float)
        for step in 0..<steps {
            try Task.checkCancellation()
            let cur = try Self.tensor([Float(step)], [1], .float)
            xt = try run(sVE, oVE, [
                "noisy_latent": xt, "text_emb": textEmb, "style_ttl": style.ttl,
                "text_mask": textMask, "latent_mask": latentMask,
                "current_step": cur, "total_step": totalStep,
            ])
        }
        let wav = try Self.floats(try run(sVoc, oVoc, ["latent": xt]))
        return Array(wav.prefix(min(wavLen, wav.count)))
    }

    // MARK: - SpeechEngine

    func synthesize(text: String, voice: Voice, options: SynthesisOptions,
                    progress: @escaping @Sendable (Double) -> Void) async throws -> [Float] {
        let st = try style(for: voice.preset.isEmpty ? "M1" : voice.preset)
        // Số bước khử nhiễu: ánh xạ từ mức chất lượng của app (8/16/32/48 → 6/8/12/16). Hãng đặt mặc định 8.
        let steps = options.steps <= 8 ? 6 : (options.steps <= 16 ? 8 : (options.steps <= 32 ? 12 : 16))
        let speed = max(0.3, options.speed) * 1.05          // 1.05 là tốc độ mặc định của hãng

        var plans: [(chunks: [String], pause: Double)] = []
        for (seg, pause) in PauseTags.split(text) {
            plans.append((seg.isEmpty ? [] : Self.chunk(seg), pause))
        }
        let total = max(1, plans.reduce(0) { $0 + $1.chunks.count })
        var done = 0
        var out: [Float] = []
        for plan in plans {
            var wavs: [[Float]] = []
            for c in plan.chunks {
                try Task.checkCancellation()
                let w = try infer(c, style: st, steps: steps, speed: speed)
                if !w.isEmpty { wavs.append(Resampler.resample(w, from: nativeRate, to: sampleRate)) }
                done += 1
                progress(Double(done) / Double(total))
            }
            let gaps = [Double](repeating: options.pauses.sentence, count: max(0, wavs.count - 1))
            out += AudioUtils.join(wavs, sr: sampleRate, pauses: gaps)
            if plan.pause > 0 { out += [Float](repeating: 0, count: Int(plan.pause * Double(sampleRate))) }
        }
        return options.normalize ? AudioUtils.normalizeLoudness(out) : out
    }
}
