import Foundation

/// Port từ src/vieneu_utils/core_utils.py + phonemize_text.py:
///   split_into_sentences → pack_sentences_into_chunks → punc_norm → _classify_gap → _merge_short_chunks
/// và `phonemize_text_with_emotions`. Phần chuẩn hoá/âm vị thật sự do `SeaG2P` đảm nhiệm.
struct TextChunker {
    let g2p: SeaG2P
    var maxChars = 140          // Nano train với clip ≤ 15 giây
    var minChunkChars = 20

    // MARK: - API chính

    /// Văn bản thô → (chunks đã chuẩn hoá, loại ranh giới giữa các chunk: para / sentence / minor).
    func chunks(from text: String) throws -> (chunks: [String], gaps: [String]) {
        if text.isEmpty { return ([], []) }
        let keepCues = text.contains("[") || text.contains("<|emotion_")
        var chunks: [String] = []
        var gaps: [String] = []
        let paragraphs = text.components(separatedBy: CharacterSet(charactersIn: "\r\n"))
            .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        for para in paragraphs {
            let sentences = Self.splitIntoSentences(para)
            if sentences.isEmpty { continue }
            let normalized = try sentences.map { try normalizeSentence($0, keepCues: keepCues) }
            let paraChunks = Self.packSentences(normalized, maxChars: maxChars)
            if paraChunks.isEmpty { continue }
            if !chunks.isEmpty { gaps.append("para") }
            for (j, c) in paraChunks.enumerated() {
                if j > 0 { gaps.append("sentence") }
                chunks.append(c)
            }
        }
        chunks = try chunks.map { try g2p.puncNorm($0) }
        gaps = gaps.enumerated().map { $1 == "para" ? "para" : Self.classifyGap(chunks[$0]) }
        return Self.mergeShort(chunks, gaps, minChars: minChunkChars)
    }

    /// Một chunk → chuỗi âm vị, giữ thẻ cảm xúc `<|emotion_k|>`.
    func phonemize(chunk: String) throws -> String {
        if !chunk.contains("[") && !chunk.contains("<|emotion_") {
            return try g2p.run(chunk, puncNorm: true)
        }
        var out = ""
        for (isTag, part) in Self.splitKeepingTags(chunk) {
            if isTag, let token = Self.emotionToken(part) {
                out = out.isEmpty ? token : out + " " + token
                continue
            }
            let ph = part.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                ? "" : try g2p.run(part, puncNorm: false)
            if ph.isEmpty { continue }
            if out.isEmpty { out = ph }
            else if let f = ph.unicodeScalars.first, Self.attachingPunct.contains(f) { out += ph }
            else { out += " " + ph }
        }
        return try g2p.puncNorm(out)
    }

    // MARK: - Thẻ cảm xúc

    private static let attachingPunct = Set(".,!?;:…)]}\"'’”".unicodeScalars)
    private static let tagRE = try! NSRegularExpression(pattern: #"\[[^\]]+\]|<\|emotion_\d+\|>"#)
    private static let emotionTokenRE = try! NSRegularExpression(pattern: #"<\|emotion_\d+\|>"#)
    private static let emotionK: [String: Int] = [
        "chuckle": 1, "cười": 1, "cuoi": 1,
        "sigh": 2, "thở dài": 2, "tho dai": 2,
        "clear throat": 3, "hắng giọng": 3, "hang giong": 3, "hắc giọng": 3, "hac giong": 3,
    ]

    /// Tương đương `re.split` có nhóm bắt: trả [(isTag, đoạn)] xen kẽ, giữ cả đoạn rỗng.
    private static func splitKeepingTags(_ s: String) -> [(Bool, String)] {
        let ns = s as NSString
        var out: [(Bool, String)] = []
        var pos = 0
        for m in tagRE.matches(in: s, range: NSRange(location: 0, length: ns.length)) {
            out.append((false, ns.substring(with: NSRange(location: pos, length: m.range.location - pos))))
            out.append((true, ns.substring(with: m.range)))
            pos = m.range.location + m.range.length
        }
        out.append((false, ns.substring(from: pos)))
        return out
    }

    private static func emotionToken(_ tag: String) -> String? {
        let t = tag.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.hasPrefix("<|") { return t }
        let inner = String(t.dropFirst().dropLast()).trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if let k = emotionK[inner] { return "<|emotion_\(k)|>" }
        return nil
    }

    private func normalizeSentence(_ s: String, keepCues: Bool) throws -> String {
        if !s.contains("[") && !s.contains("<|emotion_") { return try g2p.normalize(s, puncNorm: false) }
        var parts: [String] = []
        for (isTag, part) in Self.splitKeepingTags(s) {
            if isTag { parts.append(Self.emotionToken(part) ?? part) }
            else if !part.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                parts.append(try g2p.normalize(part, puncNorm: false))
            }
        }
        return parts.filter { !$0.isEmpty }.joined(separator: " ")
    }

    // MARK: - Độ dài (đếm theo code point như Python)

    private static func plen(_ s: String) -> Int { s.unicodeScalars.count }

    private static func effectiveLen(_ chunk: String) -> Int {
        let ns = chunk as NSString
        let stripped = emotionTokenRE.stringByReplacingMatches(
            in: chunk, range: NSRange(location: 0, length: ns.length), withTemplate: "")
        return plen(stripped.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    // MARK: - Tách câu (nhận biết ngoặc/trích dẫn)

    private static let openToClose: [Unicode.Scalar: Unicode.Scalar] = [
        "(": ")", "[": "]", "{": "}", "“": "”", "‘": "’", "«": "»", "‹": "›", "「": "」", "『": "』",
    ]
    private static let openers = Set(openToClose.keys)
    private static let closers = Set(openToClose.values)
    private static let sentEnd = Set(".!?…".unicodeScalars)
    private static let trailingClose = closers.union(Set("\"'’”".unicodeScalars))

    private static func str(_ s: ArraySlice<Unicode.Scalar>) -> String {
        var v = String.UnicodeScalarView(); v.append(contentsOf: s); return String(v)
    }

    private static func scanSentences(_ text: String, quoteAware: Bool) -> ([String], Bool) {
        let t = Array(text.unicodeScalars)
        let n = t.count
        var out: [String] = []
        var start = 0, i = 0, depth = 0
        var inQuote = false
        while i < n {
            let ch = t[i]
            if quoteAware && ch == "\"" {
                inQuote.toggle()
            } else if quoteAware && openers.contains(ch) {
                depth += 1
            } else if quoteAware && closers.contains(ch) {
                if depth > 0 { depth -= 1 }
            } else if sentEnd.contains(ch) && depth == 0 && !inQuote {
                var j = i + 1
                while j < n && sentEnd.contains(t[j]) { j += 1 }
                while j < n && trailingClose.contains(t[j]) { j += 1 }
                if j >= n || t[j].properties.isWhitespace {
                    out.append(str(t[start..<j]))
                    start = j; i = j
                    continue
                }
                i = j
                continue
            }
            i += 1
        }
        if start < n { out.append(str(t[start..<n])) }
        let cleaned = out.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        return (cleaned, depth == 0 && !inQuote)
    }

    static func splitIntoSentences(_ text: String) -> [String] {
        if text.isEmpty { return [] }
        let (s, balanced) = scanSentences(text, quoteAware: true)
        return balanced ? s : scanSentences(text, quoteAware: false).0
    }

    // MARK: - Đóng gói chunk

    private static let connWords = Set("và nhưng hoặc song rồi nên vì nếu khi để do bởi".split(separator: " ").map(String.init))
    private static let connPairs: Set<String> = Set([
        ("sau", "khi"), ("trước", "khi"), ("trong", "khi"), ("mỗi", "khi"),
        ("đến", "khi"), ("tới", "khi"), ("cho", "nên"), ("cho", "đến"),
        ("bởi", "vì"), ("nếu", "như"), ("tuy", "nhiên"), ("thế", "nhưng"),
        ("vì", "vậy"), ("vì", "thế"), ("do", "đó"), ("sau", "đó"),
    ].map { "\($0.0)|\($0.1)" })
    private static let connStrip = CharacterSet(charactersIn: "\"'“”‘’()[]«»…")
    private static let numberWords = Set((
        "không một mốt hai ba bốn tư năm lăm sáu bảy tám chín mười mươi trăm nghìn ngàn "
        + "triệu tỷ tỉ linh lẻ phẩy chấm").split(separator: " ").map(String.init))
    private static let tokenRE = try! NSRegularExpression(
        pattern: #"<en>.*?</en>|\S+"#, options: [.caseInsensitive, .dotMatchesLineSeparators])

    private static func connKey(_ t: String) -> String { t.trimmingCharacters(in: connStrip).lowercased() }

    private static func isNumberWord(_ t: String) -> Bool {
        let k = connKey(t)
        return numberWords.contains(k)
            || (!k.isEmpty && k.unicodeScalars.allSatisfy { $0.properties.numericType == .decimal })
    }

    private static func tokenize(_ s: String) -> [String] {
        let ns = s as NSString
        return tokenRE.matches(in: s, range: NSRange(location: 0, length: ns.length)).map { ns.substring(with: $0.range) }
    }

    private static func tailSlack(_ maxChars: Int) -> Int { min(15, maxChars / 8) }

    private static func fits(_ cur: Int, _ add: Int, _ maxChars: Int) -> Bool {
        let total = cur > 0 ? cur + 1 + add : add
        let slack = tailSlack(maxChars)
        return total <= maxChars || (add <= slack && total <= maxChars + slack)
    }

    private static func spanLen(_ w: [String], _ s: Int, _ e: Int) -> Int {
        if e <= s { return 0 }
        return w[s..<e].reduce(0) { $0 + plen($1) } + (e - s - 1)
    }

    private static func balancedCut(_ w: [String], start: Int, target: Double, maxChars: Int, minLeft: Int) -> Int {
        var bestNat: (Double, Int)?
        var bestPlain: (Double, Int)?
        var endCap = start + 1
        var j = start + 1
        while j < w.count {
            let left = spanLen(w, start, j)
            if left > maxChars { break }
            endCap = j
            let key = connKey(w[j]), prev = connKey(w[j - 1])
            let nxt = j + 1 < w.count ? connKey(w[j + 1]) : ""
            let d = abs(Double(left) - target)
            let insidePair = connPairs.contains("\(prev)|\(key)")
            let natural = (connWords.contains(key) || connPairs.contains("\(key)|\(nxt)")) && !connWords.contains(prev)
            if natural && !insidePair && left >= minLeft && (bestNat == nil || d < bestNat!.0) { bestNat = (d, j) }
            let plainOK = !insidePair && !(isNumberWord(w[j - 1]) && isNumberWord(w[j]))
            if plainOK && (bestPlain == nil || d < bestPlain!.0) { bestPlain = (d, j) }
            j += 1
        }
        if let b = bestNat { return b.1 }
        if let b = bestPlain { return b.1 }
        var end = endCap
        while end > start + 1 && end < w.count && connPairs.contains("\(connKey(w[end - 1]))|\(connKey(w[end]))") { end -= 1 }
        return end
    }

    private static func splitLongPart(_ part: String, maxChars: Int) -> [String] {
        let words = tokenize(part)
        let minLeft = maxChars / 3
        var pieces: [String] = []
        var start = 0
        while start < words.count {
            let rest = spanLen(words, start, words.count)
            if rest <= maxChars { pieces.append(words[start...].joined(separator: " ")); break }
            var full = start + 1
            while full < words.count && spanLen(words, start, full + 1) <= maxChars { full += 1 }
            if fits(spanLen(words, start, full), spanLen(words, full, words.count), maxChars) {
                pieces.append(words[start...].joined(separator: " ")); break
            }
            let nPieces = (rest + maxChars - 1) / maxChars
            let end = balancedCut(words, start: start, target: Double(rest) / Double(nPieces), maxChars: maxChars, minLeft: minLeft)
            pieces.append(words[start..<end].joined(separator: " "))
            start = end
        }
        return pieces
    }

    /// Cắt theo `(?<=[,;:\-–—])\s+`.
    private static func splitMinor(_ s: String) -> [String] {
        let minor = Set(",;:-–—".unicodeScalars)
        let t = Array(s.unicodeScalars)
        var parts: [String] = []
        var start = 0, i = 0
        while i < t.count {
            if t[i].properties.isWhitespace, i > 0, minor.contains(t[i - 1]) {
                parts.append(str(t[start..<i]))
                var j = i
                while j < t.count && t[j].properties.isWhitespace { j += 1 }
                start = j; i = j
            } else { i += 1 }
        }
        parts.append(str(t[start..<t.count]))
        return parts
    }

    static func packSentences(_ sentences: [String], maxChars: Int) -> [String] {
        var finals: [String] = []
        var buffer = ""
        for raw in sentences {
            let sentence = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if sentence.isEmpty { continue }
            if plen(sentence) > maxChars {
                if !buffer.isEmpty { finals.append(buffer); buffer = "" }
                for p in splitMinor(sentence) {
                    let part = p.trimmingCharacters(in: .whitespacesAndNewlines)
                    if part.isEmpty { continue }
                    if fits(plen(buffer), plen(part), maxChars) {
                        buffer = buffer.isEmpty ? part : buffer + " " + part
                    } else {
                        if !buffer.isEmpty { finals.append(buffer) }
                        buffer = part
                        if plen(buffer) > maxChars {
                            let pieces = splitLongPart(buffer, maxChars: maxChars)
                            finals.append(contentsOf: pieces.dropLast())
                            buffer = pieces.last ?? ""
                        }
                    }
                }
            } else if !buffer.isEmpty && !fits(plen(buffer), plen(sentence), maxChars) {
                finals.append(buffer); buffer = sentence
            } else {
                buffer = buffer.isEmpty ? sentence : buffer + " " + sentence
            }
        }
        if !buffer.isEmpty { finals.append(buffer) }
        return finals.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
    }

    static func classifyGap(_ chunk: String) -> String {
        let c = chunk.trimmingCharacters(in: .whitespacesAndNewlines)
        if let last = c.unicodeScalars.last, ".!?".unicodeScalars.contains(last) { return "sentence" }
        return "minor"
    }

    private static func mergeShort(_ chunksIn: [String], _ gapsIn: [String], minChars: Int) -> ([String], [String]) {
        var chunks = chunksIn, gaps = gapsIn
        while chunks.count > 1 {
            let short = chunks.indices.filter { effectiveLen(chunks[$0]) < minChars }
            guard let i = short.min(by: { effectiveLen(chunks[$0]) < effectiveLen(chunks[$1]) }) else { break }
            var right: (Int, Int)?, left: (Int, Int)?
            if i < chunks.count - 1 { right = (gaps[i] != "para" ? 1 : 0, -plen(chunks[i + 1])) }
            if i > 0 { left = (gaps[i - 1] != "para" ? 1 : 0, -plen(chunks[i - 1])) }
            var useRight = true
            if let r = right, let l = left { useRight = !(l.0 > r.0 || (l.0 == r.0 && l.1 > r.1)) }
            else if right == nil { useRight = false }
            if useRight {
                chunks[i] = chunks[i] + " " + chunks.remove(at: i + 1)
                gaps.remove(at: i)
            } else {
                chunks[i - 1] = chunks[i - 1] + " " + chunks.remove(at: i)
                gaps.remove(at: i - 1)
            }
        }
        return (chunks, gaps)
    }
}
