import Foundation

// Nhân bản giọng v3 Nano — port của `OnnxV3NanoEngine.prepare_reference` (vieneu ≥ 3.5.4, v3nano.py):
//   x-vector : fbank Kaldi 80 mel @16 kHz của cả clip (≤ 30 s) → speaker_encoder.onnx → [192]
//   style    : 5 giây đầu @24 kHz → codec_encoder.onnx → latent [1, 24, T]
//              → (z − mean) / std × scale → gom nhóm ×6 (kênh 24 → 144, T → ⌈T/6⌉) → cắt ≤ min(⌊5·fps⌋, ref_max_frames)
//              → reference_encoder.onnx (ref, ref_mask) → [50, 256]
// Kết quả dùng đúng như một giọng có sẵn (Voice.speakerEmb + Voice.style).
// Chưa làm: khử nhiễu `denoiser.onnx` (tuỳ chọn trong bản Python) và watermark.

#if canImport(OnnxRuntimeBindings)
import OnnxRuntimeBindings

final class VoiceCloner: @unchecked Sendable {
    static let refSeconds = 5.0
    static let maxSeconds = 30.0

    private let env: ORTEnv
    private let sSpk: ORTSession, sCodec: ORTSession, sRef: ORTSession
    private let spkIn: String, spkOut: String
    private let codecIn: String, codecOut: String
    private let refOut: String, refMaskIn: String
    private let latMean: [Float], latStd: [Float], latScale: Float
    private let group: Int, refMaxFrames: Int, fps: Double
    private let nStyle: Int, styleDim: Int

    init(directory: URL, threads: Int = 3) throws {
        let cfgData = try Data(contentsOf: directory.appendingPathComponent("config.json"))
        let obj = try JSONSerialization.jsonObject(with: cfgData) as? [String: Any] ?? [:]
        func nums(_ k: String) -> [Float]? { (obj[k] as? [Any])?.compactMap { ($0 as? NSNumber)?.floatValue } }
        var meanV = nums("latent_mean")
        var stdV = nums("latent_std")
        var scaleV = (obj["latent_scale"] as? NSNumber)?.floatValue
        // constants.npz (nếu có) được ưu tiên, giống bản Python.
        if let c = try? NPZ.load(url: directory.appendingPathComponent("constants.npz")) {
            if let m = c["latent_mean"], !m.data.isEmpty { meanV = m.data }
            if let s = c["latent_std"], !s.data.isEmpty { stdV = s.data }
            if let s = c["latent_scale"], let v = s.data.first { scaleV = v }
        }
        guard let mean = meanV, let std = stdV, let scale = scaleV, !mean.isEmpty, mean.count == std.count else {
            throw TTSError.clone("config.json / constants.npz thiếu latent_mean, latent_std hoặc latent_scale.")
        }
        latMean = mean; latStd = std; latScale = scale
        group = (obj["group"] as? Int) ?? 6
        refMaxFrames = (obj["ref_max_frames"] as? Int) ?? 140
        fps = (obj["flow_fps"] as? Double) ?? (24000.0 / 256.0 / 6.0)
        nStyle = (obj["n_style"] as? Int) ?? 50
        styleDim = (obj["style_dim"] as? Int) ?? 256

        let environment = try ORTEnv(loggingLevel: .warning)
        let opts = try ORTSessionOptions()
        try opts.setIntraOpNumThreads(Int32(threads))
        func open(_ f: String) throws -> ORTSession {
            let path = directory.appendingPathComponent(f).path
            guard FileManager.default.fileExists(atPath: path) else {
                throw TTSError.clone("Thiếu file \(f). Hãy tải model nhân bản giọng trước.")
            }
            return try ORTSession(env: environment, modelPath: path, sessionOptions: opts)
        }
        let spk = try open("speaker_encoder.onnx")
        let codec = try open("codec_encoder.onnx")
        let ref = try open("reference_encoder.onnx")
        env = environment
        sSpk = spk; sCodec = codec; sRef = ref

        guard let si = try spk.inputNames().first, let so = try spk.outputNames().first,
              let ci = try codec.inputNames().first, let co = try codec.outputNames().first,
              let ro = try ref.outputNames().first else {
            throw TTSError.clone("Không đọc được tên đầu vào/ra của model nhân bản giọng.")
        }
        spkIn = si; spkOut = so; codecIn = ci; codecOut = co; refOut = ro
        // reference_encoder nhận `ref_mask` kiểu bool; sau khi vá thì tên là `ref_mask_u8` (uint8).
        let refInputs = try ref.inputNames()
        refMaskIn = refInputs.contains("ref_mask_u8") ? "ref_mask_u8" : "ref_mask"
    }

    // MARK: - Tensor helpers

    private static func tensor<T>(_ a: [T], _ shape: [Int], _ type: ORTTensorElementDataType) throws -> ORTValue {
        let data = a.withUnsafeBufferPointer { NSMutableData(bytes: $0.baseAddress, length: a.count * MemoryLayout<T>.stride) }
        return try ORTValue(tensorData: data, elementType: type, shape: shape.map { NSNumber(value: $0) })
    }

    private static func floats(_ v: ORTValue) throws -> [Float] {
        let d = try v.tensorData() as Data
        return d.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
    }

    // MARK: - Enroll

    func enroll(clip: ReferenceAudio.Clip, denoise: Bool = false) throws -> (spk: [Float], style: [[Float]]) {
        let sr = clip.sampleRate
        var wav = Array(clip.samples.prefix(Int(Self.maxSeconds * Double(sr))))
        wav = AudioUtils.trimAndFade(wav, sr: sr)          // cắt im lặng hai đầu (như bước làm sạch của bản Python)
        guard wav.count >= 2 * sr else {
            throw TTSError.clone("Giọng mẫu quá ngắn: cần ít nhất 2 giây tiếng nói (khuyến nghị 5–10 giây).")
        }
        let peak = wav.reduce(Float(0)) { max($0, abs($1)) }
        guard peak > 0.005 else { throw TTSError.clone("Giọng mẫu quá nhỏ hoặc gần như im lặng.") }

        // Làm sạch nhẹ + chuẩn hoá âm lượng giọng mẫu (giọng mẫu nhỏ/ồn → giọng tạo ra nhỏ/rè).
        if denoise { wav = SpectralDenoiser.denoise(wav, sr: sr, strength: 0.35) }   // khử tiếng xì/ù/ồn nền ổn định
        wav = AudioUtils.prepareReference(wav, sr: sr)
        // Theo hướng dẫn của VieNeu: mẫu 3–8 giây. Chọn đoạn 8 giây nhiều tiếng nói, ít ồn nhất;
        // x-vector tính trên cả đoạn đó, style dùng 5 giây đầu của đoạn (xem styleTokens).
        let segLen = Int(8.0 * Double(sr))
        let s0 = AudioUtils.bestWindowStart(wav, sr: sr, seconds: 8.0)
        let seg = Array(wav[s0..<min(wav.count, s0 + segLen)])

        let spk = try speakerEmbedding(Resampler.resample(seg, from: sr, to: 16_000))
        let style = try styleTokens(Resampler.resample(seg, from: sr, to: 24_000))
        return (spk, style)
    }

    private func speakerEmbedding(_ w16: [Float]) throws -> [Float] {
        guard let fb = SpeakerFbank.compute(w16) else { throw TTSError.clone("Giọng mẫu quá ngắn.") }
        func run(_ shape: [Int], _ data: [Float]) throws -> [Float] {
            let t = try Self.tensor(data, shape, .float)
            guard let o = try sSpk.run(withInputs: [spkIn: t], outputNames: [spkOut], runOptions: nil)[spkOut] else {
                throw TTSError.clone("speaker_encoder không trả kết quả.")
            }
            return try Self.floats(o)
        }
        var emb: [Float]
        do {
            emb = try run([1, fb.frames, SpeakerFbank.numBins], fb.data)          // [1, T, 80]
        } catch {
            var tr = [Float](repeating: 0, count: fb.data.count)                  // thử bố cục [1, 80, T]
            for t in 0..<fb.frames { for m in 0..<SpeakerFbank.numBins { tr[m * fb.frames + t] = fb.data[t * SpeakerFbank.numBins + m] } }
            emb = try run([1, SpeakerFbank.numBins, fb.frames], tr)
        }
        guard emb.count == 192, emb.allSatisfy({ $0.isFinite }) else {
            throw TTSError.clone("x-vector có \(emb.count) giá trị (cần 192).")
        }
        return emb
    }

    private func styleTokens(_ w24: [Float]) throws -> [[Float]] {
        let n = min(w24.count, Int(Self.refSeconds * 24_000))
        let seg = Array(w24.prefix(n))
        let inp = try Self.tensor(seg, [1, 1, n], .float)
        guard let mu = try sCodec.run(withInputs: [codecIn: inp], outputNames: [codecOut], runOptions: nil)[codecOut] else {
            throw TTSError.clone("codec_encoder không trả kết quả.")
        }
        let shape = try mu.tensorTypeAndShapeInfo().shape.map { $0.intValue }
        let data = try Self.floats(mu)
        let C = latMean.count
        guard shape.count == 3, shape[0] == 1, shape[1] == C, shape[2] > 0, data.count == C * shape[2] else {
            throw TTSError.clone("codec_encoder trả dạng \(shape), cần [1, \(C), T].")
        }
        let T = shape[2]
        let g = group
        let Tg = (T + g - 1) / g                                   // T được đệm 0 lên bội số của g
        let rows = C * g

        // z[(c*g + j)][k] = norm(mu[c][k*g + j]); phần đệm = 0 (đệm SAU khi chuẩn hoá, như bản Python).
        var z = [Float](repeating: 0, count: rows * Tg)
        for c in 0..<C {
            let m = latMean[c], s = latStd[c]
            for k in 0..<Tg {
                for j in 0..<g {
                    let t = k * g + j
                    if t < T { z[(c * g + j) * Tg + k] = (data[c * T + t] - m) / s * latScale }
                }
            }
        }

        let F = min(Tg, min(Int(Self.refSeconds * fps), refMaxFrames))
        guard F > 0 else { throw TTSError.clone("Giọng mẫu quá ngắn để mã hoá phong cách.") }
        var ref = [Float](repeating: 0, count: rows * F)
        for r in 0..<rows { for k in 0..<F { ref[r * F + k] = z[r * Tg + k] } }

        let refT = try Self.tensor(ref, [1, rows, F], .float)
        let maskT = try Self.tensor([UInt8](repeating: 1, count: F), [1, F], .uInt8)
        guard let out = try sRef.run(withInputs: ["ref": refT, refMaskIn: maskT], outputNames: [refOut], runOptions: nil)[refOut] else {
            throw TTSError.clone("reference_encoder không trả kết quả.")
        }
        let flat = try Self.floats(out)
        guard flat.count == nStyle * styleDim, flat.allSatisfy({ $0.isFinite }) else {
            throw TTSError.clone("style có \(flat.count) giá trị (cần \(nStyle * styleDim)).")
        }
        return (0..<nStyle).map { Array(flat[($0 * styleDim)..<(($0 + 1) * styleDim)]) }
    }
}
#else
final class VoiceCloner: @unchecked Sendable {
    init(directory: URL, threads: Int = 3) throws {
        throw TTSError.notImplemented("ONNX Runtime (bật package onnxruntime trong project.yml)")
    }
    func enroll(clip: ReferenceAudio.Clip, denoise: Bool = false) throws -> (spk: [Float], style: [[Float]]) { throw TTSError.clone("Thiếu ONNX Runtime.") }
}
#endif
