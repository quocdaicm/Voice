import Foundation

/// Port từ src/vieneu_utils/pause_tags.py: thẻ `[nghỉ 2s]`, `[nghỉ 500ms]`, `[pause 1.5s]`, `[nghỉ]`.
enum PauseTags {
    static let defaultPause = 1.0
    static let maxPause = 10.0

    private static let tagRE = try! NSRegularExpression(
        pattern: #"\[\s*(?:nghỉ|nghi|pause)(?!\p{L})([^\]]*)\]"#, options: [.caseInsensitive])
    private static let argRE = try! NSRegularExpression(
        pattern: #"^\s*(\d+(?:[.,]\d+)?)\s*(ms|s|giây|giay|sec|seconds?)?\s*$"#, options: [.caseInsensitive])

    static func parsePause(_ arg: String) -> Double {
        if arg.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return defaultPause }
        let ns = arg as NSString
        guard let m = argRE.firstMatch(in: arg, range: NSRange(location: 0, length: ns.length)) else { return 0 }
        var value = Double(ns.substring(with: m.range(at: 1)).replacingOccurrences(of: ",", with: ".")) ?? 0
        if m.range(at: 2).location != NSNotFound, ns.substring(with: m.range(at: 2)).lowercased() == "ms" {
            value /= 1000
        }
        return min(max(value, 0), maxPause)
    }

    /// [(đoạn, giây nghỉ sau đoạn)]. Không có thẻ -> [(text, 0)].
    static func split(_ text: String) -> [(String, Double)] {
        let ns = text as NSString
        var out: [(String, Double)] = []
        var pos = 0
        for m in tagRE.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            let seg = ns.substring(with: NSRange(location: pos, length: m.range.location - pos))
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let pause = parsePause(ns.substring(with: m.range(at: 1)))
            if seg.isEmpty, let last = out.last {
                out[out.count - 1] = (last.0, last.1 + pause)
            } else {
                out.append((seg, pause))
            }
            pos = m.range.location + m.range.length
        }
        let tail = ns.substring(from: pos).trimmingCharacters(in: .whitespacesAndNewlines)
        if !tail.isEmpty || out.isEmpty { out.append((tail, 0)) }
        return out
    }
}
