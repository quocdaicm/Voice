import Foundation

/// Ba phép toán mà thư viện sea-g2p (Rust) cung cấp — xem ghi chú GIAI ĐOẠN 2 ở TTSEngine.swift.
/// Mọi phần còn lại của pipeline văn bản (tách câu, chia chunk, thẻ cảm xúc, thẻ nghỉ) đã được port sang Swift.
protocol SeaG2P {
    /// Chuẩn hoá văn bản (số, ngày, từ tiếng Anh…) — tương đương `Normalizer.normalize(text, punc_norm=…)`.
    func normalize(_ text: String, puncNorm: Bool) throws -> String
    /// Chuẩn hoá + chuyển âm vị (IPA) — tương đương `SEAPipeline(lang="vi").run(text, punc_norm=…)`.
    func run(_ text: String, puncNorm: Bool) throws -> String
    /// Chốt dấu câu cuối — tương đương `sea_g2p.punc_norm(text)`.
    func puncNorm(_ text: String) throws -> String
}

/// Dùng khi chưa có XCFramework SeaG2P (giai đoạn 2 chưa hoàn tất): báo lỗi rõ ràng thay vì đọc sai.
struct UnavailableG2P: SeaG2P {
    private var err: Error { TTSError.notImplemented("bộ chuyển văn bản → âm vị (sea-g2p, giai đoạn 2)") }
    func normalize(_ text: String, puncNorm: Bool) throws -> String { throw err }
    func run(_ text: String, puncNorm: Bool) throws -> String { throw err }
    func puncNorm(_ text: String) throws -> String { throw err }
}

#if canImport(SeaG2PFFI)
import SeaG2PFFI

/// Cầu nối C-ABI có sẵn của sea-g2p (vendor/sea-g2p/src/capi.rs, header include/sea_g2p.h).
/// Handle không an toàn đa luồng: dùng tuần tự trên một luồng (NanoEngine đã làm vậy).
final class RustG2P: SeaG2P, @unchecked Sendable {
    private let handle: OpaquePointer

    init() throws {
        guard let url = Bundle.main.url(forResource: "sea_g2p", withExtension: "bin") else {
            throw TTSError.notImplemented("thiếu file từ điển sea_g2p.bin trong app")
        }
        guard let h = sea_g2p_open(url.path) else {
            let msg = sea_g2p_last_error().map { String(cString: $0) } ?? "không rõ"
            throw TTSError.notImplemented("mở từ điển sea-g2p thất bại: \(msg)")
        }
        handle = h
    }

    deinit { sea_g2p_close(handle) }

    private func take(_ p: UnsafeMutablePointer<CChar>?, _ what: String) throws -> String {
        guard let p else {
            let msg = sea_g2p_last_error().map { String(cString: $0) } ?? "không rõ"
            throw TTSError.notImplemented("sea-g2p \(what): \(msg)")
        }
        defer { sea_g2p_string_free(p) }
        return String(cString: p)
    }

    func normalize(_ text: String, puncNorm: Bool) throws -> String {
        try take(sea_g2p_normalize(handle, text, puncNorm ? 1 : 0), "normalize")
    }
    func run(_ text: String, puncNorm: Bool) throws -> String {
        try take(sea_g2p_phonemize(handle, text, puncNorm ? 1 : 0), "phonemize")
    }
    func puncNorm(_ text: String) throws -> String {
        try take(sea_g2p_punc_norm(text), "punc_norm")
    }
}
#endif

enum G2PFactory {
    static var isAvailable: Bool {
        #if canImport(SeaG2PFFI)
        return true
        #else
        return false
        #endif
    }
    static func make() throws -> SeaG2P {
        #if canImport(SeaG2PFFI)
        return try RustG2P()
        #else
        return UnavailableG2P()
        #endif
    }
}
