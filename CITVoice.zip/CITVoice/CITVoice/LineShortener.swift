import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

// =============================================================================
//  TỰ RÚT NGẮN CÂU DỊCH CHO VỪA THỜI LƯỢNG (v0.7)
//  Dùng model ngôn ngữ trên máy của Apple (framework Foundation Models, iOS 26+, máy có Apple Intelligence).
//  Không tải thêm model, chạy offline. Máy/iOS không hỗ trợ → tính năng tự tắt, app vẫn lồng tiếng bằng
//  cách đọc nhanh hơn (tối đa 1.6x) như trước.
//  Chưa build thử: API FoundationModels viết theo tài liệu công khai (SystemLanguageModel.default.availability,
//  LanguageModelSession(instructions:), respond(to:options:) → .content). Bọc bằng canImport + #available.
// =============================================================================

enum ShortenAvailability: Equatable {
    case available
    case unavailable(String)
}

enum LineShortener {
    /// Số ký tự mỗi giây mục tiêu (giọng đọc ở khoảng 1.1–1.2x vẫn tự nhiên). Trình sửa phụ đề cảnh báo từ 15 ký tự/giây.
    static let targetCPS = 17.0
    /// Dòng chỉ bị rút ngắn nếu vượt ngưỡng này (ký tự/giây).
    static let triggerCPS = 18.0
    /// Dòng ngắn hơn số ký tự này thì bỏ qua.
    static let minChars = 14

    static var availability: ShortenAvailability {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            let model = SystemLanguageModel.default
            switch model.availability {
            case .available:
                if model.supportsLocale(Locale(identifier: "vi")) { return .available }
                return .unavailable("Model của Apple chưa hỗ trợ tiếng Việt với cài đặt ngôn ngữ hiện tại của máy.")
            case .unavailable(let reason):
                switch reason {
                case .deviceNotEligible:
                    return .unavailable("Máy này không hỗ trợ Apple Intelligence.")
                case .appleIntelligenceNotEnabled:
                    return .unavailable("Hãy bật Apple Intelligence trong Cài đặt để dùng tính năng này.")
                case .modelNotReady:
                    return .unavailable("Model của Apple chưa tải xong. Thử lại sau ít phút.")
                @unknown default:
                    return .unavailable("Model của Apple chưa sẵn sàng.")
                }
            }
        }
        #endif
        return .unavailable("Cần iOS 26 trở lên và máy hỗ trợ Apple Intelligence.")
    }

    /// Khung thời gian của một dòng = từ lúc nó bắt đầu đến khi dòng sau bắt đầu (giống cách DubbingModel đặt giọng).
    static func slot(of cue: SubtitleCue, in cues: [SubtitleCue]) -> Double {
        let next = cues.filter { $0.start > cue.start }.map { $0.start }.min()
        return max(0.4, (next ?? cue.end) - cue.start - 0.05)
    }

    /// Các dòng cần rút ngắn: (vị trí, số ký tự tối đa).
    static func candidates(_ cues: [SubtitleCue]) -> [(index: Int, maxChars: Int)] {
        var out: [(Int, Int)] = []
        for (i, c) in cues.enumerated() {
            let text = c.text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard text.count >= minChars else { continue }
            let slot = slot(of: c, in: cues)
            if Double(text.count) / slot > triggerCPS {
                out.append((i, max(8, Int(slot * targetCPS))))
            }
        }
        return out
    }

    /// Rút ngắn tất cả dòng quá dài. Trả về số dòng đã sửa. `onProgress(đã xong, tổng)`.
    @MainActor
    static func shortenAll(_ cues: inout [SubtitleCue],
                           onProgress: @MainActor (Int, Int) -> Void = { _, _ in }) async throws -> Int {
        guard case .available = availability else { return 0 }
        let work = candidates(cues)
        var changed = 0
        for (n, item) in work.enumerated() {
            try Task.checkCancellation()
            onProgress(n, work.count)
            let cue = cues[item.index]
            if let better = await shorten(cue.text, original: cue.original, maxChars: item.maxChars) {
                cues[item.index].text = better
                changed += 1
            }
        }
        onProgress(work.count, work.count)
        return changed
    }

    /// Rút một dòng; nil nếu không rút được (giữ nguyên bản cũ).
    static func shorten(_ text: String, original: String, maxChars: Int) async -> String? {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            var current = text.trimmingCharacters(in: .whitespacesAndNewlines)
            var limit = maxChars
            for _ in 0..<2 {
                guard let next = await rewrite(current, original: original, limit: limit) else { break }
                guard next.count < current.count else { break }
                current = next
                if current.count <= Int(Double(maxChars) * 1.15) { break }
                limit = Int(Double(maxChars) * 0.85)      // vẫn dài → thử lần hai chặt hơn
            }
            return current == text.trimmingCharacters(in: .whitespacesAndNewlines) ? nil : current
        }
        #endif
        return nil
    }

    #if canImport(FoundationModels)
    @available(iOS 26.0, *)
    private static func rewrite(_ text: String, original: String, limit: Int) async -> String? {
        let instructions = """
        You shorten Vietnamese subtitle lines so a voice actor can read them in a limited time. \
        Rewrite the given line so it has at most the requested number of characters. \
        Keep the meaning, names, numbers and tone. Use natural spoken Vietnamese. Do not add new information. \
        Reply with the rewritten Vietnamese line only: no quotes, no notes, no explanation.
        """
        var prompt = "Maximum length: \(limit) characters.\nLine: \(text)"
        let ref = original.trimmingCharacters(in: .whitespacesAndNewlines)
        if !ref.isEmpty, ref != text { prompt += "\nOriginal source line (for reference only): \(ref)" }
        do {
            let session = LanguageModelSession(instructions: instructions)
            let response = try await session.respond(to: prompt, options: GenerationOptions(temperature: 0.2))
            return clean(response.content)
        } catch {
            return nil      // vượt giới hạn an toàn / ngôn ngữ / ngữ cảnh… → giữ nguyên dòng
        }
    }
    #endif

    /// Bỏ dấu ngoặc kép, nhãn "Line:", lấy dòng đầu.
    static func clean(_ raw: String) -> String? {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if let first = s.split(whereSeparator: \.isNewline).first { s = String(first) }
        for prefix in ["Line:", "Rewritten line:", "Câu rút gọn:"] where s.hasPrefix(prefix) {
            s = String(s.dropFirst(prefix.count))
        }
        s = s.trimmingCharacters(in: CharacterSet(charactersIn: "\"“”'‘’ ").union(.whitespacesAndNewlines))
        return s.isEmpty ? nil : s
    }
}
