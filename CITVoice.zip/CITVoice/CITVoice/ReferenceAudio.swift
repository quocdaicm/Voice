import Foundation
import AVFoundation

/// Đọc giọng mẫu (wav/m4a/mp3/caf…) về mono float [-1, 1] ở tần số gốc của file.
enum ReferenceAudio {
    struct Clip {
        var samples: [Float]
        var sampleRate: Int
        var seconds: Double { sampleRate > 0 ? Double(samples.count) / Double(sampleRate) : 0 }
    }

    static func load(url: URL, maxSeconds: Double = 30) throws -> Clip {
        let file = try AVAudioFile(forReading: url)
        let fmt = file.processingFormat
        let want = min(Double(file.length), maxSeconds * fmt.sampleRate)
        let frames = AVAudioFrameCount(max(0, want))
        guard frames > 0, let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: frames) else {
            throw TTSError.clone("File âm thanh rỗng hoặc không đọc được.")
        }
        try file.read(into: buf, frameCount: frames)
        guard let ch = buf.floatChannelData else { throw TTSError.clone("Không đọc được dữ liệu âm thanh.") }
        let n = Int(buf.frameLength)
        let channels = max(1, Int(fmt.channelCount))
        var mono = [Float](repeating: 0, count: n)
        for c in 0..<channels {
            let p = ch[c]
            for i in 0..<n { mono[i] += p[i] }
        }
        if channels > 1 {
            let inv = 1 / Float(channels)
            for i in 0..<n { mono[i] *= inv }
        }
        return Clip(samples: mono, sampleRate: Int(fmt.sampleRate))
    }

    static func duration(of url: URL) -> Double {
        guard let f = try? AVAudioFile(forReading: url), f.processingFormat.sampleRate > 0 else { return 0 }
        return Double(f.length) / f.processingFormat.sampleRate
    }
}

/// Ghi âm giọng mẫu từ micro: WAV mono 16-bit 24 kHz, tối đa `maxSeconds` giây (tự dừng).
@MainActor
final class VoiceRecorder: ObservableObject {
    static let maxSeconds = 20.0

    @Published var isRecording = false
    @Published var elapsed: Double = 0
    @Published var recordedURL: URL?

    private var recorder: AVAudioRecorder?
    private var timer: Timer?

    func start() async throws {
        guard !isRecording else { return }
        let granted: Bool = await withCheckedContinuation { cont in
            AVAudioSession.sharedInstance().requestRecordPermission { cont.resume(returning: $0) }
        }
        guard granted else {
            throw TTSError.clone("Chưa cấp quyền micro. Vào Cài đặt → CIT Voice → Micro để bật.")
        }
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
        try session.setActive(true)

        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("clone-ref-\(Int(Date().timeIntervalSince1970)).wav")
        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatLinearPCM),
            AVSampleRateKey: 24_000.0,
            AVNumberOfChannelsKey: 1,
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: false,
        ]
        let r = try AVAudioRecorder(url: url, settings: settings)
        r.prepareToRecord()
        guard r.record() else { throw TTSError.clone("Không bắt đầu ghi âm được.") }
        recorder = r
        recordedURL = nil
        elapsed = 0
        isRecording = true
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
    }

    private func tick() {
        guard let r = recorder, isRecording else { return }
        elapsed = r.currentTime
        if elapsed >= Self.maxSeconds { stop() }
    }

    @discardableResult
    func stop() -> URL? {
        timer?.invalidate()
        timer = nil
        guard let r = recorder else { return nil }
        r.stop()
        let url = r.url
        recorder = nil
        isRecording = false
        recordedURL = url
        return url
    }
}
