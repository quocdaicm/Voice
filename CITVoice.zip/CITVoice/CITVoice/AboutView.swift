import SwiftUI

// Thông tin tác giả ứng dụng. Giấy phép của thành phần bên thứ ba nằm ở Licenses.swift.
enum AuthorInfo {
    static let name = "Quốc Đại"
    static let email = "quocdai.net@gmail.com"
    static let web = "https://quocdai.site"
    static let tiktok = "https://www.tiktok.com/@quocdai69f1"
    static let copyright = "© 2026 Quốc Đại"
}

struct AboutView: View {
    private var version: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
        return v.isEmpty ? "" : "Phiên bản \(v)"
    }

    var body: some View {
        List {
            Section {
                VStack(spacing: 4) {
                    Text("CIT Voice").font(.title2.weight(.bold))
                    Text(version).font(.footnote).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
            }
            Section("Tác giả") {
                row("person.fill", AuthorInfo.name, nil)
                row("envelope.fill", AuthorInfo.email, "mailto:\(AuthorInfo.email)")
                row("globe", "quocdai.site", AuthorInfo.web)
                row("play.rectangle.fill", "TikTok @quocdai69f1", AuthorInfo.tiktok)
            }
            Section {
                Text("\(AuthorInfo.copyright). Giao diện và mã nguồn của ứng dụng thuộc về tác giả. Các thư viện và model bên thứ ba thuộc bản quyền của từng tác giả gốc, xem mục Giấy phép & ghi công. Ứng dụng không phải sản phẩm chính thức của các tác giả đó.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                NavigationLink("Giấy phép & ghi công") { LicensesView() }
            }
        }
        .navigationTitle("Về ứng dụng")
        .navigationBarTitleDisplayMode(.inline)
    }

    @ViewBuilder
    private func row(_ icon: String, _ text: String, _ link: String?) -> some View {
        if let link, let url = URL(string: link) {
            Link(destination: url) {
                Label(text, systemImage: icon)
            }
        } else {
            Label(text, systemImage: icon)
        }
    }
}
