import SwiftUI
import AVFoundation

// MARK: - Tách sóng âm từ file

enum WaveformExtractor {
    /// Trả về `count` đỉnh (0…1) và độ dài (giây). Chạy ở luồng nền.
    static func load(url: URL, count: Int) -> (peaks: [Float], duration: Double) {
        guard let file = try? AVAudioFile(forReading: url) else { return ([], 0) }
        let rate = file.processingFormat.sampleRate
        let duration = rate > 0 ? Double(file.length) / rate : 0
        let frames = AVAudioFrameCount(file.length)
        guard frames > 0,
              let buf = AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: frames) else {
            return ([], duration)
        }
        do { try file.read(into: buf) } catch { return ([], duration) }
        guard let ch = buf.floatChannelData?[0] else { return ([], duration) }

        let n = Int(buf.frameLength)
        let per = max(1, n / count)
        var out = [Float](repeating: 0, count: count)
        for i in 0..<count {
            let s = i * per
            let e = min(n, s + per)
            if s >= e { break }
            var peak: Float = 0
            var sum: Float = 0
            for j in s..<e {
                let v = abs(ch[j])
                if v > peak { peak = v }
                sum += v * v
            }
            let rms = (sum / Float(e - s)).squareRoot()
            out[i] = 0.4 * peak + 0.6 * rms
        }
        let mx = max(out.max() ?? 0, 0.0001)
        return (out.map { pow($0 / mx, 0.65) }, duration)   // nén nhẹ để thanh thấp vẫn thấy
    }
}

private func formatTime(_ t: TimeInterval) -> String {
    let s = max(0, Int(t.rounded(.down)))
    return String(format: "%d:%02d", s / 60, s % 60)
}

// MARK: - Trình phát sóng âm (kiểu tin nhắn thoại)

struct WaveformPlayer: View {
    let url: URL
    @ObservedObject var player: AudioPlayer
    var showShare = true
    var onError: (String) -> Void = { _ in }

    @State private var peaks: [Float] = []
    @State private var totalDuration: Double = 0
    @State private var scrubbing = false
    @State private var scrubProgress: Double = 0

    init(url: URL, player: AudioPlayer, showShare: Bool = true, onError: @escaping (String) -> Void = { _ in }) {
        self.url = url
        self._player = ObservedObject(wrappedValue: player)
        self.showShare = showShare
        self.onError = onError
    }

    private var isActive: Bool { player.loadedURL == url }
    private var playing: Bool { isActive && player.isPlaying }
    private var total: Double { isActive && player.duration > 0 ? player.duration : totalDuration }
    private var shownProgress: Double {
        if scrubbing { return scrubProgress }
        return isActive ? player.progress : 0
    }
    private var shownTime: Double { shownProgress * total }

    var body: some View {
        HStack(spacing: 12) {
            playButton

            VStack(spacing: 4) {
                waveform
                    .frame(height: 40)
                HStack {
                    Text(formatTime(shownTime))
                    Spacer()
                    Text(formatTime(total))
                }
                .font(.caption2.monospacedDigit())
                .foregroundStyle(.secondary)
            }

            if showShare {
                ExportMenu(url: url, onError: onError)
            }
        }
        .padding(10)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .task(id: url) {
            let u = url
            peaks = []
            let r = await Task.detached(priority: .userInitiated) {
                WaveformExtractor.load(url: u, count: 160)
            }.value
            peaks = r.peaks
            totalDuration = r.duration
        }
    }

    // MARK: Nút phát (có quầng sáng nhịp theo âm lượng)

    private var playButton: some View {
        Button {
            Haptics.tap()
            if playing {
                player.pause()
            } else {
                do { try player.play(url: url) } catch { onError(error.localizedDescription) }
            }
        } label: {
            SVGIcon(playing ? "IcPause" : "IcPlay", size: 20)
        }
        .buttonStyle(CircleIconButtonStyle(size: 48))
        .background(
            Circle()
                .fill(Brand.indigo.opacity(0.22))
                .scaleEffect(playing ? 1.0 + 0.55 * CGFloat(player.level) : 1)
                .animation(.easeOut(duration: 0.08), value: player.level)
        )
        .accessibilityLabel(playing ? "Tạm dừng" : "Phát")
    }

    // MARK: Sóng âm + kéo để tua

    private var waveform: some View {
        GeometryReader { geo in
            let w = geo.size.width
            Canvas { ctx, size in
                draw(ctx: ctx, size: size)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        if !scrubbing { Haptics.select() }
                        scrubbing = true
                        scrubProgress = min(max(0, v.location.x / max(w, 1)), 1)
                    }
                    .onEnded { v in
                        let p = min(max(0, v.location.x / max(w, 1)), 1)
                        player.seek(url: url, toProgress: p)
                        scrubbing = false
                    }
            )
        }
        .accessibilityElement()
        .accessibilityLabel("Thanh tua âm thanh")
        .accessibilityValue("\(formatTime(shownTime)) trên \(formatTime(total))")
        .accessibilityAdjustableAction { dir in
            player.skip(by: dir == .increment ? 5 : -5)
        }
    }

    private func draw(ctx: GraphicsContext, size: CGSize) {
        let barW: CGFloat = 3
        let gap: CGFloat = 2.5
        let count = max(8, Int((size.width + gap) / (barW + gap)))
        let mid = size.height / 2
        let progress = shownProgress
        let playedGradient = GraphicsContext.Shading.linearGradient(
            Gradient(colors: [Brand.indigo, Brand.purple]),
            startPoint: .zero, endPoint: CGPoint(x: size.width, y: 0))
        let idle = GraphicsContext.Shading.color(Color.secondary.opacity(0.35))
        let boost = playing ? CGFloat(player.level) : 0

        for i in 0..<count {
            let frac = Double(i) / Double(max(count - 1, 1))
            // lấy đỉnh tương ứng (nếu chưa có dữ liệu → thanh thấp đều)
            var amp: CGFloat = 0.12
            if !peaks.isEmpty {
                let idx = min(peaks.count - 1, Int(frac * Double(peaks.count)))
                amp = max(0.1, CGFloat(peaks[idx]))
            }
            // vùng quanh đầu phát nhấp nhô theo âm lượng
            let dist = abs(frac - progress) * Double(count)
            if playing && dist < 4 {
                amp = min(1, amp * (1 + boost * CGFloat(1 - dist / 4) * 0.9))
            }
            let h = max(4, amp * size.height)
            let x = CGFloat(i) * (barW + gap)
            let rect = CGRect(x: x, y: mid - h / 2, width: barW, height: h)
            let path = Path(roundedRect: rect, cornerRadius: barW / 2)
            ctx.fill(path, with: frac <= progress ? playedGradient : idle)
        }

        // kim chỉ vị trí
        if progress > 0 || scrubbing {
            let x = min(max(2, CGFloat(progress) * size.width), size.width - 2)
            let line = Path(roundedRect: CGRect(x: x - 1, y: 0, width: 2, height: size.height), cornerRadius: 1)
            ctx.fill(line, with: .color(Brand.violet))
            let dotR: CGFloat = scrubbing ? 6 : 4
            let dot = Path(ellipseIn: CGRect(x: x - dotR, y: -dotR + 2, width: dotR * 2, height: dotR * 2))
            ctx.fill(dot, with: .color(Brand.violet))
        }
    }
}
