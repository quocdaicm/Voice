import Foundation

/// Độ dài khoảng nghỉ (giây) giữa các đoạn / câu / dấu phẩy khi đọc. Làm thuyết minh thì nên nghỉ dài và đều hơn mặc định.
struct PauseProfile: Equatable, Codable {
    var paragraph: Double      // giữa hai đoạn (xuống dòng)
    var sentence: Double       // giữa hai câu (. ! ?)
    var minor: Double          // sau dấu phẩy, chấm phẩy…

    static let standard = PauseProfile(paragraph: 0.55, sentence: 0.32, minor: 0.14)   // đúng như bản Python gốc
    static let storytelling = PauseProfile(paragraph: 0.9, sentence: 0.5, minor: 0.22)
    static let xianxia = PauseProfile(paragraph: 1.2, sentence: 0.7, minor: 0.3)

    func seconds(for gap: String) -> Double {
        switch gap {
        case "para": return paragraph
        case "minor": return minor
        default: return sentence
        }
    }
}

/// Bộ cài sẵn tốc độ + ngắt nghỉ. Đây chỉ là điểm bắt đầu, chỉnh tiếp bằng thanh trượt cho hợp tai.
enum PacingPreset: Int, CaseIterable, Identifiable {
    case standard, storytelling, xianxia
    var id: Int { rawValue }
    var title: String {
        switch self {
        case .standard: return "Chuẩn"
        case .storytelling: return "Kể chuyện"
        case .xianxia: return "Tiên hiệp"
        }
    }
    var speed: Double {
        switch self { case .standard: return 1.0; case .storytelling: return 0.95; case .xianxia: return 0.9 }
    }
    var pauses: PauseProfile {
        switch self { case .standard: return .standard; case .storytelling: return .storytelling; case .xianxia: return .xianxia }
    }
}
