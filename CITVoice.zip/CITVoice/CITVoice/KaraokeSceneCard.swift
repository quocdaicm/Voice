import SwiftUI
import PhotosUI
import Photos

/// Thẻ "Video karaoke" ở màn chính: nền + chữ từng từ sáng dần theo giọng vừa tạo, không cần video gốc.
struct KaraokeSceneCard: View {
    @ObservedObject var model: AppModel
    @StateObject private var scene = KaraokeSceneModel()
    @State private var portrait = true
    @State private var bgIndex = 0
    @State private var sizeIndex = 2          // "Lớn" cho cảnh nền
    @State private var colorIndex = 0
    @State private var pickedItem: PhotosPickerItem?
    @State private var pickedImage: UIImage?
    @State private var savedMessage: String?

    private var style: KaraokeVideoStyle {
        KaraokeVideoStyle(sizeFactor: KaraokeVideoStyle.sizes[sizeIndex].factor,
                          highlight: KaraokeVideoStyle.colors[colorIndex].color)
    }

    private var background: KaraokeBackground {
        KaraokeBackground(colors: KaraokeBackground.presets[bgIndex].colors, image: pickedImage)
    }

    var body: some View {
        if let audio = model.outputURL, !model.lastTimings.isEmpty, !model.isGenerating {
            Card("Video karaoke", icon: "music.mic") {
                Text("Tạo video từ bản đọc vừa rồi: nền và chữ từng từ sáng dần theo giọng.")
                    .font(.footnote).foregroundStyle(.secondary)

                Picker("Khung hình", selection: $portrait) {
                    Text("Dọc 9:16").tag(true)
                    Text("Ngang 16:9").tag(false)
                }
                .pickerStyle(.segmented)

                Picker("Nền", selection: $bgIndex) {
                    ForEach(0..<KaraokeBackground.presets.count, id: \.self) {
                        Text(KaraokeBackground.presets[$0].name).tag($0)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(pickedImage != nil)

                HStack {
                    PhotosPicker(selection: $pickedItem, matching: .images) {
                        Label(pickedImage == nil ? "Dùng ảnh làm nền" : "Đổi ảnh nền", systemImage: "photo")
                            .font(.footnote.weight(.semibold))
                    }
                    Spacer()
                    if pickedImage != nil {
                        Button("Bỏ ảnh", role: .destructive) { pickedImage = nil; pickedItem = nil }
                            .font(.footnote)
                    }
                }

                Picker("Cỡ chữ", selection: $sizeIndex) {
                    ForEach(0..<KaraokeVideoStyle.sizes.count, id: \.self) { Text(KaraokeVideoStyle.sizes[$0].name).tag($0) }
                }
                .pickerStyle(.segmented)
                Picker("Màu sáng", selection: $colorIndex) {
                    ForEach(0..<KaraokeVideoStyle.colors.count, id: \.self) { Text(KaraokeVideoStyle.colors[$0].name).tag($0) }
                }
                .pickerStyle(.segmented)

                if scene.isMaking {
                    ProgressView(value: scene.progress).tint(Brand.indigo)
                    HStack {
                        Text("Đang tạo video… \(Int(scene.progress * 100))%")
                            .font(.footnote).foregroundStyle(.secondary)
                        Spacer()
                        Button("Huỷ", role: .cancel) { scene.cancel() }.font(.footnote)
                    }
                } else {
                    Button {
                        Haptics.tap()
                        savedMessage = nil
                        scene.make(timings: model.lastTimings, audio: audio, portrait: portrait,
                                   background: background, style: style)
                    } label: {
                        Label(scene.videoURL == nil ? "Tạo video karaoke" : "Tạo lại video karaoke",
                              systemImage: "play.rectangle.on.rectangle")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                }

                if let url = scene.videoURL, !scene.isMaking {
                    ShareLink(item: url) {
                        Label("Chia sẻ video", systemImage: "square.and.arrow.up")
                            .font(.footnote.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                    Button {
                        saveToPhotos(url)
                    } label: {
                        Label("Lưu video vào Ảnh", systemImage: "photo.on.rectangle")
                            .font(.footnote.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                }
                if let m = savedMessage {
                    Text(m).font(.footnote).foregroundStyle(.green)
                }
                if let e = scene.error {
                    Text(e).font(.footnote).foregroundStyle(.red)
                }
            }
            .onChange(of: pickedItem) { item in
                guard let item else { return }
                Task {
                    if let data = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: data) {
                        pickedImage = img
                    }
                }
            }
            .onChange(of: model.outputURL) { _ in scene.reset() }
        }
    }

    private func saveToPhotos(_ url: URL) {
        Task {
            let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            guard status == .authorized || status == .limited else {
                scene.error = "Chưa được cấp quyền lưu vào Ảnh. Vào Cài đặt > CIT Voice > Ảnh để cho phép."
                return
            }
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
                }
                savedMessage = "Đã lưu vào Ảnh."
                Haptics.success()
            } catch {
                scene.error = error.localizedDescription
            }
        }
    }
}
