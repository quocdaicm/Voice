import Foundation

/// Giọng có sẵn của VieNeu v3 Nano: x-vector 192 chiều + 50x256 style token.
/// Nguồn: Resources/voices_v3_nano.json (copy từ src/vieneu/assets/voices_v3_nano.json).
struct Voice: Identifiable {
    let id: String            // tên giọng, vd "Minh Quân"
    let description: String
    let gender: String
    let speakerEmb: [Float]   // [192]
    let style: [[Float]]      // [50][256]
}

enum VoiceLibrary {
    private struct File: Decodable {
        let default_voice: String
        let presets: [String: Preset]
    }
    private struct Preset: Decodable {
        let description: String
        let gender: String
        let speaker_emb: [Float]
        let style: [[Float]]
    }

    static func load() -> (voices: [Voice], defaultID: String) {
        guard let url = Bundle.main.url(forResource: "voices_v3_nano", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let file = try? JSONDecoder().decode(File.self, from: data) else {
            return ([], "")
        }
        var list = file.presets.map {
            Voice(id: $0.key, description: $0.value.description, gender: $0.value.gender,
                  speakerEmb: $0.value.speaker_emb, style: $0.value.style)
        }
        list.sort { $0.id.localizedCompare($1.id) == .orderedAscending }
        return (list, file.default_voice)
    }
}
