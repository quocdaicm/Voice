import Foundation

/// Giọng có sẵn của VieNeu v3 Nano: x-vector 192 chiều + 50x256 style token.
/// Nguồn: Resources/voices_v3_nano.json (copy từ src/vieneu/assets/voices_v3_nano.json).
struct Voice: Identifiable {
    let id: String            // tên giọng, vd "Minh Quân"
    let description: String
    let gender: String
    let speakerEmb: [Float]   // [192]
    let style: [[Float]]      // [50][256]
    var isCustom = false      // giọng người dùng nhân bản (lưu trong CustomVoices.json)
    var engine = "vieneu"     // "vieneu" | "supertonic" (giọng mẫu của Supertonic-3: không có speakerEmb/style)
    var preset = ""           // tên file giọng Supertonic, vd "M1", "F2"
}

enum VoiceLibrary {
    private struct File: Decodable {
        let default_voice: String
        let presets: [String: Preset]
    }
    private struct Preset: Decodable {
        let description: String
        let gender: String
        let speaker_emb: [Float]
        let style: [[Float]]
    }

    static func load() -> (voices: [Voice], defaultID: String) {
        guard let url = Bundle.main.url(forResource: "voices_v3_nano", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let file = try? JSONDecoder().decode(File.self, from: data) else {
            return ([], "")
        }
        var list = file.presets.map {
            Voice(id: $0.key, description: $0.value.description, gender: $0.value.gender,
                  speakerEmb: $0.value.speaker_emb, style: $0.value.style)
        }
        list.sort { $0.id.localizedCompare($1.id) == .orderedAscending }
        return (list, file.default_voice)
    }
}

/// Giọng nhân bản của người dùng: lưu trong Application Support/CustomVoices.json (x-vector 192 + style 50×256 mỗi giọng).
/// Cùng ý nghĩa với một mục trong voices_v3_nano.json nên NanoEngine dùng như giọng có sẵn.
final class CustomVoiceStore {
    private struct Item: Codable {
        var name: String
        var createdAt: Date
        var speakerEmb: [Float]
        var style: [[Float]]
    }

    private let url: URL

    init() {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        url = dir.appendingPathComponent("CustomVoices.json")
    }

    private func read() -> [Item] {
        guard let data = try? Data(contentsOf: url),
              let items = try? JSONDecoder().decode([Item].self, from: data) else { return [] }
        return items
    }

    private func write(_ items: [Item]) throws {
        try JSONEncoder().encode(items).write(to: url, options: .atomic)
    }

    func load() -> [Voice] {
        read().map {
            Voice(id: $0.name, description: "Giọng nhân bản", gender: "", speakerEmb: $0.speakerEmb,
                  style: $0.style, isCustom: true)
        }
    }

    func add(_ v: Voice) throws {
        var items = read().filter { $0.name != v.id }
        items.append(Item(name: v.id, createdAt: Date(), speakerEmb: v.speakerEmb, style: v.style))
        try write(items)
    }

    func remove(id: String) throws {
        try write(read().filter { $0.name != id })
    }
}
