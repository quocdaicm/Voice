import SwiftUI
import AVKit
import PhotosUI
import UniformTypeIdentifiers

/// Màn "Lồng tiếng video": chọn video + phụ đề → tạo giọng cho từng dòng → ghép vào video.
struct DubbingView: View {
    @ObservedObject var store: ModelStore
    @ObservedObject var app: AppModel
    @StateObject private var dub = DubbingModel()
    @StateObject private var gen = SubtitleGenModel()
    @StateObject private var stems = StemModelStore()
    @State private var sheet: Sheet?

    @State private var pickerItem: PhotosPickerItem?
    @State private var importing = false
    @State private var importKind: ImportKind = .video
    @State private var loadingVideo = false

    private enum ImportKind { case video, subtitle }
    private enum Sheet: Int, Identifiable { case auto, edit; var id: Int { rawValue } }

    private var importTypes: [UTType] {
        switch importKind {
        case .video:
            return [.movie, .mpeg4Movie, .quickTimeMovie]
        case .subtitle:
            return [.plainText, .text, UTType(filenameExtension: "srt"), UTType(filenameExtension: "vtt")]
                .compactMap { $0 }
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                videoCard
                subtitleCard
                optionsCard
                if let url = dub.outputURL { resultCard(url) }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .background(AuroraBackground())
        .navigationTitle("Lồng tiếng video")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom, spacing: 0) { bottomBar }
        .filePicker(isPresented: $importing, types: importTypes) { result in
            switch result {
            case .success(let url): handleImported(url)
            case .failure(let e): dub.errorMessage = e.localizedDescription
            }
        }
        .onChange(of: pickerItem) { item in
            guard let item else { return }
            loadingVideo = true
            Task {
                defer { loadingVideo = false; pickerItem = nil }
                do {
                    if let v = try await item.loadTransferable(type: PickedVideo.self) {
                        await dub.setVideo(url: v.url, name: "Video từ thư viện")
                    }
                } catch {
                    dub.errorMessage = error.localizedDescription
                }
            }
        }
        .sheet(item: $sheet) { which in
            switch which {
            case .auto:
                AutoSubtitleSheet(gen: gen, dub: dub) { sheet = .edit }
            case .edit:
                SubtitleEditorView(cues: $dub.cues, notice: gen.notice, previewingID: dub.previewingID) { cue in
                    dub.preview(cue: cue, app: app, store: store)
                }
            }
        }
        .alert("Lỗi", isPresented: Binding(
            get: { dub.errorMessage != nil },
            set: { if !$0 { dub.errorMessage = nil } }
        )) {
            Button("Đóng", role: .cancel) {}
        } message: {
            Text(dub.errorMessage ?? "")
        }
    }

    // MARK: - Video

    private var videoCard: some View {
        Card("Video", icon: "film") {
            if let img = dub.thumbnail {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 180)
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(alignment: .bottomTrailing) {
                        Text(timeString(dub.videoDuration))
                            .font(.caption.weight(.semibold).monospacedDigit())
                            .foregroundStyle(.white)
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(.black.opacity(0.55), in: Capsule())
                            .padding(8)
                    }
                Text(dub.videoName).font(.subheadline.weight(.semibold)).lineLimit(1)
            }
            HStack(spacing: 8) {
                PhotosPicker(selection: $pickerItem, matching: .videos) {
                    tile(loadingVideo ? "Đang nạp…" : "Thư viện ảnh", system: "photo.on.rectangle")
                }
                .disabled(dub.isBusy || loadingVideo)
                Button {
                    importKind = .video
                    importing = true
                } label: {
                    tile("Tệp", system: "folder")
                }
                .disabled(dub.isBusy)
            }
        }
    }

    // MARK: - Phụ đề

    private var subtitleCard: some View {
        Card("Phụ đề", icon: "captions.bubble") {
            Button { sheet = .auto } label: {
                HStack(spacing: 12) {
                    Image(systemName: "wand.and.stars").font(.title3)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Tự tạo phụ đề").font(.subheadline.weight(.bold))
                        Text("Nhận dạng giọng nói + dịch sang tiếng Việt")
                            .font(.caption).opacity(0.85)
                            .lineLimit(1).minimumScaleFactor(0.8)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).opacity(0.7)
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 16)
                .frame(maxWidth: .infinity, minHeight: 58)
                .background(Brand.gradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(dub.videoURL == nil || dub.isBusy)
            .opacity(dub.videoURL == nil ? 0.5 : 1)

            Text("hoặc dùng phụ đề có sẵn").font(.caption).foregroundStyle(.secondary)

            HStack(spacing: 8) {
                Button {
                    importKind = .subtitle
                    importing = true
                } label: { tile("File .srt/.vtt", system: "doc.text") }

                Button {
                    if let s = UIPasteboard.general.string, !s.isEmpty {
                        dub.setSubtitles(text: s, name: "Phụ đề đã dán")
                    }
                } label: { tile("Dán", system: "doc.on.clipboard") }

                Button {
                    Task { await dub.loadEmbedded() }
                } label: { tile("Từ video", system: "film") }
                .disabled(dub.videoURL == nil)
            }
            .buttonStyle(.plain)
            .disabled(dub.isBusy)

            if dub.cues.isEmpty {
                Text("Chưa có phụ đề.").font(.footnote).foregroundStyle(.secondary)
            } else {
                HStack {
                    Text("\(dub.cues.count) dòng · \(dub.subtitleName)")
                        .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                        .lineLimit(1)
                    Spacer(minLength: 8)
                    Button { sheet = .edit } label: {
                        Label("Sửa", systemImage: "pencil")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(Brand.indigo)
                            .padding(.horizontal, 12).frame(minHeight: 32)
                            .background(Brand.indigo.opacity(0.12), in: Capsule())
                    }
                    .disabled(dub.isBusy)
                }
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(dub.cues.prefix(6)) { cue in
                        HStack(alignment: .top, spacing: 10) {
                            Text(timeString(cue.start))
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(Brand.indigo)
                                .frame(width: 44, alignment: .leading)
                            Text(cue.text).font(.footnote).lineLimit(2)
                        }
                    }
                    if dub.cues.count > 6 {
                        Text("… và \(dub.cues.count - 6) dòng nữa")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(.tertiarySystemGroupedBackground),
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }

    // MARK: - Giọng & âm gốc

    private var optionsCard: some View {
        Card("Giọng đọc", icon: "person.wave.2.fill") {
            HStack {
                Text("Giọng")
                Spacer()
                Picker("Giọng", selection: $app.selectedVoiceID) {
                    ForEach(app.voices) { v in Text(v.id).tag(v.id) }
                }
                .pickerStyle(.menu)
                .tint(Brand.indigo)
            }
            Divider()
            Toggle("Giữ nhạc nền & tiếng động gốc", isOn: $dub.keepOriginal)
                .tint(Brand.indigo)
            if dub.keepOriginal {
                Toggle("Tách lời gốc, chỉ giữ nhạc nền", isOn: $dub.removeVoice)
                    .tint(Brand.indigo)
                if dub.removeVoice { stemModelRow }
                VStack(alignment: .leading, spacing: 2) {
                    if dub.removeVoice && stems.state == .ready {
                        Text("Âm lượng nhạc nền: \(Int(dub.originalLevel * 100))%").font(.footnote)
                        Slider(value: $dub.originalLevel, in: 0.2...1).tint(Brand.indigo)
                        Text("Lời gốc được loại bằng model AI chạy trên máy nên có thể còn sót nhẹ ở đoạn nhạc mạnh. Lần đầu tách video dài sẽ mất vài phút; kết quả được dùng lại nếu tạo lại cùng video.")
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        Text("Âm gốc lúc không có giọng đọc: \(Int(dub.originalLevel * 100))%").font(.footnote)
                        Slider(value: $dub.originalLevel, in: 0.2...1).tint(Brand.indigo)
                        Text("Âm gốc khi giọng đọc đang nói: \(Int(dub.duckLevel * 100))%").font(.footnote)
                        Slider(value: $dub.duckLevel, in: 0...0.6).tint(Brand.indigo)
                        Text("Âm gốc tự nhỏ xuống khi giọng lồng tiếng nói rồi to lại. Bật \"Tách lời gốc\" để loại hẳn lời nói gốc, chỉ còn nhạc nền.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .disabled(dub.isBusy)
    }

    /// Dòng tải / trạng thái model tách nhạc.
    @ViewBuilder
    private var stemModelRow: some View {
        switch stems.state {
        case .ready:
            HStack {
                Label("Model tách nhạc đã sẵn sàng", systemImage: "checkmark.circle.fill")
                    .font(.footnote).foregroundStyle(.green)
                Spacer()
                Button("Xoá", role: .destructive) { stems.delete() }
                    .font(.footnote).buttonStyle(.borderless)
            }
        case .downloading:
            VStack(alignment: .leading, spacing: 4) {
                Text(stems.statusText).font(.footnote)
                ProgressView(value: stems.progress).tint(Brand.indigo)
            }
        case .notInstalled, .failed:
            VStack(alignment: .leading, spacing: 6) {
                if case .failed(let m) = stems.state {
                    Text("Tải lỗi: \(m)").font(.footnote).foregroundStyle(.red)
                }
                Button {
                    Task { await stems.download() }
                } label: {
                    Label("Tải model tách nhạc (~\(StemModelStore.approxMB) MB)", systemImage: "arrow.down.circle")
                        .font(.subheadline.weight(.semibold))
                }
                .buttonStyle(.borderless)
                Text("Model UVR MDX-Net (giấy phép MIT), chạy hoàn toàn trên máy. Xem mục Giấy phép ở màn chính.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - Kết quả

    private func resultCard(_ url: URL) -> some View {
        Card("Kết quả", icon: "checkmark.circle") {
            ResultVideo(url: url)
                .frame(height: 210)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            if dub.tightCount > 0 {
                Text("\(dub.tightCount) dòng đọc dài hơn khung phụ đề dù đã đọc nhanh tối đa, nên có thể chồng nhẹ sang dòng sau.")
                    .font(.footnote).foregroundStyle(.orange)
            }
            HStack(spacing: 8) {
                Button { dub.saveToPhotos(url) } label: {
                    Label("Lưu vào Ảnh", systemImage: "square.and.arrow.down")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(SoftButtonStyle())
                ShareLink(item: url) {
                    SVGLabel("Chia sẻ", icon: "IcShare")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(SoftButtonStyle())
            }
            if let m = dub.savedMessage {
                Text(m).font(.footnote).foregroundStyle(.green)
            }
        }
    }

    // MARK: - Thanh dưới

    private var bottomBar: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                Button {
                    hideKeyboard()
                    Haptics.tap()
                    dub.start(app: app, store: store, stems: stems)
                } label: {
                    HStack(spacing: 8) {
                        if dub.isBusy {
                            ProgressView().tint(.white)
                            Text("\(dub.statusText) · \(Int(dub.progress * 100))%")
                                .lineLimit(1).minimumScaleFactor(0.8)
                        } else {
                            SVGIcon("IcWave", size: 20)
                            Text("Tạo video lồng tiếng")
                        }
                    }
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(!dub.canStart)

                if dub.isBusy {
                    Button { dub.cancel() } label: { SVGIcon("IcClear", size: 22) }
                        .buttonStyle(CircleIconButtonStyle(danger: true, size: 54))
                        .accessibilityLabel("Huỷ")
                }
            }
            if dub.isBusy { ProgressView(value: dub.progress).tint(Brand.indigo) }
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 8)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Divider() }
    }

    // MARK: - Tiện ích

    private func tile(_ title: String, system: String) -> some View {
        VStack(spacing: 4) {
            Image(systemName: system).font(.title3)
            Text(title).font(.caption.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.8)
        }
        .foregroundStyle(Brand.indigo)
        .frame(maxWidth: .infinity, minHeight: 62)
        .background(Brand.indigo.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func pillLabel(_ title: String, system: String) -> some View {
        Label(title, systemImage: system)
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(Brand.indigo)
            .padding(.horizontal, 14)
            .frame(minHeight: 40)
            .background(Brand.indigo.opacity(0.12), in: Capsule())
    }

    private func timeString(_ t: Double) -> String {
        let s = max(0, Int(t.rounded(.down)))
        return s >= 3600 ? String(format: "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                         : String(format: "%d:%02d", s / 60, s % 60)
    }

    private func handleImported(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        switch importKind {
        case .subtitle:
            do {
                let text = SubtitleParser.decode(try Data(contentsOf: url))
                dub.setSubtitles(text: text, name: url.lastPathComponent)
            } catch {
                dub.errorMessage = error.localizedDescription
            }
        case .video:
            let ext = url.pathExtension.isEmpty ? "mov" : url.pathExtension
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent("dub-src-\(UUID().uuidString).\(ext)")
            do {
                try FileManager.default.copyItem(at: url, to: dest)
                let name = url.lastPathComponent
                Task { await dub.setVideo(url: dest, name: name) }
            } catch {
                dub.errorMessage = error.localizedDescription
            }
        }
    }
}

/// Phát video kết quả.
private struct ResultVideo: View {
    let url: URL
    @State private var avPlayer: AVPlayer?

    var body: some View {
        Group {
            if let avPlayer {
                VideoPlayer(player: avPlayer)
            } else {
                Color.black
            }
        }
        .onAppear { avPlayer = AVPlayer(url: url) }
        .onChange(of: url) { avPlayer = AVPlayer(url: $0) }
        .onDisappear { avPlayer?.pause() }
    }
}
