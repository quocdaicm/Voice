import Foundation
import AVFoundation

struct SubtitleCue: Identifiable {
    let id = UUID()
    let index: Int
    let start: Double      // giây
    var end: Double
    var text: String
    var original: String = ""   // bản gốc trước khi dịch (rỗng nếu không dịch)
}

enum SubtitleParser {
    /// Đọc SRT hoặc WebVTT. Bỏ thẻ định dạng, nội dung trong [ ] (vd [Music]) và ký hiệu ♪.
    static func parse(_ raw: String) -> [SubtitleCue] {
        var text = raw.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        if text.hasPrefix("\u{FEFF}") { text.removeFirst() }
        let lines = text.components(separatedBy: "\n")

        var cues: [SubtitleCue] = []
        var i = 0
        while i < lines.count {
            let line = lines[i]
            guard line.contains("-->") else { i += 1; continue }
            let parts = line.components(separatedBy: "-->")
            guard parts.count >= 2,
                  let start = seconds(parts[0]),
                  let end = seconds(String(parts[1].trimmingCharacters(in: .whitespaces)
                                            .split(separator: " ").first ?? "")) else { i += 1; continue }
            var body: [String] = []
            i += 1
            while i < lines.count, !lines[i].trimmingCharacters(in: .whitespaces).isEmpty {
                body.append(lines[i]); i += 1
            }
            let cleaned = clean(body.joined(separator: " "))
            if !cleaned.isEmpty {
                cues.append(SubtitleCue(index: cues.count + 1, start: start,
                                        end: end > start ? end : start + 1, text: cleaned))
            }
        }
        return cues.sorted { $0.start < $1.start }
    }

    static func decode(_ data: Data) -> String {
        String(data: data, encoding: .utf8)
            ?? String(data: data, encoding: .utf16)
            ?? String(data: data, encoding: .isoLatin1) ?? ""
    }

    static func clean(_ s: String) -> String {
        var t = s
        for pattern in ["<[^>]+>", "\\{\\\\[^}]*\\}", "\\[[^\\]]*\\]", "♪"] {
            t = t.replacingOccurrences(of: pattern, with: " ", options: .regularExpression)
        }
        t = t.replacingOccurrences(of: "&nbsp;", with: " ")
            .replacingOccurrences(of: "&amp;", with: "&")
        t = t.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
        return t.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func seconds(_ s: String) -> Double? {
        let t = s.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: ".")
        let p = t.split(separator: ":").map(String.init)
        guard p.count == 2 || p.count == 3 else { return nil }
        let nums = p.map { Double($0) }
        guard !nums.contains(where: { $0 == nil }) else { return nil }
        let v = nums.map { $0 ?? 0 }
        return p.count == 3 ? v[0] * 3600 + v[1] * 60 + v[2] : v[0] * 60 + v[1]
    }
}

/// Đọc phụ đề nằm sẵn trong video dạng track văn bản (mov_text/tx3g). Không đọc được phụ đề bị "đóng cứng" vào hình.
enum EmbeddedSubtitles {
    static func read(from url: URL) async -> [SubtitleCue] {
        let asset = AVURLAsset(url: url)
        var track: AVAssetTrack?
        for type in [AVMediaType.subtitle, AVMediaType.text] {
            if let t = try? await asset.loadTracks(withMediaType: type), let first = t.first { track = first; break }
        }
        guard let track, let reader = try? AVAssetReader(asset: asset) else { return [] }
        let out = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
        guard reader.canAdd(out) else { return [] }
        reader.add(out)
        guard reader.startReading() else { return [] }

        var cues: [SubtitleCue] = []
        while let sb = out.copyNextSampleBuffer() {
            guard let block = CMSampleBufferGetDataBuffer(sb) else { continue }
            let len = CMBlockBufferGetDataLength(block)
            guard len > 2 else { continue }
            var data = Data(count: len)
            let status = data.withUnsafeMutableBytes { buf -> OSStatus in
                guard let base = buf.baseAddress else { return -1 }
                return CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: len, destination: base)
            }
            guard status == kCMBlockBufferNoErr else { continue }
            let tl = Int(data[0]) << 8 | Int(data[1])
            guard tl > 0, 2 + tl <= len,
                  let raw = String(data: data.subdata(in: 2..<(2 + tl)), encoding: .utf8) else { continue }
            let start = CMSampleBufferGetPresentationTimeStamp(sb).seconds
            var dur = CMSampleBufferGetDuration(sb).seconds
            if !dur.isFinite || dur <= 0 { dur = 2 }
            let cleaned = raw.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
                .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if !cleaned.isEmpty, start.isFinite {
                cues.append(SubtitleCue(index: cues.count + 1, start: start, end: start + dur, text: cleaned))
            }
        }
        return cues
    }
}

enum SubtitleWriter {
    /// Xuất SRT từ danh sách dòng (đánh lại số thứ tự).
    static func srt(_ cues: [SubtitleCue]) -> String {
        var out = ""
        for (i, c) in cues.enumerated() {
            out += "\(i + 1)\n\(stamp(c.start)) --> \(stamp(max(c.end, c.start + 0.2)))\n\(c.text)\n\n"
        }
        return out
    }

    private static func stamp(_ t: Double) -> String {
        let ms = Int((max(0, t) * 1000).rounded())
        return String(format: "%02d:%02d:%02d,%03d", ms / 3_600_000, (ms / 60_000) % 60, (ms / 1000) % 60, ms % 1000)
    }
}
