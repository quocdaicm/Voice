import SwiftUI

/// Phần "Video karaoke" trong thẻ Kết quả của Lồng tiếng.
struct KaraokeVideoSection: View {
    @ObservedObject var dub: DubbingModel
    @State private var sizeIndex = 1
    @State private var colorIndex = 0

    private var style: KaraokeVideoStyle {
        KaraokeVideoStyle(sizeFactor: KaraokeVideoStyle.sizes[sizeIndex].factor,
                          highlight: KaraokeVideoStyle.colors[colorIndex].color)
    }

    var body: some View {
        if dub.outputURL != nil, dub.hasFittedCues {
            VStack(alignment: .leading, spacing: 8) {
                Divider()
                Text("Video karaoke").font(.subheadline.weight(.semibold))
                Text("Vẽ chữ từng từ sáng dần theo giọng lên video đã lồng tiếng.")
                    .font(.caption).foregroundStyle(.secondary)
                Picker("Cỡ chữ", selection: $sizeIndex) {
                    ForEach(0..<KaraokeVideoStyle.sizes.count, id: \.self) { Text(KaraokeVideoStyle.sizes[$0].name).tag($0) }
                }
                .pickerStyle(.segmented)
                Picker("Màu", selection: $colorIndex) {
                    ForEach(0..<KaraokeVideoStyle.colors.count, id: \.self) { Text(KaraokeVideoStyle.colors[$0].name).tag($0) }
                }
                .pickerStyle(.segmented)

                if dub.isMakingKaraoke {
                    ProgressView(value: dub.karaokeProgress).tint(Brand.indigo)
                    HStack {
                        Text("Đang vẽ chữ karaoke… \(Int(dub.karaokeProgress * 100))%")
                            .font(.footnote).foregroundStyle(.secondary)
                        Spacer()
                        Button("Huỷ", role: .cancel) { dub.cancelKaraoke() }.font(.footnote)
                    }
                } else {
                    Button {
                        Haptics.tap()
                        dub.makeKaraokeVideo(style: style)
                    } label: {
                        Label(dub.karaokeVideoURL == nil ? "Tạo video karaoke" : "Tạo lại video karaoke",
                              systemImage: "play.rectangle.on.rectangle")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                }
                if let url = dub.karaokeVideoURL, !dub.isMakingKaraoke {
                    ShareLink(item: url) {
                        Label("Chia sẻ video karaoke", systemImage: "square.and.arrow.up")
                            .font(.footnote.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                    Button {
                        dub.saveToPhotos(url)
                    } label: {
                        Label("Lưu video karaoke vào Ảnh", systemImage: "photo.on.rectangle")
                            .font(.footnote.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                }
                if let e = dub.karaokeError {
                    Text(e).font(.footnote).foregroundStyle(.red)
                }
            }
        }
    }
}
