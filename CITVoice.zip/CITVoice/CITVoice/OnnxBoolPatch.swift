import Foundation

/// ONNX Runtime Swift/ObjC KHÔNG có kiểu tensor bool, mà `duration_predictor.onnx` và `vector_estimator.onnx`
/// nhận `ctx_mask` kiểu bool. Giải pháp: sau khi tải, vá file model một lần:
///   - input `ctx_mask` (bool) → đổi tên `ctx_mask_u8`, kiểu uint8
///   - chèn node `Cast(to=BOOL)` : ctx_mask_u8 → ctx_mask   (các node cũ vẫn dùng tên `ctx_mask`)
/// Chỉ sửa protobuf mức cao (ModelProto → GraphProto), phần còn lại giữ nguyên từng byte.
enum OnnxBoolPatch {
    static let u8Name = "ctx_mask_u8"

    private struct Field { var num: Int; var wire: Int; var varint: UInt64 = 0; var bytes = Data() }

    private static func readVarint(_ d: Data, _ p: inout Int) -> UInt64 {
        var v: UInt64 = 0, shift: UInt64 = 0
        while p < d.count {
            let b = d[d.startIndex + p]; p += 1
            v |= UInt64(b & 0x7F) << shift
            if b & 0x80 == 0 { break }
            shift += 7
        }
        return v
    }

    private static func writeVarint(_ v: UInt64, into out: inout Data) {
        var x = v
        while x >= 0x80 { out.append(UInt8(x & 0x7F) | 0x80); x >>= 7 }
        out.append(UInt8(x))
    }

    private static func parse(_ d: Data) -> [Field] {
        var fields: [Field] = []
        var p = 0
        while p < d.count {
            let tag = readVarint(d, &p)
            var f = Field(num: Int(tag >> 3), wire: Int(tag & 7))
            switch f.wire {
            case 0: f.varint = readVarint(d, &p)
            case 1: f.bytes = d.subdata(in: (d.startIndex + p)..<(d.startIndex + p + 8)); p += 8
            case 2:
                let len = Int(readVarint(d, &p))
                f.bytes = d.subdata(in: (d.startIndex + p)..<(d.startIndex + p + len)); p += len
            case 5: f.bytes = d.subdata(in: (d.startIndex + p)..<(d.startIndex + p + 4)); p += 4
            default: return fields
            }
            fields.append(f)
        }
        return fields
    }

    private static func serialize(_ fields: [Field]) -> Data {
        var out = Data()
        for f in fields {
            writeVarint(UInt64(f.num << 3 | f.wire), into: &out)
            switch f.wire {
            case 0: writeVarint(f.varint, into: &out)
            case 2: writeVarint(UInt64(f.bytes.count), into: &out); out.append(f.bytes)
            default: out.append(f.bytes)
            }
        }
        return out
    }

    private static func str(_ s: String) -> Data { Data(s.utf8) }
    private static func lenField(_ num: Int, _ data: Data) -> Field { Field(num: num, wire: 2, bytes: data) }
    private static func varField(_ num: Int, _ v: UInt64) -> Field { Field(num: num, wire: 0, varint: v) }

    /// Trả về dữ liệu đã vá, hoặc nil nếu model không có input `ctx_mask` kiểu bool (đã vá rồi / không cần).
    static func patch(_ model: Data) -> Data? {
        var top = parse(model)
        guard let gi = top.firstIndex(where: { $0.num == 7 && $0.wire == 2 }) else { return nil }
        var graph = parse(top[gi].bytes)

        var patched = false
        for k in graph.indices where graph[k].num == 11 && graph[k].wire == 2 {
            var vi = parse(graph[k].bytes)                       // ValueInfoProto
            guard let ni = vi.firstIndex(where: { $0.num == 1 }),
                  String(decoding: vi[ni].bytes, as: UTF8.self) == "ctx_mask",
                  let ti = vi.firstIndex(where: { $0.num == 2 }) else { continue }
            var type = parse(vi[ti].bytes)                       // TypeProto
            guard let tti = type.firstIndex(where: { $0.num == 1 }) else { continue }
            var tensor = parse(type[tti].bytes)                  // TypeProto.Tensor
            guard let ei = tensor.firstIndex(where: { $0.num == 1 && $0.wire == 0 }), tensor[ei].varint == 9 else { continue }
            tensor[ei].varint = 2                                // BOOL(9) → UINT8(2)
            type[tti].bytes = serialize(tensor)
            vi[ti].bytes = serialize(type)
            vi[ni].bytes = str(u8Name)
            graph[k].bytes = serialize(vi)
            patched = true
        }
        guard patched else { return nil }

        // Node Cast: input ctx_mask_u8 → output ctx_mask, attribute to = 9 (BOOL)
        let attr = serialize([lenField(1, str("to")), varField(3, 9), varField(20, 2)])   // name, i, type=INT
        let node = serialize([
            lenField(1, str(u8Name)), lenField(2, str("ctx_mask")),
            lenField(3, str("cast_ctx_mask_to_bool")), lenField(4, str("Cast")),
            lenField(5, attr),
        ])
        let firstNode = graph.firstIndex(where: { $0.num == 1 && $0.wire == 2 }) ?? 0
        graph.insert(lenField(1, node), at: firstNode)           // đầu danh sách node: đúng thứ tự topo
        top[gi].bytes = serialize(graph)
        return serialize(top)
    }

    /// Vá file tại chỗ (ghi qua file tạm). Trả true nếu có sửa.
    @discardableResult
    static func patchFile(at url: URL) throws -> Bool {
        let data = try Data(contentsOf: url, options: .mappedIfSafe)
        guard let out = patch(data) else { return false }
        let tmp = url.appendingPathExtension("tmp")
        try out.write(to: tmp, options: .atomic)
        _ = try FileManager.default.replaceItemAt(url, withItemAt: tmp)
        return true
    }
}
