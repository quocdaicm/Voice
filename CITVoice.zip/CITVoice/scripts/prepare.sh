#!/bin/bash
# Chạy tự động trước `xcodegen generate` (xem options.preGenCommand trong project.yml).
# Chuẩn bị 3 thứ mà repo không chứa: gói ONNX Runtime, từ điển sea_g2p.bin, SeaG2PFFI.xcframework.
set -euo pipefail
export GIT_TERMINAL_PROMPT=0
cd "$(dirname "$0")/.."

echo "== 1/3 onnxruntime-swift-package-manager (1.24.2, bản sao)"
# Repo gốc microsoft/onnxruntime-swift-package-manager bị gỡ khỏi GitHub từ 2026-11-17 (trả 404).
# Dùng bản sao của bên thứ ba, nhưng CHỈ nhận nếu đúng commit b7fb7f7 của tag 1.24.2
# (hai nhóm độc lập cùng báo commit này là bản gốc không sửa đổi).
WANT=b7fb7f7
if [ ! -f vendor/onnxruntime-spm/Package.swift ]; then
  ok=0
  for repo in TypeWhisper/onnxruntime-swift-package-manager Spoken-Margins/onnxruntime-swift-package-manager; do
    rm -rf vendor/onnxruntime-spm
    echo "thử $repo"
    if git clone --depth 1 --branch 1.24.2 "https://github.com/$repo" vendor/onnxruntime-spm; then
      got=$(git -C vendor/onnxruntime-spm rev-parse HEAD)
      echo "commit: $got"
      case "$got" in
        $WANT*) ok=1; break ;;
        *) echo "commit KHÔNG khớp $WANT — bỏ qua bản sao này" ;;
      esac
    fi
  done
  [ "$ok" = 1 ] || { rm -rf vendor/onnxruntime-spm; echo "LỖI: không lấy được onnxruntime-swift-package-manager hợp lệ"; exit 1; }
fi

echo "== 2/3 từ điển sea_g2p.bin (~62 MB)"
if [ ! -f CITVoice/Resources/sea_g2p.bin ]; then
  rm -rf /tmp/sea-g2p
  git clone --depth 1 https://github.com/pnnbao97/sea-g2p /tmp/sea-g2p
  cp /tmp/sea-g2p/python/sea_g2p/sea_g2p.bin CITVoice/Resources/sea_g2p.bin
fi
ls -la CITVoice/Resources

echo "== 3/3 sea-g2p (Rust) → SeaG2PFFI.xcframework"
export IPHONEOS_DEPLOYMENT_TARGET=16.0
rustup target add aarch64-apple-ios aarch64-apple-ios-sim
( cd vendor/sea-g2p
  for t in aarch64-apple-ios aarch64-apple-ios-sim; do
    cargo rustc --release --lib --no-default-features --features capi --crate-type staticlib --target "$t"
  done )
rm -rf headers Frameworks/SeaG2PFFI.xcframework
mkdir -p headers Frameworks
cp vendor/sea-g2p/include/sea_g2p.h headers/
printf 'module SeaG2PFFI {\n    header "sea_g2p.h"\n    export *\n}\n' > headers/module.modulemap
xcodebuild -create-xcframework \
  -library vendor/sea-g2p/target/aarch64-apple-ios/release/libsea_g2p_rs.a -headers headers \
  -library vendor/sea-g2p/target/aarch64-apple-ios-sim/release/libsea_g2p_rs.a -headers headers \
  -output Frameworks/SeaG2PFFI.xcframework
echo "== xong"
