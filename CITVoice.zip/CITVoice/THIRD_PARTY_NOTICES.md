**Tác giả ứng dụng:** Quốc Đại · quocdai.net@gmail.com · https://quocdai.site · https://www.tiktok.com/@quocdai69f1 · © 2026 Quốc Đại

# Giấy phép & ghi công bên thứ ba (CIT Voice 0.7.0)

CIT Voice dùng hoặc tải về các thành phần dưới đây. Giấy phép là của từng tác giả. Bản đầy đủ nhất xem trong app (**màn chính → Giấy phép & ghi công**) và ở trang nguồn.
Khi thêm thành phần mới, cập nhật cả file này lẫn `CITVoice/Licenses.swift`.

| Thành phần | Dùng để | Tác giả / bản quyền | Giấy phép | Nguồn |
|---|---|---|---|---|
| VieNeu-TTS v3 Nano (model giọng, 11 giọng mẫu, model nhân bản giọng) | Tạo giọng tiếng Việt, nhân bản giọng | Phạm Nguyễn Ngọc Bảo (pnnbao-ump) | Apache-2.0 (theo thẻ license của trang model) | https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Nano |
| sea-g2p (+ từ điển `sea_g2p.bin`) | Văn bản → âm vị | pnnbao97 | Apache-2.0 | https://github.com/pnnbao97/sea-g2p |
| ONNX Runtime | Chạy model ONNX | Microsoft Corporation | MIT | https://github.com/microsoft/onnxruntime |
| onnxruntime-swift-package-manager | Gói Swift cho ONNX Runtime | Microsoft Corporation | MIT | https://github.com/microsoft/onnxruntime-swift-package-manager |
| WhisperKit | Chạy Whisper trên máy | Argmax, Inc. | MIT | https://github.com/argmaxinc/WhisperKit |
| OpenAI Whisper (bản Core ML của Argmax) | Nhận dạng giọng nói | OpenAI; Argmax, Inc. (chuyển đổi) | MIT | https://github.com/openai/whisper · https://huggingface.co/argmaxinc/whisperkit-coreml |
| UVR MDX-Net Inst HQ 3 (bản Core ML fp16) | Tách lời khỏi nhạc nền | Anjok07, Kimberley Jensen (model); Gyoom (chuyển đổi, © 2026) | MIT | https://huggingface.co/gyoom/UVR-MDX-CoreML · https://github.com/TRvlvr/model_repo |
| Kaldi / kaldi-native-fbank | Tham khảo thuật toán fbank (không chép mã) | Các tác giả Kaldi / kaldi-native-fbank | Apache-2.0 | https://github.com/csukuangfj/kaldi-native-fbank |
| Apple Translation, Foundation Models, SF Symbols | Dịch, rút ngắn câu, biểu tượng | Apple Inc. | Điều khoản của Apple | https://developer.apple.com/support/terms/ |

Toàn văn: MIT — trong app, mỗi mục MIT hiện văn bản kèm tên chủ bản quyền. Apache-2.0 — `CITVoice/Resources/LICENSE-Apache-2.0.txt` (cũng hiện trong app) và https://www.apache.org/licenses/LICENSE-2.0.

Lưu ý: model được tải trực tiếp từ Hugging Face về máy người dùng khi dùng tính năng tương ứng; app không đóng gói trọng số model trong IPA (trừ từ điển `sea_g2p.bin` và `voices_v3_nano.json`).
